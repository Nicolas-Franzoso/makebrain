# Tutorial de Conexao da Meta API para Social Media

Guia operacional para o Gestor de Social Media da Make conectar o cliente ao ecossistema de Social Media do Make Central Brain.

## Objetivo

Liberar leitura de dados do Instagram e Facebook para:

- auditoria inicial
- analise de vencedores
- leitura de alcance, engajamento e conversao
- relatorio mensal comparativo

## O Que o Gestor Precisa Ter em Maos

- nome do cliente
- acesso ao Gerenciador de Negocios
- pagina do Facebook conectada ao Instagram
- perfil do Instagram profissional
- Instagram Business Account ID
- access token valido da Meta para leitura
- permissao do cliente para conceder acesso

## Passo a Passo Interno para o Gestor da Make

1. Confirmar se o Instagram esta em conta profissional e vinculado a uma pagina do Facebook.
2. Confirmar se o cliente sabe quem administra o Business Manager.
3. Pedir ao cliente para adicionar ou aprovar o parceiro da Make no Gerenciador de Negocios.
4. Validar se a pagina, o Instagram e os ativos corretos aparecem vinculados.
5. Registrar no contexto do cliente:
   - status da conexao
   - quem aprovou
   - data
   - pendencias
   - Instagram Business Account ID
   - Page ID
6. Atualizar `04_channels/social.md` com o status da conexao.

## Como Enviar para o Codex em Texto Comum

O operador pode colar algo assim:

```text
token meta: <TOKEN>
instagram business account id: 1784...
page id: 1234...
instagram handle: @cliente
```

Se o cliente ja estiver ativo com `social`, o Make Brain valida a conexao e salva isso no control plane.

## Checklist Tecnico

- Instagram profissional conectado
- pagina do Facebook correta
- Business Manager identificado
- permissao de leitura dos ativos concedida
- conta validada pelo time interno

## Mensagem Pronta para WhatsApp

```text
Oi, [Nome]! Tudo bem?

Para liberarmos a analise de Social Media da sua conta com seguranca, precisamos que voce aprove a conexao dos ativos da Meta no seu Gerenciador de Negocios.

Isso permite que a nossa equipe acompanhe dados de desempenho do Instagram/Facebook, como alcance, engajamento e conversoes, e use essas informacoes para construir os proximos conteudos e os relatorios mensais.

Se preferir, eu posso te mandar o passo a passo e acompanhar junto com voce. Assim que a aprovacao estiver concluida, seguimos com a configuracao final por aqui.
```

## Mensagem Pronta para Email

```text
Assunto: Liberacao de acesso Meta para analise de Social Media

Oi, [Nome].

Para darmos continuidade ao setup da sua operacao de Social Media, precisamos da aprovacao dos ativos da Meta no Gerenciador de Negocios.

Esse acesso sera usado apenas para leitura e analise dos dados da conta, permitindo que a Make acompanhe desempenho de conteudos, identifique oportunidades e entregue relatorios mensais com mais precisao.

Se for melhor para voce, podemos fazer isso juntos em uma chamada rapida.

Assim que a aprovacao for concluida, nos avise por aqui para seguirmos com o setup.

Obrigado.
```

## Quando Escalar

- o cliente nao sabe quem administra o Business Manager
- a pagina e o Instagram nao estao conectados
- ha conflito entre agencias/parceiros
- o perfil ainda esta como conta pessoal

## O Que Salvar no Contexto

Salvar em `tutorial_conexao_meta_social.md`:

- status atual
- pendencias
- ultima acao realizada
- proximo passo
- responsavel
