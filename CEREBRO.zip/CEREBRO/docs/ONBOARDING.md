# Onboarding de Novo Projeto

Este fluxo existe para garantir que os agentes certos sejam ativados na hora certa, sem depender de tentativa e erro.

## Como funciona

1. Preencha o onboarding mestre do cliente.
2. O sistema identifica o que ja pode ser ativado.
3. O sistema mostra o que ainda esta bloqueado.
4. Para cada etapa bloqueada, ele faz as proximas perguntas certas.
5. Cada integracao tem tutorial simples para pessoas leigas.

## Perguntas obrigatorias do onboarding mestre

- Nome do cliente
- Identificador da conta
- Produtos contratados
- Meta dos proximos 90 dias
- Metricas de sucesso
- Investimento mensal
- Verba de midia paga, quando existir
- Ofertas prioritarias
- Ticket medio
- Ciclo de vendas
- Capacidade comercial
- Transcricao da R1
- Concorrentes
- Regioes atendidas
- Tom de voz
- Ativos existentes
- Contatos de aprovacao
- Rotina de alinhamento

## Exemplos de perguntas por etapa

### MakeADS

- Qual oferta vai primeiro para campanha?
- Ja existe acesso valido da Meta?
- Qual destino principal: WhatsApp, landing page ou formulario?

### Social

- Em quais redes a marca sera trabalhada?
- Quem aprova posts?
- Ha material criativo disponivel?

### Web

- Qual pagina precisa converter primeiro?
- O time tem acesso ao CMS?
- O objetivo e lead, venda, agendamento ou outra acao?

### CRM

- O cliente usa MakeCRM?
- Quais estagios existem no pipeline?
- Qual e o SLA de resposta?

### Mavi

- Em quais canais a Mavi vai atuar?
- O que define lead qualificado?
- Quando a conversa precisa ir para um humano?

## Endpoints principais

- `GET /onboarding/project-template`
- `POST /onboarding/project-plan`
- `POST /onboarding/bootstrap-client`
- `GET /onboarding/stages/{stage}`

## Bootstrap sem chamar API manualmente

Se o time ja preencheu o JSON do cliente, pode rodar:

```powershell
python scripts\bootstrap_client.py examples\onboarding\cliente-exemplo.json growth
```

Isso faz tudo de uma vez:

- cria a estrutura do cliente em `make-central-brain-context/clients/<slug>/`
- grava a R1 no historico
- cria os arquivos canônicos e os `04_channels/*.md`
- indexa a memoria
- gera os primeiros jobs do projeto

## Skill para o time

A skill `project-bootstrap-client` executa o mesmo fluxo do script e do endpoint.

- entrada: respostas completas do onboarding
- saida: arquivos criados, plano de ativacao e jobs iniciais

## Regra operacional

Nenhum agente especialista deve ser ativado so porque o produto foi contratado. Ele so entra quando:

- o contexto base existe
- a etapa tem respostas minimas
- os acessos necessarios foram confirmados

## Regra de Growth

Se `MakeADS` estiver contratado:

- o onboarding deve salvar a transcricao da R1 no contexto
- o primeiro job de growth deve ser `onboarding-media-plan`
- essa skill deve usar a skill oficial `plano-de-midia-make`, versionada dentro do Make Brain
- o plano de midia aprovado vira a diretriz mestra das campanhas
- depois disso entram `campaign-roadmap`, criativo e performance
