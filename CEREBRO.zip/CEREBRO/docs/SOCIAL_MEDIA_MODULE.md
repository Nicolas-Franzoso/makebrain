# Modulo Social Media

Documento-base do pipeline de Social Media dentro do Make Central Brain.

## Regra Mestra

- Social Media nao cria um contexto paralelo.
- Toda leitura parte dos arquivos globais do cliente em `make-central-brain-context/clients/<slug>/`.
- Toda escrita relevante volta para a mesma base compartilhada.
- MakeADS, SEO, Web, CRM, Mavi e Social devem conseguir ler os mesmos fatos, restricoes e aprendizados.

## Fluxograma Logico

```mermaid
flowchart TD
    A[Novo cliente com servico Social] --> B[Modulo 1: Ingestao da R1 global]
    B --> C[Atualizar contexto global .md do cliente]
    C --> D[Auditoria de perfil e concorrencia]
    D --> E[Salvar auditoria_social_inicial.md]
    E --> F[Gerar tutorial de conexao Meta + copy para o gestor]
    F --> G[Modulo 2: Briefing oficial da conta]
    G --> H[Gerar briefing_social.md]
    H --> I[Gerar posts_iniciais.md com 4 ideias]
    I --> J[Aprovacao humana]
    J --> K[Modulo 3: Motor de execucao]
    K --> L[Fetch obrigatorio do contexto global]
    L --> M[Gerar grade datada posts_<mes><ano>.md]
    M --> N[Aprovacao humana]
    N --> O[Publicacao operacional pelo time]
    O --> P[Modulo 4: Analise mensal]
    P --> Q[Ler Meta Graph API + contexto + historico]
    Q --> R[Gerar relatorio_<mes><ano>.md]
    R --> S[Proximos passos planejados]
    S --> T[Realimentar 04_channels/social.md e artifacts]
```

## Estrutura Tecnica por Modulo

### Modulo 1. Onboarding e Setup Inicial

- Gatilho: cliente com `social` contratado
- Agente principal: `social-onboarding-agent`
- Skills:
  - `social-r1-ingestion`
  - `social-profile-audit`
  - `social-meta-api-connection-guide`
- Leitura obrigatoria:
  - `07_history/daily/*`
  - `00_profile.md`
  - `01_brand_voice.md`
  - `03_offer_stack.md`
  - `04_channels/social.md`
- Escritas:
  - enriquecimento dos arquivos canonicamente compartilhados
  - `auditoria_social_inicial.md`
  - `tutorial_conexao_meta_social.md`

### Modulo 2. Entrega Estrategica Inicial

- Gatilho: fechamento do Modulo 1
- Agente principal: `social-onboarding-agent`
- Skills:
  - `social-initial-delivery`
  - `editorial-pillar-map`
- Saidas:
  - `briefing_social.md`
  - `posts_iniciais.md`
- Regra:
  - as 4 ideias iniciais devem vir com formato, hook, referencia visual descritiva e referencia de conteudo
  - tudo alinhado ao contexto global consolidado

### Modulo 3. Motor de Execucao

- Gatilho:
  - completar 8 posts restantes
  - abrir novo ciclo de 12 posts
- Agente principal: `social-copy-agent`
- Skill central:
  - `social-copy-engine`
- Leitura obrigatoria antes de escrever:
  - `00_profile.md`
  - `01_brand_voice.md`
  - `02_business_model.md`
  - `03_offer_stack.md`
  - `04_channels/social.md`
  - `04_channels/makeads.md` se existir
  - `05_sales_crm.md`
  - `07_history/daily/*`
  - `08_artifacts/*`
- Saida:
  - `posts_<mes><ano>.md`
- Governanca:
  - `approval_required = true`

### Modulo 4. Analise de Dados e Reporte

- Gatilho: fechamento do ciclo mensal
- Agente principal: `social-reporting-agent`
- Skills:
  - `social-monthly-report-analysis`
  - `community-signal-report`
  - `content-winner-analysis`
- Insumos:
  - Graph API do Meta
  - lote publicado no mes
  - aprendizados anteriores
  - contexto global
- Saida:
  - `relatorio_<mes><ano>.md`
- Conteudo minimo:
  - alcance, engajamento, conversao
  - comparativo MoM
  - vitorias, riscos, proximos passos planejados

## Agentes do Modulo

- `social-onboarding-agent`
  - conecta R1, auditoria, setup e entrega inicial
- `social-strategy-agent`
  - transforma contexto em linhas editoriais
- `social-copy-agent`
  - gera a grade estruturada de posts usando fetch previo do contexto global
- `social-listening-agent`
  - detecta sinais organicos e conteudos vencedores
- `social-reporting-agent`
  - consolida aprendizado mensal e recomenda proximos movimentos

## Regras de Armazenamento

- R1 entra no historico global do cliente e nunca em um arquivo isolado so do Social
- aprendizados do Social podem atualizar:
  - `04_channels/social.md`
  - `08_artifacts/*.md`
  - entradas diarias em `07_history/daily/*`
- quando um insight de Social impactar outro pilar, ele deve ser registrado em formato legivel para o resto do brain

## Outputs Canonicos do Pilar

- `auditoria_social_inicial.md`
- `tutorial_conexao_meta_social.md`
- `briefing_social.md`
- `posts_iniciais.md`
- `posts_<mes><ano>.md`
- `relatorio_<mes><ano>.md`
