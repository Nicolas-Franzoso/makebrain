from __future__ import annotations

from fastapi import FastAPI

from brain.api.routes import router
from brain.config import get_settings
from brain.db import init_db


settings = get_settings()
init_db()

app = FastAPI(title=settings.app_name, version="0.1.0")
app.include_router(router)

