from __future__ import annotations

from pathlib import Path

from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from sqlalchemy import func, select

from brain.config import get_settings
from brain.contracts import AlertRecord, ApprovalDecision, JobCreate
from brain.db import session_scope
from brain.orchestrator.maestro import MaestroOrchestrator
from brain.platform.approval_service import ApprovalService
from brain.platform.bootstrap_service import OnboardingBootstrapService
from brain.platform.conversation_service import ConversationService
from brain.platform.context_indexer import ContextIndexer
from brain.platform.context_service import ContextService
from brain.platform.db_models import AlertORM, ApprovalORM, ContextIndexORM, ConversationSessionORM
from brain.platform.growth_kickoff_service import GrowthKickoffService
from brain.platform.integration_service import IntegrationService
from brain.platform.job_queue import JobQueue
from brain.platform.onboarding_service import OnboardingService
from brain.platform.registry import load_agents, load_skills
from brain.platform.social_reporting_service import SocialReportingService


router = APIRouter()


class ContextCaptureRequest(BaseModel):
    client_slug: str
    author: str
    title: str
    body: str


class ApprovalRequestBody(BaseModel):
    client_id: str
    requested_by: str
    artifact_id: str | None = None


class GitWebhookPayload(BaseModel):
    commit_sha: str
    repo_path: str | None = None


class OnboardingAnswersBody(BaseModel):
    answers: dict


class OnboardingBootstrapBody(BaseModel):
    answers: dict
    requested_by: str = "onboarding"


class MediaPlanFinalizeBody(BaseModel):
    job_id: str
    media_plan_content: str
    plan_summary: str
    approved_by: str


class ConversationMessageBody(BaseModel):
    message: str
    session_id: str | None = None
    author: str = "user"


class MetaSocialConnectBody(BaseModel):
    client_id: str
    access_token: str
    instagram_business_account_id: str
    meta_page_id: str | None = None
    meta_business_id: str | None = None
    instagram_handle: str | None = None
    requested_by: str = "social-operator"


class SocialMonthlyReportBody(BaseModel):
    client_id: str
    period: str
    requested_by: str = "social-reporting-agent"


@router.get("/health")
def health() -> dict:
    settings = get_settings()
    return {"status": "ok", "app": settings.app_name, "environment": settings.environment}


@router.get("/registry/agents")
def agents() -> list[dict]:
    return [agent.model_dump() for agent in load_agents()]


@router.get("/registry/skills")
def skills() -> list[dict]:
    return [skill.model_dump() for skill in load_skills()]


@router.get("/onboarding/project-template")
def onboarding_project_template() -> dict:
    return OnboardingService().get_project_template()


@router.get("/onboarding/stages/{stage}")
def onboarding_stage_guide(stage: str) -> dict:
    try:
        return OnboardingService().get_stage_guide(stage)
    except KeyError as exc:
        raise HTTPException(status_code=404, detail=str(exc)) from exc


@router.post("/onboarding/project-plan")
def onboarding_project_plan(body: OnboardingAnswersBody) -> dict:
    return OnboardingService().build_activation_plan(body.answers)


@router.post("/onboarding/bootstrap-client")
def onboarding_bootstrap_client(body: OnboardingBootstrapBody) -> dict:
    return OnboardingBootstrapService().run(body.answers, requested_by=body.requested_by)


@router.post("/growth/media-plan/finalize")
def growth_finalize_media_plan(body: MediaPlanFinalizeBody) -> dict:
    with session_scope() as session:
        return GrowthKickoffService(session).finalize_media_plan_job(
            job_id=body.job_id,
            media_plan_content=body.media_plan_content,
            plan_summary=body.plan_summary,
            approved_by=body.approved_by,
        )


@router.post("/conversation/message")
def conversation_message(body: ConversationMessageBody) -> dict:
    with session_scope() as session:
        return ConversationService(session).handle_message(
            message=body.message,
            session_id=body.session_id,
            author=body.author,
        )


@router.get("/conversation/sessions/{session_id}")
def conversation_session(session_id: str) -> dict:
    with session_scope() as session:
        row = session.get(ConversationSessionORM, session_id)
        if row is None:
            raise HTTPException(status_code=404, detail="Conversation session not found.")
        return {
            "session_id": row.session_id,
            "client_id": row.client_id,
            "status": row.status,
            "stage": row.stage,
            "pending_question_id": row.pending_question_id,
            "answers": row.answers_json,
            "message_log": row.message_log,
            "metadata": row.metadata_json,
        }


@router.post("/integrations/meta/social/connect")
def connect_meta_social(body: MetaSocialConnectBody) -> dict:
    with session_scope() as session:
        return IntegrationService(session).upsert_meta_social_connection(
            client_id=body.client_id,
            access_token=body.access_token,
            instagram_business_account_id=body.instagram_business_account_id,
            meta_page_id=body.meta_page_id,
            meta_business_id=body.meta_business_id,
            instagram_handle=body.instagram_handle,
            requested_by=body.requested_by,
        )


@router.get("/integrations/meta/social/{client_id}")
def get_meta_social(client_id: str) -> dict:
    with session_scope() as session:
        result = IntegrationService(session).get_meta_social_connection(client_id)
        if result is None:
            raise HTTPException(status_code=404, detail="Meta social integration not found.")
        safe_result = dict(result)
        safe_result.pop("access_token", None)
        return safe_result


@router.post("/social/reporting/monthly")
def social_monthly_report(body: SocialMonthlyReportBody) -> dict:
    with session_scope() as session:
        return SocialReportingService(session).generate_monthly_report(
            client_id=body.client_id,
            period_label=body.period,
            requested_by=body.requested_by,
        )


@router.post("/context/capture")
def context_capture(request: ContextCaptureRequest) -> dict:
    service = ContextService()
    path = service.capture_daily_note(request.client_slug, request.author, request.title, request.body)
    return {"path": str(path)}


@router.post("/context/index")
def context_index(payload: GitWebhookPayload) -> dict:
    root = Path(payload.repo_path) if payload.repo_path else get_settings().context_repo_path
    with session_scope() as session:
        indexed = ContextIndexer(session).index_repository(root, payload.commit_sha)
    return {"indexed_blocks": indexed, "commit_sha": payload.commit_sha}


@router.get("/context/validate")
def context_validate(commit_sha: str | None = None) -> list[dict]:
    service = ContextService()
    return service.validate_repository(commit_sha or get_settings().default_context_sha)


@router.get("/context/clients/{client_id}/blocks")
def client_blocks(client_id: str) -> list[dict]:
    with session_scope() as session:
        results = session.execute(
            select(ContextIndexORM).where(ContextIndexORM.client_id == client_id).order_by(ContextIndexORM.path, ContextIndexORM.chunk_order)
        ).scalars()
        return [
            {
                "chunk_id": row.chunk_id,
                "path": row.path,
                "heading": row.heading,
                "body": row.body,
                "commit_sha": row.commit_sha,
            }
            for row in results
        ]


@router.post("/jobs/enqueue")
def enqueue_job(data: JobCreate) -> dict:
    with session_scope() as session:
        record = JobQueue(session).enqueue(data)
        return record.model_dump(mode="json")


@router.post("/jobs/claim/{worker_id}")
def claim_job(worker_id: str) -> dict:
    with session_scope() as session:
        record = JobQueue(session).claim_next(worker_id)
        if record is None:
            return {"job": None}
        return {"job": record.model_dump(mode="json")}


@router.post("/jobs/{job_id}/complete")
def complete_job(job_id: str) -> dict:
    with session_scope() as session:
        record = JobQueue(session).complete(job_id)
        return record.model_dump(mode="json")


@router.post("/approvals")
def create_approval(request: ApprovalRequestBody) -> dict:
    with session_scope() as session:
        record = ApprovalService(session).request(request.client_id, request.requested_by, request.artifact_id)
        return record.model_dump(mode="json")


@router.post("/approvals/{approval_id}/decision")
def decide_approval(approval_id: str, decision: ApprovalDecision) -> dict:
    with session_scope() as session:
        try:
            record = ApprovalService(session).decide(approval_id, decision)
        except KeyError as exc:
            raise HTTPException(status_code=404, detail=str(exc)) from exc
        return record.model_dump(mode="json")


@router.get("/approvals/pending/count")
def approvals_pending_count() -> dict:
    with session_scope() as session:
        count = session.execute(
            select(func.count()).select_from(ApprovalORM).where(ApprovalORM.status == "pending")
        ).scalar_one()
        return {"pending": count}


@router.post("/alerts")
def create_alert(alert: AlertRecord) -> dict:
    with session_scope() as session:
        row = AlertORM(**alert.model_dump(mode="python"))
        session.add(row)
        session.flush()
        return {"alert_id": row.alert_id}


@router.get("/orchestrator/daily-plan/{client_id}")
def build_daily_plan(client_id: str, context_sha: str | None = None) -> dict:
    with session_scope() as session:
        alerts = session.execute(select(AlertORM).where(AlertORM.client_id == client_id)).scalars().all()
        approvals_pending = session.execute(
            select(func.count()).select_from(ApprovalORM).where(ApprovalORM.client_id == client_id, ApprovalORM.status == "pending")
        ).scalar_one()
        sources = session.execute(
            select(ContextIndexORM.path).where(ContextIndexORM.client_id == client_id).distinct()
        ).scalars().all()

    plan = MaestroOrchestrator().build_daily_plan(
        client_id=client_id,
        context_sha=context_sha or get_settings().default_context_sha,
        alerts=[
            AlertRecord(
                alert_id=row.alert_id,
                client_id=row.client_id,
                severity=row.severity,
                pillar=row.pillar,
                reason=row.reason,
                recommended_action=row.recommended_action,
                evidence_refs=row.evidence_refs,
                created_at=row.created_at,
            )
            for row in alerts
        ],
        approvals_pending=approvals_pending,
        indexed_sources=list(sources),
    )
    return plan.model_dump(mode="json")
