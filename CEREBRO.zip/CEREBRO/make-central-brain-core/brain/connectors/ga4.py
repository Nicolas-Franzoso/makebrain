from .base import BaseConnector


class GA4Connector(BaseConnector):
    provider = "ga4"

