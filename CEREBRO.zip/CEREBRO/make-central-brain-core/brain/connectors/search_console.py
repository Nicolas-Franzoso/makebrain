from .base import BaseConnector


class SearchConsoleConnector(BaseConnector):
    provider = "search-console"

