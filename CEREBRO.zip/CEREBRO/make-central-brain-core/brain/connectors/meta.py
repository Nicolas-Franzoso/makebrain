from __future__ import annotations

from datetime import UTC, datetime

import httpx

from .base import BaseConnector, ConnectorResult


class MetaConnectorError(RuntimeError):
    pass


class MetaConnector(BaseConnector):
    provider = "meta"

    def __init__(self, access_token: str, api_version: str = "v23.0", base_url: str = "https://graph.facebook.com"):
        self.access_token = access_token
        self.api_version = api_version
        self.base_url = base_url.rstrip("/")

    def fetch(self, account_ref: str, **kwargs) -> ConnectorResult:
        return self.fetch_instagram_profile(account_ref)

    def fetch_instagram_profile(self, instagram_business_account_id: str) -> ConnectorResult:
        payload = self._get(
            f"/{instagram_business_account_id}",
            params={"fields": "id,username,followers_count,media_count"},
        )
        return ConnectorResult(provider=self.provider, account_ref=instagram_business_account_id, payload=payload)

    def fetch_instagram_media(
        self,
        instagram_business_account_id: str,
        since: datetime | None = None,
        until: datetime | None = None,
        limit: int = 25,
    ) -> ConnectorResult:
        payload = self._get(
            f"/{instagram_business_account_id}/media",
            params={
                "fields": "id,caption,media_type,media_product_type,timestamp,like_count,comments_count,permalink,thumbnail_url,media_url",
                "limit": str(limit),
            },
        )
        data = payload.get("data", [])
        if since or until:
            filtered = []
            for item in data:
                timestamp = self._parse_dt(item.get("timestamp"))
                if since and timestamp and timestamp < since:
                    continue
                if until and timestamp and timestamp > until:
                    continue
                filtered.append(item)
            payload["data"] = filtered
        return ConnectorResult(provider=self.provider, account_ref=instagram_business_account_id, payload=payload)

    def fetch_instagram_media_insights(self, media_id: str, media_type: str | None = None) -> ConnectorResult:
        metrics_by_type = {
            "REELS": "reach,views,saved,shares,total_interactions",
            "VIDEO": "reach,views,saved,total_interactions",
            "CAROUSEL_ALBUM": "reach,saved,total_interactions",
            "IMAGE": "reach,saved,total_interactions",
        }
        metrics = metrics_by_type.get((media_type or "").upper(), "reach,saved,total_interactions")
        try:
            payload = self._get(f"/{media_id}/insights", params={"metric": metrics})
        except MetaConnectorError as exc:
            return self.error(media_id, str(exc), metrics={})
        metrics_payload = {item.get("name"): self._extract_metric_value(item) for item in payload.get("data", [])}
        return ConnectorResult(provider=self.provider, account_ref=media_id, payload={"metrics": metrics_payload})

    def fetch_instagram_account_insights(
        self,
        instagram_business_account_id: str,
        since: datetime,
        until: datetime,
        metrics: str = "reach,views,follower_count",
        period: str = "day",
    ) -> ConnectorResult:
        payload = self._get(
            f"/{instagram_business_account_id}/insights",
            params={
                "metric": metrics,
                "period": period,
                "since": str(int(since.timestamp())),
                "until": str(int(until.timestamp())),
            },
        )
        metrics_payload = {item.get("name"): item.get("values", []) for item in payload.get("data", [])}
        return ConnectorResult(provider=self.provider, account_ref=instagram_business_account_id, payload={"metrics": metrics_payload})

    def _get(self, path: str, params: dict | None = None) -> dict:
        query = dict(params or {})
        query["access_token"] = self.access_token
        url = f"{self.base_url}/{self.api_version}{path}"
        response = httpx.get(url, params=query, timeout=30.0)
        data = response.json()
        if response.is_error or data.get("error"):
            message = data.get("error", {}).get("message") if isinstance(data, dict) else response.text
            raise MetaConnectorError(message or f"Erro ao chamar {url}")
        return data

    def _extract_metric_value(self, item: dict) -> int:
        values = item.get("values", [])
        if values:
            value = values[-1].get("value")
            if isinstance(value, dict):
                return int(value.get("value") or 0)
            return int(value or 0)
        total_value = item.get("total_value")
        if isinstance(total_value, dict):
            return int(total_value.get("value") or 0)
        return int(total_value or 0)

    def _parse_dt(self, value: str | None) -> datetime | None:
        if not value:
            return None
        return datetime.fromisoformat(value.replace("Z", "+00:00")).astimezone(UTC)
