from __future__ import annotations

from dataclasses import dataclass
from typing import Any


@dataclass
class ConnectorResult:
    provider: str
    account_ref: str
    payload: dict


class BaseConnector:
    provider = "unknown"

    def fetch(self, account_ref: str, **kwargs) -> ConnectorResult:
        return ConnectorResult(provider=self.provider, account_ref=account_ref, payload={"status": "stub"})

    def error(self, account_ref: str, message: str, **payload: Any) -> ConnectorResult:
        return ConnectorResult(
            provider=self.provider,
            account_ref=account_ref,
            payload={"status": "error", "message": message, **payload},
        )
