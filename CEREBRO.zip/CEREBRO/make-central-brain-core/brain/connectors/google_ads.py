from .base import BaseConnector


class GoogleAdsConnector(BaseConnector):
    provider = "google-ads"

