from .base import BaseConnector


class CRMConnector(BaseConnector):
    provider = "crm"

