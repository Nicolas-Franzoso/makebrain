"""External connector stubs."""

