from __future__ import annotations

from collections import Counter
from datetime import UTC, datetime

from brain.contracts import AlertRecord, OrchestratorPlan


class MaestroOrchestrator:
    def build_daily_plan(
        self,
        client_id: str,
        context_sha: str,
        alerts: list[AlertRecord],
        approvals_pending: int,
        indexed_sources: list[str],
    ) -> OrchestratorPlan:
        counts = Counter(alert.pillar for alert in alerts)
        priorities = []

        if approvals_pending:
            priorities.append(
                {
                    "priority": 100,
                    "title": "Tratar aprovacoes pendentes",
                    "reason": f"{approvals_pending} aprovacao(oes) aguardando decisao humana.",
                    "owner_agent": "approval-governance-agent",
                }
            )

        for pillar, amount in counts.most_common():
            priorities.append(
                {
                    "priority": 90 - len(priorities),
                    "title": f"Responder sinais do pilar {pillar}",
                    "reason": f"{amount} alerta(s) aberto(s) para o pilar {pillar}.",
                    "owner_agent": "maestro-orchestrator",
                }
            )

        if not priorities:
            priorities.append(
                {
                    "priority": 50,
                    "title": "Executar checagem operacional de rotina",
                    "reason": "Nenhum alerta critico encontrado; manter o ritmo e revisar baselines.",
                    "owner_agent": "maestro-orchestrator",
                }
            )

        return OrchestratorPlan(
            client_id=client_id,
            context_sha=context_sha,
            generated_at=datetime.now(UTC),
            priorities=priorities,
            alerts_considered=len(alerts),
            approvals_pending=approvals_pending,
            sources=indexed_sources,
        )
