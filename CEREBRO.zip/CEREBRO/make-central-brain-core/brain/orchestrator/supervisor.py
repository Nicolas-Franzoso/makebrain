from __future__ import annotations

from datetime import UTC, datetime


class ExecutionSupervisor:
    def lease_is_expired(self, lease_until) -> bool:
        if lease_until is None:
            return False
        return lease_until < datetime.now(UTC)

    def should_retry(self, attempts: int, max_attempts: int = 3) -> bool:
        return attempts < max_attempts
