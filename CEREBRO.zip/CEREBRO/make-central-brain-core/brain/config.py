from __future__ import annotations

import os
from dataclasses import dataclass
from functools import lru_cache
from pathlib import Path


@dataclass(frozen=True)
class Settings:
    app_name: str
    environment: str
    database_url: str
    context_repo_path: Path
    default_context_sha: str
    lease_seconds: int


@lru_cache(maxsize=1)
def get_settings() -> Settings:
    root = Path(__file__).resolve().parents[3]
    context_repo = Path(
        os.getenv(
            "BRAIN_CONTEXT_REPO_PATH",
            str(root / "make-central-brain-context"),
        )
    )
    return Settings(
        app_name="Make Central Brain",
        environment=os.getenv("BRAIN_ENV", "development"),
        database_url=os.getenv("BRAIN_DATABASE_URL", f"sqlite:///{root / 'brain.db'}"),
        context_repo_path=context_repo,
        default_context_sha=os.getenv("BRAIN_DEFAULT_CONTEXT_SHA", "workspace"),
        lease_seconds=int(os.getenv("BRAIN_LEASE_SECONDS", "300")),
    )

