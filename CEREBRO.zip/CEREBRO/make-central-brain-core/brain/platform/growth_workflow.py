from __future__ import annotations

from brain.contracts import JobCreate
from .media_plan_skill import resolve_media_plan_skill_path


LOCAL_MEDIA_PLAN_SKILL = resolve_media_plan_skill_path()


class GrowthWorkflowService:
    def build_initial_jobs(self, answers: dict, context_sha: str) -> list[JobCreate]:
        client_id = answers["client_slug"]
        jobs: list[JobCreate] = []
        services = answers.get("contracted_services", [])

        if "makeads" in services and answers.get("r1_transcript"):
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="makeads-planner-agent",
                    skill_id="onboarding-media-plan",
                    priority=100,
                    input_refs=["07_history/daily/onboarding", "04_channels/makeads.md"],
                    payload={
                        "client_slug": client_id,
                        "client_name": answers.get("client_name"),
                        "monthly_media_budget": answers.get("monthly_media_budget"),
                        "r1_transcript": answers.get("r1_transcript"),
                        "local_skill_path": str(LOCAL_MEDIA_PLAN_SKILL),
                        "growth_directive": "O plano de midia e a diretriz mestra das campanhas e do processo de growth.",
                        "skill_origin": "bundled-make-brain" if "make-central-brain-core" in str(LOCAL_MEDIA_PLAN_SKILL) else "legacy-local",
                    },
                    idempotency_key=f"{client_id}:onboarding-media-plan:{context_sha}",
                    context_sha=context_sha,
                )
            )
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="makeads-planner-agent",
                    skill_id="campaign-roadmap",
                    priority=90,
                    input_refs=["04_channels/makeads.md"],
                    payload={
                        "client_slug": client_id,
                        "depends_on": "onboarding-media-plan",
                        "growth_directive": "Construir roadmap de campanhas a partir do plano de midia aprovado.",
                    },
                    idempotency_key=f"{client_id}:campaign-roadmap:{context_sha}",
                    context_sha=context_sha,
                )
            )

        if "social" in services:
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="social-onboarding-agent",
                    skill_id="social-profile-audit",
                    priority=78,
                    input_refs=["07_history/daily/onboarding", "04_channels/social.md", "01_brand_voice.md"],
                    payload={
                        "client_slug": client_id,
                        "social_directive": "Usar a mesma R1 global e a mesma base de contexto do cliente sem criar silo isolado para Social.",
                        "output_filename": "auditoria_social_inicial.md",
                    },
                    idempotency_key=f"{client_id}:social-profile-audit:{context_sha}",
                    context_sha=context_sha,
                )
            )
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="social-onboarding-agent",
                    skill_id="social-meta-api-connection-guide",
                    priority=77,
                    input_refs=["04_channels/social.md", "07_history/daily/onboarding"],
                    payload={
                        "client_slug": client_id,
                        "social_directive": "Gerar tutorial tecnico para o gestor interno da Make e copy pronta para pedir aprovacao ao cliente.",
                        "output_filename": "tutorial_conexao_meta_social.md",
                    },
                    idempotency_key=f"{client_id}:social-meta-api-connection-guide:{context_sha}",
                    context_sha=context_sha,
                )
            )
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="social-onboarding-agent",
                    skill_id="social-initial-delivery",
                    priority=76,
                    input_refs=["00_profile.md", "01_brand_voice.md", "03_offer_stack.md", "04_channels/social.md", "07_history/daily/onboarding"],
                    payload={
                        "client_slug": client_id,
                        "output_files": ["briefing_social.md", "posts_iniciais.md"],
                        "social_directive": "Gerar briefing oficial da conta e 4 ideias iniciais de posts alinhadas ao contexto global consolidado.",
                    },
                    idempotency_key=f"{client_id}:social-initial-delivery:{context_sha}",
                    context_sha=context_sha,
                )
            )
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="social-strategy-agent",
                    skill_id="editorial-pillar-map",
                    priority=75,
                    input_refs=["01_brand_voice.md", "03_offer_stack.md", "04_channels/social.md"],
                    payload={
                        "client_slug": client_id,
                        "social_directive": "Cruzar os pilares editoriais com a R1 global, brand voice e diretrizes transversais da Make.",
                    },
                    idempotency_key=f"{client_id}:editorial-pillar-map:{context_sha}",
                    context_sha=context_sha,
                )
            )

        if "crm" in services:
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="crm-pipeline-agent",
                    skill_id="pipeline-diagnosis",
                    priority=70,
                    input_refs=["05_sales_crm.md"],
                    payload={"client_slug": client_id},
                    idempotency_key=f"{client_id}:pipeline-diagnosis:{context_sha}",
                    context_sha=context_sha,
                )
            )

        if "mavi" in services:
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="mavi-conversation-design-agent",
                    skill_id="persona-definition",
                    priority=65,
                    input_refs=["01_brand_voice.md", "06_mavi.md"],
                    payload={"client_slug": client_id},
                    idempotency_key=f"{client_id}:persona-definition:{context_sha}",
                    context_sha=context_sha,
                )
            )

        if "seo" in services:
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="seo-strategy-agent",
                    skill_id="keyword-cluster-map",
                    priority=60,
                    input_refs=["00_profile.md", "04_channels/seo.md"],
                    payload={"client_slug": client_id},
                    idempotency_key=f"{client_id}:keyword-cluster-map:{context_sha}",
                    context_sha=context_sha,
                )
            )

        if "web" in services:
            jobs.append(
                JobCreate(
                    client_id=client_id,
                    agent_id="web-architecture-agent",
                    skill_id="landing-page-brief",
                    priority=60,
                    input_refs=["03_offer_stack.md", "04_channels/web.md"],
                    payload={"client_slug": client_id},
                    idempotency_key=f"{client_id}:landing-page-brief:{context_sha}",
                    context_sha=context_sha,
                )
            )

        return jobs
