from __future__ import annotations

from sqlalchemy import delete
from sqlalchemy.orm import Session

from .context_parser import parse_context_repository
from .db_models import ContextIndexORM


class ContextIndexer:
    def __init__(self, session: Session):
        self.session = session

    def index_repository(self, root, commit_sha: str) -> int:
        documents = parse_context_repository(root, commit_sha)
        self.session.execute(delete(ContextIndexORM).where(ContextIndexORM.commit_sha == commit_sha))
        indexed = 0
        for document in documents:
            for block in document.blocks:
                self.session.add(
                    ContextIndexORM(
                        client_id=block.client_id,
                        path=block.path,
                        heading=block.heading,
                        body=block.body,
                        heading_level=block.heading_level,
                        chunk_order=block.order,
                        commit_sha=block.commit_sha,
                        metadata_json=block.metadata,
                        embedding_json=block.embedding,
                    )
                )
                indexed += 1
        return indexed

