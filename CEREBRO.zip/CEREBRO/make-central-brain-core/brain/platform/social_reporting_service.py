from __future__ import annotations

from dataclasses import dataclass
from datetime import UTC, datetime, timedelta

from sqlalchemy.orm import Session

from brain.config import get_settings
from brain.connectors.meta import MetaConnector
from brain.contracts import ApprovalStatus

from .approval_service import ApprovalService
from .artifact_service import ArtifactService
from .context_service import ContextService
from .integration_service import IntegrationService


@dataclass
class SocialPeriodSnapshot:
    since: datetime
    until: datetime
    profile: dict
    media: list[dict]
    totals: dict
    top_posts: list[dict]


class SocialReportingService:
    def __init__(self, session: Session, context_service: ContextService | None = None):
        self.session = session
        self.context_service = context_service or ContextService()
        self.integrations = IntegrationService(session, self.context_service)

    def generate_monthly_report(
        self,
        client_id: str,
        period_label: str,
        requested_by: str = "social-reporting-agent",
        until: datetime | None = None,
    ) -> dict:
        connection = self.integrations.get_meta_social_connection(client_id)
        if connection is None:
            raise ValueError("Nenhuma conexao Meta Social encontrada para este cliente.")

        current_until = until or datetime.now(UTC)
        current_since = current_until - timedelta(days=30)
        previous_until = current_since
        previous_since = previous_until - timedelta(days=30)

        connector = MetaConnector(access_token=connection["access_token"])
        account_id = connection["instagram_business_account_id"]

        current = self._collect_snapshot(connector, account_id, current_since, current_until)
        previous = self._collect_snapshot(connector, account_id, previous_since, previous_until)
        report_body = self._render_markdown(client_id, period_label, current, previous)

        artifact_path = self.context_service.publish_artifact(
            client_slug=client_id,
            artifact_type="social-monthly-report",
            title=f"Relatorio social {period_label}",
            body=report_body,
            metadata={
                "period": period_label,
                "since": current_since.isoformat(),
                "until": current_until.isoformat(),
                "provider": "meta-social",
            },
        )
        artifact = ArtifactService(self.session).create(
            client_id=client_id,
            artifact_type="social-monthly-report",
            producer_agent="social-reporting-agent",
            source_jobs=[],
            source_context_sha=get_settings().default_context_sha,
            storage_ref=str(artifact_path),
            approval_status=ApprovalStatus.pending,
        )
        approval = ApprovalService(self.session).request(
            client_id=client_id,
            requested_by=requested_by,
            artifact_id=artifact.artifact_id,
        )
        self.session.flush()
        return {
            "client_id": client_id,
            "period": period_label,
            "artifact_path": str(artifact_path),
            "artifact_id": artifact.artifact_id,
            "approval_id": approval.approval_id,
            "current_totals": current.totals,
            "previous_totals": previous.totals,
        }

    def _collect_snapshot(
        self,
        connector: MetaConnector,
        instagram_business_account_id: str,
        since: datetime,
        until: datetime,
    ) -> SocialPeriodSnapshot:
        profile = connector.fetch_instagram_profile(instagram_business_account_id).payload
        media = connector.fetch_instagram_media(instagram_business_account_id, since=since, until=until).payload.get("data", [])

        totals = {
            "posts": len(media),
            "likes": 0,
            "comments": 0,
            "reach": 0,
            "views": 0,
            "engagement_total": 0,
        }

        enriched_media: list[dict] = []
        for item in media:
            insights_payload = connector.fetch_instagram_media_insights(
                media_id=item["id"],
                media_type=item.get("media_type"),
            ).payload
            insight_values = insights_payload.get("metrics", {})
            likes = int(item.get("like_count") or 0)
            comments = int(item.get("comments_count") or 0)
            reach = int(insight_values.get("reach") or 0)
            views = int(insight_values.get("views") or 0)
            engagement_total = likes + comments + int(insight_values.get("saved") or 0) + int(insight_values.get("shares") or 0)
            totals["likes"] += likes
            totals["comments"] += comments
            totals["reach"] += reach
            totals["views"] += views
            totals["engagement_total"] += engagement_total
            enriched_media.append(
                {
                    **item,
                    "insights": insight_values,
                    "engagement_total": engagement_total,
                }
            )

        top_posts = sorted(enriched_media, key=lambda item: item.get("engagement_total", 0), reverse=True)[:3]
        return SocialPeriodSnapshot(
            since=since,
            until=until,
            profile=profile,
            media=enriched_media,
            totals=totals,
            top_posts=top_posts,
        )

    def _render_markdown(
        self,
        client_id: str,
        period_label: str,
        current: SocialPeriodSnapshot,
        previous: SocialPeriodSnapshot,
    ) -> str:
        return (
            f"# Relatorio de Social Media - {period_label}\n\n"
            + f"Cliente: `{client_id}`\n\n"
            + "## Janela analisada\n\n"
            + f"- Atual: {current.since.date()} ate {current.until.date()}\n"
            + f"- Anterior: {previous.since.date()} ate {previous.until.date()}\n\n"
            + "## Conta analisada\n\n"
            + f"- Instagram: `{current.profile.get('username', 'nao identificado')}`\n"
            + f"- Seguidores: `{current.profile.get('followers_count', 'n/d')}`\n"
            + f"- Midias totais: `{current.profile.get('media_count', 'n/d')}`\n\n"
            + "## Comparativo MoM\n\n"
            + self._metric_table(current.totals, previous.totals)
            + "\n## Top conteudos do periodo\n\n"
            + self._top_posts_block(current.top_posts)
            + "\n## Leitura analitica\n\n"
            + self._analysis_block(current.totals, previous.totals)
            + "\n## Proximos passos planejados\n\n"
            + self._next_steps(current.totals, previous.totals)
            + "\n## Governanca\n\n"
            + "- Aprovacao Humana: `Pendente`\n"
        )

    def _metric_table(self, current: dict, previous: dict) -> str:
        lines = [
            "| Metrica | Atual | Anterior | Variacao |",
            "|---|---:|---:|---:|",
        ]
        for metric in ("posts", "likes", "comments", "reach", "views", "engagement_total"):
            current_value = int(current.get(metric, 0))
            previous_value = int(previous.get(metric, 0))
            delta = current_value - previous_value
            lines.append(f"| {metric} | {current_value} | {previous_value} | {delta:+d} |")
        return "\n".join(lines) + "\n"

    def _top_posts_block(self, top_posts: list[dict]) -> str:
        if not top_posts:
            return "- Nenhum post encontrado na janela analisada.\n"
        block = []
        for item in top_posts:
            block.append(
                f"- `{item.get('media_type', 'POST')}` | `{item.get('timestamp', 'n/d')}` | engajamento `{item.get('engagement_total', 0)}` | {item.get('permalink', 'sem link')}"
            )
        return "\n".join(block) + "\n"

    def _analysis_block(self, current: dict, previous: dict) -> str:
        insights = []
        if current.get("engagement_total", 0) > previous.get("engagement_total", 0):
            insights.append("- O engajamento total cresceu versus o ciclo anterior, sugerindo melhor aderencia editorial.")
        else:
            insights.append("- O engajamento total caiu ou ficou estagnado versus o ciclo anterior, pedindo revisao de formato, ritmo e gancho.")
        if current.get("reach", 0) < previous.get("reach", 0):
            insights.append("- O alcance caiu e isso pode indicar distribuicao fraca, formato menos competitivo ou baixa frequencia.")
        if current.get("posts", 0) == 0:
            insights.append("- Nao houve posts registrados no periodo; revisar publicacao operacional e acessos.")
        return "\n".join(insights) + "\n"

    def _next_steps(self, current: dict, previous: dict) -> str:
        steps = [
            "- Revisar os formatos vencedores e reaplicar os ganchos mais fortes no proximo lote.",
            "- Cruzar os temas com os aprendizados de MakeADS e CRM antes do proximo calendario.",
        ]
        if current.get("reach", 0) <= previous.get("reach", 0):
            steps.append("- Testar um novo mix entre Reels, carrosseis e posts unicos para recuperar alcance.")
        if current.get("engagement_total", 0) > previous.get("engagement_total", 0):
            steps.append("- Reforcar os temas que geraram mais resposta organica e transformar os melhores em serie.")
        return "\n".join(steps) + "\n"
