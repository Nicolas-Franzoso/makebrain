from __future__ import annotations

from sqlalchemy.orm import Session

from brain.contracts import ApprovalStatus, ArtifactRecord

from .db_models import ArtifactORM


class ArtifactService:
    def __init__(self, session: Session):
        self.session = session

    def create(
        self,
        client_id: str,
        artifact_type: str,
        producer_agent: str,
        source_jobs: list[str],
        source_context_sha: str,
        storage_ref: str,
        approval_status: ApprovalStatus = ApprovalStatus.approved,
    ) -> ArtifactRecord:
        row = ArtifactORM(
            client_id=client_id,
            type=artifact_type,
            producer_agent=producer_agent,
            source_jobs=source_jobs,
            source_context_sha=source_context_sha,
            approval_status=approval_status.value,
            storage_ref=storage_ref,
        )
        self.session.add(row)
        self.session.flush()
        return ArtifactRecord(
            artifact_id=row.artifact_id,
            client_id=row.client_id,
            type=row.type,
            producer_agent=row.producer_agent,
            source_jobs=row.source_jobs,
            source_context_sha=row.source_context_sha,
            approval_status=ApprovalStatus(row.approval_status),
            storage_ref=row.storage_ref,
        )

