from __future__ import annotations

from datetime import UTC, datetime

from sqlalchemy.orm import Session

from brain.contracts import ApprovalDecision, ApprovalRecord, ApprovalStatus

from .db_models import ApprovalORM


class ApprovalService:
    def __init__(self, session: Session):
        self.session = session

    def request(self, client_id: str, requested_by: str, artifact_id: str | None = None) -> ApprovalRecord:
        approval = ApprovalORM(
            client_id=client_id,
            artifact_id=artifact_id,
            requested_by=requested_by,
            status=ApprovalStatus.pending.value,
        )
        self.session.add(approval)
        self.session.flush()
        return self._to_record(approval)

    def decide(self, approval_id: str, decision: ApprovalDecision) -> ApprovalRecord:
        approval = self.session.get(ApprovalORM, approval_id)
        if approval is None:
            raise KeyError(approval_id)
        approval.status = ApprovalStatus.approved.value if decision.approved else ApprovalStatus.rejected.value
        approval.decision_by = decision.decision_by
        approval.decision_at = datetime.now(UTC)
        approval.rationale = decision.rationale
        self.session.flush()
        return self._to_record(approval)

    def _to_record(self, approval: ApprovalORM) -> ApprovalRecord:
        return ApprovalRecord(
            approval_id=approval.approval_id,
            client_id=approval.client_id,
            artifact_id=approval.artifact_id,
            status=ApprovalStatus(approval.status),
            requested_by=approval.requested_by,
            requested_at=approval.requested_at,
            decision_by=approval.decision_by,
            decision_at=approval.decision_at,
            rationale=approval.rationale,
        )
