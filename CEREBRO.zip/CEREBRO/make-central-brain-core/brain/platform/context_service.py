from __future__ import annotations

from datetime import UTC, datetime
from pathlib import Path
import re
import unicodedata

import yaml

from brain.config import get_settings

from .context_parser import parse_context_repository, split_frontmatter, validate_frontmatter_for_path


class ContextService:
    def __init__(self, root: Path | None = None):
        settings = get_settings()
        self.root = root or settings.context_repo_path

    def client_root(self, client_slug: str) -> Path:
        return self.root / "clients" / client_slug

    def capture_daily_note(self, client_slug: str, author: str, title: str, body: str) -> Path:
        now = datetime.now(UTC)
        note_dir = self.client_root(client_slug) / "07_history" / "daily" / now.strftime("%Y-%m-%d")
        note_dir.mkdir(parents=True, exist_ok=True)
        safe_author = self.slugify(author)
        safe_title = self.slugify(title)
        path = note_dir / f"{now.strftime('%H%M%S')}-{safe_author}-{safe_title}.md"
        content = (
            "---\n"
            f"client_id: {client_slug}\n"
            f"author: {author}\n"
            f"created_at: {now.isoformat()}\n"
            "kind: daily-note\n"
            "---\n\n"
            f"# {title}\n\n"
            f"{body.strip()}\n"
        )
        path.write_text(content, encoding="utf-8")
        return path

    def bootstrap_client_context(self, answers: dict) -> dict[str, str]:
        client_slug = self.slugify(answers["client_slug"])
        client_id = client_slug
        root = self.client_root(client_slug)
        (root / "04_channels").mkdir(parents=True, exist_ok=True)
        (root / "08_artifacts").mkdir(parents=True, exist_ok=True)

        frontmatter = self._base_frontmatter(client_id, client_slug, answers)
        written: dict[str, str] = {}

        canonical_files = {
            "00_profile.md": self._render_profile(frontmatter, answers),
            "01_brand_voice.md": self._render_brand_voice(frontmatter, answers),
            "02_business_model.md": self._render_business_model(frontmatter, answers),
            "03_offer_stack.md": self._render_offer_stack(frontmatter, answers),
            "05_sales_crm.md": self._render_sales_crm(frontmatter, answers),
            "06_mavi.md": self._render_mavi(frontmatter, answers),
            "09_rules_and_constraints.md": self._render_rules(frontmatter, answers),
        }

        for filename, content in canonical_files.items():
            path = root / filename
            path.write_text(content, encoding="utf-8")
            written[filename] = str(path)

        for service in answers.get("contracted_services", []):
            channel_path = root / "04_channels" / f"{service}.md"
            channel_path.write_text(self._render_channel_file(frontmatter, answers, service), encoding="utf-8")
            written[f"04_channels/{service}.md"] = str(channel_path)

        onboarding_note = self.capture_daily_note(
            client_slug=client_slug,
            author=answers.get("requested_by", "onboarding"),
            title="Onboarding Inicial",
            body=self._render_onboarding_note(answers),
        )
        written["07_history/daily/onboarding"] = str(onboarding_note)
        return written

    def slugify(self, value: str) -> str:
        normalized = unicodedata.normalize("NFKD", value).encode("ascii", "ignore").decode("ascii")
        normalized = normalized.strip().lower()
        normalized = re.sub(r"[^a-z0-9]+", "-", normalized)
        return normalized.strip("-")

    def validate_repository(self, commit_sha: str) -> list[dict]:
        results = []
        for document in parse_context_repository(self.root, commit_sha):
            results.append(
                {
                    "path": document.path,
                    "client_id": document.client_id,
                    "missing_frontmatter_keys": validate_frontmatter_for_path(Path(document.path), document.frontmatter),
                    "blocks": len(document.blocks),
                }
            )
        return results

    def publish_artifact(
        self,
        client_slug: str,
        artifact_type: str,
        title: str,
        body: str,
        metadata: dict | None = None,
    ) -> Path:
        now = datetime.now(UTC)
        artifact_dir = self.client_root(client_slug) / "08_artifacts"
        artifact_dir.mkdir(parents=True, exist_ok=True)
        path = artifact_dir / f"{now.strftime('%Y-%m-%d-%H%M%S')}-{self.slugify(title)}.md"
        frontmatter = {
            "client_id": client_slug,
            "artifact_type": artifact_type,
            "title": title,
            "created_at": now.isoformat(),
            "metadata": metadata or {},
        }
        content = self._dump_frontmatter(frontmatter) + f"# {title}\n\n{body.strip()}\n"
        path.write_text(content, encoding="utf-8")
        return path

    def update_makeads_channel_from_media_plan(
        self,
        client_slug: str,
        plan_summary: str,
        artifact_path: str,
        approved_by: str,
    ) -> Path:
        path = self.client_root(client_slug) / "04_channels" / "makeads.md"
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            text = path.read_text(encoding="utf-8")
            frontmatter, body = split_frontmatter(text)
        else:
            frontmatter = {
                "client_id": client_slug,
                "slug": client_slug,
                "name": client_slug,
                "timezone": "America/Sao_Paulo",
                "owners": [],
                "services_enabled": ["makeads"],
                "approval_policy": "human-required",
                "stage": "active",
                "main_goals": [],
                "primary_kpis": [],
                "integrations": {"meta": "pending"},
                "status": "active",
            }
            body = "# Estado inicial do pilar makeads\n"

        cleaned_body = re.sub(r"\n## Plano de midia aprovado[\s\S]*$", "", body.strip(), flags=re.MULTILINE)
        updated_body = (
            cleaned_body
            + "\n\n## Plano de midia aprovado\n\n"
            + "O plano de midia aprovado vira a diretriz principal do growth e das campanhas de MakeADS.\n\n"
            + "### Resumo executivo\n\n"
            + f"{plan_summary.strip()}\n\n"
            + "### Fonte de verdade\n\n"
            + f"- Artefato aprovado: `{artifact_path}`\n"
            + "- Skill de origem: `plano-de-midia-make`\n"
            + f"- Aprovado por: `{approved_by}`\n\n"
            + "### Ordem operacional\n\n"
            + "1. Usar o plano de midia como diretriz das campanhas.\n"
            + "2. Refinar o roadmap de campanhas a partir do plano aprovado.\n"
            + "3. Só depois ativar criativo, performance e expansão.\n"
        )

        path.write_text(self._dump_frontmatter(frontmatter) + updated_body.strip() + "\n", encoding="utf-8")
        return path

    def update_social_channel_connection_status(
        self,
        client_slug: str,
        instagram_business_account_id: str,
        meta_page_id: str | None,
        instagram_handle: str | None,
        connected_by: str,
    ) -> Path:
        path = self.client_root(client_slug) / "04_channels" / "social.md"
        path.parent.mkdir(parents=True, exist_ok=True)

        if path.exists():
            text = path.read_text(encoding="utf-8")
            frontmatter, body = split_frontmatter(text)
        else:
            frontmatter = {
                "client_id": client_slug,
                "slug": client_slug,
                "name": client_slug,
                "timezone": "America/Sao_Paulo",
                "owners": [],
                "services_enabled": ["social"],
                "approval_policy": "human-required",
                "stage": "active",
                "main_goals": [],
                "primary_kpis": [],
                "integrations": {"meta": "pending"},
                "status": "active",
            }
            body = "# Estado inicial do pilar social\n"

        cleaned_body = re.sub(r"\n## Conexao Meta ativa[\s\S]*$", "", body.strip(), flags=re.MULTILINE)
        updated_body = (
            cleaned_body
            + "\n\n## Conexao Meta ativa\n\n"
            + f"- Instagram Business Account ID: `{instagram_business_account_id}`\n"
            + (f"- Meta Page ID: `{meta_page_id}`\n" if meta_page_id else "")
            + (f"- Instagram: `{instagram_handle}`\n" if instagram_handle else "")
            + f"- Registrado por: `{connected_by}`\n"
            + "- Status: `connected`\n"
        )
        path.write_text(self._dump_frontmatter(frontmatter) + updated_body.strip() + "\n", encoding="utf-8")
        return path

    def _base_frontmatter(self, client_id: str, client_slug: str, answers: dict) -> dict:
        integrations = {
            "meta": "connected" if answers.get("meta_access_ready") else "pending",
            "google_ads": "connected" if answers.get("google_ads_customer_id") else "pending",
            "ga4": "connected" if answers.get("ga4_property_id") else "pending",
            "search_console": "connected" if answers.get("search_console_ready") else "pending",
            "makecrm": "connected" if answers.get("makecrm_api_key") else "pending",
            "mavi": "planned" if "mavi" in answers.get("contracted_services", []) else "disabled",
        }
        return {
            "client_id": client_id,
            "slug": client_slug,
            "name": answers["client_name"],
            "timezone": answers.get("timezone", "America/Sao_Paulo"),
            "owners": answers.get("owners", []),
            "services_enabled": answers.get("contracted_services", []),
            "approval_policy": "human-required",
            "stage": "onboarding",
            "main_goals": [answers.get("primary_goal_90d", "")],
            "primary_kpis": answers.get("success_metrics", []),
            "integrations": integrations,
            "status": "active",
        }

    def _dump_frontmatter(self, frontmatter: dict) -> str:
        return "---\n" + yaml.safe_dump(frontmatter, allow_unicode=False, sort_keys=False) + "---\n\n"

    def _render_profile(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Empresa\n\n"
            + f"{answers['client_name']}\n\n"
            + "# Objetivo de 90 dias\n\n"
            + f"{answers.get('primary_goal_90d', 'Nao informado')}\n\n"
            + "# Servicos contratados\n\n"
            + self._bullet_list(answers.get("contracted_services", []))
            + "\n# Concorrentes\n\n"
            + self._bullet_list(answers.get("competitors", []))
            + "\n# Regioes atendidas\n\n"
            + self._bullet_list(answers.get("target_regions", []))
            + "\n# Metricas principais\n\n"
            + self._bullet_list(answers.get("success_metrics", []))
        )

    def _render_brand_voice(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Tom de voz\n\n"
            + f"{answers.get('brand_tone', 'Nao informado')}\n\n"
            + "# Restrições e compliance\n\n"
            + f"{answers.get('compliance_constraints', 'Nenhuma restricao adicional registrada.')}\n\n"
            + "# Quem aprova\n\n"
            + self._bullet_list(answers.get("approval_contacts", []))
        )

    def _render_business_model(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Oferta principal\n\n"
            + self._bullet_list(answers.get("main_offers", []))
            + "\n# Ticket medio\n\n"
            + f"{answers.get('ticket_range', 'Nao informado')}\n\n"
            + "# Ciclo de vendas\n\n"
            + f"{answers.get('sales_cycle', 'Nao informado')}\n\n"
            + "# Capacidade comercial\n\n"
            + f"{answers.get('sales_capacity', 'Nao informado')}\n\n"
            + "# Investimento mensal total\n\n"
            + f"{answers.get('monthly_investment_total', 'Nao informado')}\n"
        )

    def _render_offer_stack(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Ofertas prioritarias\n\n"
            + self._bullet_list(answers.get("main_offers", []))
            + "\n# Ativos existentes\n\n"
            + self._bullet_list(answers.get("existing_assets", []))
        )

    def _render_sales_crm(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Capacidade comercial\n\n"
            + f"{answers.get('sales_capacity', 'Nao informado')}\n\n"
            + "# SLA de aprovacao do cliente\n\n"
            + f"{answers.get('approval_sla', 'Nao informado')}\n\n"
            + "# MakeCRM\n\n"
            + f"Usa MakeCRM: {'sim' if answers.get('makecrm_enabled') else 'nao'}\n"
        )

    def _render_mavi(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Canais da Mavi\n\n"
            + self._bullet_list(answers.get("mavi_channels", []))
            + "\n# Material de FAQ e script\n\n"
            + ("Disponivel" if answers.get("faq_or_sales_scripts") else "Ainda nao disponivel")
            + "\n\n# Historico de conversa\n\n"
            + ("Disponivel" if answers.get("conversation_history_available") else "Ainda nao disponivel")
        )

    def _render_rules(self, frontmatter: dict, answers: dict) -> str:
        return (
            self._dump_frontmatter(frontmatter)
            + "# Politica de aprovacao\n\n"
            + "Nenhuma acao externa critica sem aprovacao humana.\n\n"
            + "# Rotina de alinhamento\n\n"
            + f"{answers.get('meeting_cadence', 'Nao informado')}\n\n"
            + "# Observacoes\n\n"
            + f"{answers.get('notes', 'Sem observacoes adicionais.')}\n"
        )

    def _render_channel_file(self, frontmatter: dict, answers: dict, service: str) -> str:
        base = self._dump_frontmatter(frontmatter) + f"# Estado inicial do pilar {service}\n\n"
        if service == "makeads":
            return (
                base
                + "## Diretriz-mestra\n\n"
                + "O plano de midia gerado pela skill oficial `plano-de-midia-make`, versionada dentro do Make Brain, e a referencia principal do growth para campanhas.\n\n"
                + "## Verba de midia\n\n"
                + f"{answers.get('monthly_media_budget', 'Nao informado')}\n\n"
                + "## R1\n\n"
                + "A transcricao da R1 esta registrada no historico de onboarding e deve alimentar o plano de midia.\n"
            )
        if service == "social":
            return (
                base
                + "## Regra central do pilar\n\n"
                + "Social Media deve usar a mesma base de contexto global do cliente, sem silo separado de informacao.\n\n"
                + "## Entregaveis esperados\n\n"
                + "- `auditoria_social_inicial.md`\n"
                + "- `tutorial_conexao_meta_social.md`\n"
                + "- `briefing_social.md`\n"
                + "- `posts_iniciais.md`\n"
                + "- `posts_<mes><ano>.md`\n"
                + "- `relatorio_<mes><ano>.md`\n\n"
                + "## Governanca\n\n"
                + "Nenhuma postagem avanca sem aprovacao humana.\n"
            )
        if service == "web":
            return base + f"## Site principal\n\n{answers.get('website_url', 'Nao informado')}\n"
        if service == "seo":
            return base + "## Foco inicial\n\nMapear oportunidades organicas por regiao, oferta e intencao.\n"
        if service == "aeo":
            return base + "## Foco inicial\n\nExtrair FAQs e estruturar respostas curtas e confiaveis.\n"
        if service == "geo":
            return base + "## Foco inicial\n\nReforcar entidade da marca e ativos citaveis.\n"
        if service == "crm":
            return base + "## Foco inicial\n\nLer pipeline, SLA e gargalos de qualidade de lead.\n"
        if service == "mavi":
            return base + "## Foco inicial\n\nDesenhar persona, FAQ e regras de handoff.\n"
        return base + "## Foco inicial\n\nPilar registrado no onboarding.\n"

    def _render_onboarding_note(self, answers: dict) -> str:
        return (
            "## Resumo rapido\n\n"
            + f"- Cliente: {answers.get('client_name', 'Nao informado')}\n"
            + f"- Servicos contratados: {', '.join(answers.get('contracted_services', []))}\n"
            + f"- Meta 90 dias: {answers.get('primary_goal_90d', 'Nao informado')}\n"
            + f"- Verba de midia: {answers.get('monthly_media_budget', 'Nao informado')}\n\n"
            + "## Transcricao R1\n\n"
            + f"{answers.get('r1_transcript', 'Nao informada')}\n"
        )

    def _bullet_list(self, items: list | None) -> str:
        values = items or []
        if not values:
            return "- Nao informado\n"
        return "".join(f"- {item}\n" for item in values)
