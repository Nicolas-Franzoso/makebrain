from __future__ import annotations

from sqlalchemy import select
from sqlalchemy.orm import Session

from brain.connectors.meta import MetaConnector

from .context_service import ContextService
from .db_models import EventLogORM, IntegrationAccountORM


META_SOCIAL_PROVIDER = "meta-social"


class IntegrationService:
    def __init__(self, session: Session, context_service: ContextService | None = None):
        self.session = session
        self.context_service = context_service or ContextService()

    def upsert_meta_social_connection(
        self,
        client_id: str,
        access_token: str,
        instagram_business_account_id: str,
        meta_page_id: str | None = None,
        meta_business_id: str | None = None,
        instagram_handle: str | None = None,
        requested_by: str = "social-operator",
    ) -> dict:
        connector = MetaConnector(access_token=access_token)
        profile = connector.fetch_instagram_profile(instagram_business_account_id)

        row = self.session.execute(
            select(IntegrationAccountORM).where(
                IntegrationAccountORM.client_id == client_id,
                IntegrationAccountORM.provider == META_SOCIAL_PROVIDER,
            )
        ).scalar_one_or_none()

        payload = {
            "page_id": meta_page_id,
            "business_id": meta_business_id,
            "instagram_business_account_id": instagram_business_account_id,
            "instagram_handle": instagram_handle or profile.payload.get("username"),
            "access_token": access_token,
            "validated_profile": profile.payload,
            "connected_by": requested_by,
        }

        if row is None:
            row = IntegrationAccountORM(
                client_id=client_id,
                provider=META_SOCIAL_PROVIDER,
                account_ref=instagram_business_account_id,
                execution_profile="draft-write",
                secrets_ref=f"db://integration_accounts/{META_SOCIAL_PROVIDER}",
                metadata_json=payload,
            )
            self.session.add(row)
        else:
            row.account_ref = instagram_business_account_id
            row.execution_profile = "draft-write"
            row.secrets_ref = f"db://integration_accounts/{META_SOCIAL_PROVIDER}"
            row.metadata_json = payload

        self.session.add(
            EventLogORM(
                event_type="meta_social_connected",
                client_id=client_id,
                payload={
                    "provider": META_SOCIAL_PROVIDER,
                    "instagram_business_account_id": instagram_business_account_id,
                    "page_id": meta_page_id,
                    "connected_by": requested_by,
                },
            )
        )
        self.context_service.update_social_channel_connection_status(
            client_slug=client_id,
            instagram_business_account_id=instagram_business_account_id,
            meta_page_id=meta_page_id,
            instagram_handle=payload["instagram_handle"],
            connected_by=requested_by,
        )
        self.session.flush()
        return {
            "provider": META_SOCIAL_PROVIDER,
            "client_id": client_id,
            "instagram_business_account_id": instagram_business_account_id,
            "page_id": meta_page_id,
            "profile": profile.payload,
            "connected_by": requested_by,
            "status": "connected",
        }

    def get_meta_social_connection(self, client_id: str) -> dict | None:
        row = self.session.execute(
            select(IntegrationAccountORM).where(
                IntegrationAccountORM.client_id == client_id,
                IntegrationAccountORM.provider == META_SOCIAL_PROVIDER,
            )
        ).scalar_one_or_none()
        if row is None:
            return None
        metadata = dict(row.metadata_json or {})
        return {
            "integration_id": row.integration_id,
            "provider": row.provider,
            "client_id": row.client_id,
            "instagram_business_account_id": metadata.get("instagram_business_account_id") or row.account_ref,
            "page_id": metadata.get("page_id"),
            "business_id": metadata.get("business_id"),
            "instagram_handle": metadata.get("instagram_handle"),
            "access_token": metadata.get("access_token"),
            "validated_profile": metadata.get("validated_profile", {}),
        }
