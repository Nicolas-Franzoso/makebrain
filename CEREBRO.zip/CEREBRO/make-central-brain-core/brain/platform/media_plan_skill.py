from __future__ import annotations

from pathlib import Path


BUNDLED_MEDIA_PLAN_SKILL = Path(__file__).resolve().parents[1] / "skills" / "makeads" / "plano-de-midia-make" / "SKILL.md"
LEGACY_LOCAL_MEDIA_PLAN_SKILL = Path.home() / ".codex" / "skills" / "plano-de-midia-make" / "SKILL.md"


def resolve_media_plan_skill_path() -> Path:
    if BUNDLED_MEDIA_PLAN_SKILL.exists():
        return BUNDLED_MEDIA_PLAN_SKILL
    return LEGACY_LOCAL_MEDIA_PLAN_SKILL


def media_plan_skill_sources() -> dict[str, str | bool]:
    resolved = resolve_media_plan_skill_path()
    return {
        "resolved_path": str(resolved),
        "bundled_path": str(BUNDLED_MEDIA_PLAN_SKILL),
        "bundled_available": BUNDLED_MEDIA_PLAN_SKILL.exists(),
        "legacy_local_path": str(LEGACY_LOCAL_MEDIA_PLAN_SKILL),
        "legacy_local_available": LEGACY_LOCAL_MEDIA_PLAN_SKILL.exists(),
    }
