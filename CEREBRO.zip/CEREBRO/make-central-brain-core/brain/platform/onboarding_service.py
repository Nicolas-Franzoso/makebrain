from __future__ import annotations

from dataclasses import dataclass

from .onboarding_catalog import INTEGRATION_TUTORIALS, PROJECT_ONBOARDING_SECTIONS, STAGE_GUIDES


SERVICE_AGENT_MAP = {
    "makeads": ["makeads-planner-agent", "makeads-performance-agent", "makeads-creative-agent", "makeads-expansion-agent"],
    "social": ["social-onboarding-agent", "social-strategy-agent", "social-calendar-agent", "social-copy-agent", "social-listening-agent", "social-repurpose-agent", "social-reporting-agent"],
    "web": ["web-architecture-agent", "cro-agent", "tracking-web-agent", "ux-copy-agent"],
    "seo": ["seo-technical-agent", "seo-strategy-agent", "seo-briefing-agent", "seo-monitoring-agent"],
    "aeo": ["aeo-answer-agent", "aeo-schema-agent", "aeo-snippet-agent"],
    "geo": ["geo-presence-agent", "geo-citable-content-agent", "geo-entity-agent"],
    "crm": ["crm-pipeline-agent", "crm-reactivation-agent", "crm-attribution-agent", "crm-sla-agent"],
    "mavi": ["mavi-conversation-design-agent", "mavi-knowledge-agent", "mavi-optimization-agent", "mavi-safety-agent"],
}


CORE_AGENTS = [
    "project-onboarding-agent",
    "memory-context-agent",
    "research-intelligence-agent",
    "qa-compliance-agent",
    "approval-governance-agent",
]


@dataclass
class ActivationDecision:
    stage: str
    status: str
    reasons: list[str]
    next_questions: list[str]
    active_agents: list[str]
    blocked_agents: list[str]


class OnboardingService:
    def get_project_template(self) -> dict:
        return {
            "title": "Onboarding de novo projeto",
            "description": "Questionario mestre para ativar os agentes certos na hora certa.",
            "sections": PROJECT_ONBOARDING_SECTIONS,
            "tutorials": INTEGRATION_TUTORIALS,
        }

    def get_stage_guide(self, stage: str) -> dict:
        if stage not in STAGE_GUIDES:
            raise KeyError(stage)
        guide = STAGE_GUIDES[stage]
        return {
            "stage": stage,
            "title": guide["title"],
            "goal": guide["goal"],
            "required_answers": guide["required_answers"],
            "optional_answers": guide["optional_answers"],
            "next_questions": guide["next_questions"],
            "tutorials": self._stage_tutorials(stage),
        }

    def build_activation_plan(self, answers: dict) -> dict:
        contracted_services = answers.get("contracted_services", []) or []
        missing_global = self._missing_global_requirements(answers)

        decisions = []
        activated_agents = list(CORE_AGENTS)
        blocked_agents = []

        if missing_global:
            blocked_agents.extend(self._agents_for_services(contracted_services))

        for service in contracted_services:
            decision = self._evaluate_stage(service, answers, missing_global)
            decisions.append(decision)
            activated_agents.extend(decision.active_agents)
            blocked_agents.extend(decision.blocked_agents)

        activated_agents = sorted(set(activated_agents))
        blocked_agents = sorted(set(blocked_agents) - set(activated_agents))

        return {
            "summary": {
                "client_name": answers.get("client_name"),
                "contracted_services": contracted_services,
                "global_status": "ready" if not missing_global else "missing-core-context",
                "missing_global_requirements": missing_global,
            },
            "growth_workflow": {
                "required": "makeads" in contracted_services,
                "first_skill": "onboarding-media-plan" if "makeads" in contracted_services else None,
                "rule": "Quando MakeADS estiver contratado, o plano de midia e a diretriz inicial do processo de growth.",
            },
            "recommended_context_files": self._recommended_context_files(contracted_services),
            "activated_agents": activated_agents,
            "blocked_agents": blocked_agents,
            "stage_decisions": [decision.__dict__ for decision in decisions],
            "recommended_next_steps": self._recommended_next_steps(missing_global, decisions),
            "tutorials_to_show_now": self._suggested_tutorials(answers, contracted_services),
        }

    def _missing_global_requirements(self, answers: dict) -> list[str]:
        required = [
            "client_name",
            "client_slug",
            "contracted_services",
            "primary_goal_90d",
            "success_metrics",
            "main_offers",
            "ticket_range",
            "sales_cycle",
            "sales_capacity",
            "r1_transcript",
            "competitors",
            "target_regions",
            "brand_tone",
            "existing_assets",
            "approval_contacts",
            "meeting_cadence",
            "content_assets_ready",
        ]
        missing = []
        for key in required:
            value = answers.get(key)
            if value in (None, "", [], {}):
                missing.append(key)
        return missing

    def _evaluate_stage(self, service: str, answers: dict, missing_global: list[str]) -> ActivationDecision:
        guide = STAGE_GUIDES.get(service)
        agents = SERVICE_AGENT_MAP.get(service, [])
        if guide is None:
            return ActivationDecision(service, "inactive", ["Etapa nao mapeada."], [], [], agents)

        missing_required = [key for key in guide["required_answers"] if answers.get(key) in (None, "", [], {})]
        reasons = []
        if missing_global:
            reasons.append("O onboarding ainda nao coletou o contexto base obrigatorio.")
        if missing_required:
            reasons.append("Faltam respostas essenciais da etapa: " + ", ".join(missing_required))

        if missing_global or missing_required:
            return ActivationDecision(
                stage=service,
                status="blocked",
                reasons=reasons,
                next_questions=guide["next_questions"],
                active_agents=[],
                blocked_agents=agents,
            )

        active_agents, blocked_agents, access_reasons = self._split_agents_by_stage(service, answers)
        reasons.extend(access_reasons)
        status = "active" if active_agents and not blocked_agents else "partial" if active_agents else "blocked"
        return ActivationDecision(
            stage=service,
            status=status,
            reasons=reasons or ["Etapa pronta para ativacao."],
            next_questions=[] if status == "active" else guide["next_questions"],
            active_agents=active_agents,
            blocked_agents=blocked_agents,
        )

    def _split_agents_by_stage(self, service: str, answers: dict) -> tuple[list[str], list[str], list[str]]:
        active: list[str] = []
        blocked: list[str] = []
        reasons: list[str] = []

        if service == "makeads":
            if answers.get("monthly_media_budget") not in (None, "", 0):
                active.append("makeads-planner-agent")
            else:
                blocked.append("makeads-planner-agent")
                reasons.append("Definir verba de midia paga para liberar o planner de campanhas.")

            if answers.get("content_assets_ready"):
                active.append("makeads-creative-agent")
            else:
                blocked.append("makeads-creative-agent")
                reasons.append("Criativo pago precisa de ativos visuais ou briefing criativo minimo.")

            if answers.get("meta_access_ready"):
                active.extend(["makeads-performance-agent", "makeads-expansion-agent"])
            else:
                blocked.extend(["makeads-performance-agent", "makeads-expansion-agent"])
                reasons.append("Sem acesso da Meta, monitoramento e expansao ficam bloqueados.")

        elif service == "social":
            active.extend(["social-onboarding-agent", "social-strategy-agent", "social-copy-agent"])
            if answers.get("content_assets_ready"):
                active.append("social-calendar-agent")
                active.append("social-repurpose-agent")
            else:
                blocked.extend(["social-calendar-agent", "social-repurpose-agent"])
                reasons.append("Calendario e reciclador de conteudo pedem ativos criativos disponiveis.")

            if answers.get("social_access_ready"):
                active.append("social-listening-agent")
                active.append("social-reporting-agent")
            else:
                blocked.extend(["social-listening-agent", "social-reporting-agent"])
                reasons.append("Listening e relatorio social precisam de acesso aos perfis sociais e conexao Meta.")

        elif service == "web":
            active.extend(["web-architecture-agent", "ux-copy-agent"])
            if answers.get("domain_or_host_access"):
                active.extend(["cro-agent", "tracking-web-agent"])
            else:
                blocked.extend(["cro-agent", "tracking-web-agent"])
                reasons.append("Web/CRO tecnico requer acesso ao site, CMS ou responsavel tecnico.")

        elif service == "seo":
            active.extend(["seo-strategy-agent", "seo-briefing-agent"])
            if answers.get("domain_or_host_access"):
                active.append("seo-technical-agent")
            else:
                blocked.append("seo-technical-agent")
                reasons.append("SEO tecnico requer acesso ou responsavel tecnico confirmado.")
            if answers.get("search_console_ready") or answers.get("ga4_property_id"):
                active.append("seo-monitoring-agent")
            else:
                blocked.append("seo-monitoring-agent")
                reasons.append("Monitoramento SEO precisa de Search Console ou GA4.")

        elif service == "aeo":
            if answers.get("faq_or_sales_scripts"):
                active.extend(["aeo-answer-agent", "aeo-snippet-agent"])
            else:
                blocked.extend(["aeo-answer-agent", "aeo-snippet-agent"])
                reasons.append("AEO precisa de FAQ, perguntas recorrentes ou scripts comerciais.")
            if answers.get("cms_platform") not in (None, "", "nao possui"):
                active.append("aeo-schema-agent")
            else:
                blocked.append("aeo-schema-agent")
                reasons.append("Schema e entidades precisam de CMS ou superficie editavel.")

        elif service == "geo":
            active.append("geo-presence-agent")
            if answers.get("existing_assets"):
                active.extend(["geo-citable-content-agent", "geo-entity-agent"])
            else:
                blocked.extend(["geo-citable-content-agent", "geo-entity-agent"])
                reasons.append("GEO precisa de ativos de prova, conteudo ou paginas-base.")

        elif service == "crm":
            if answers.get("makecrm_enabled"):
                active.append("crm-pipeline-agent")
                active.append("crm-sla-agent")
            else:
                blocked.extend(["crm-pipeline-agent", "crm-sla-agent"])
                reasons.append("CRM contratado, mas o uso do MakeCRM ainda nao foi confirmado.")

            if answers.get("makecrm_api_key"):
                active.extend(["crm-reactivation-agent", "crm-attribution-agent"])
            else:
                blocked.extend(["crm-reactivation-agent", "crm-attribution-agent"])
                reasons.append("Chave do MakeCRM ausente para automacao de pipeline e atribuicao.")

        elif service == "mavi":
            active.extend(["mavi-conversation-design-agent", "mavi-safety-agent"])
            if answers.get("faq_or_sales_scripts"):
                active.append("mavi-knowledge-agent")
            else:
                blocked.append("mavi-knowledge-agent")
                reasons.append("Mavi precisa de FAQs, scripts ou regras de qualificacao.")
            if answers.get("conversation_history_available"):
                active.append("mavi-optimization-agent")
            else:
                blocked.append("mavi-optimization-agent")
                reasons.append("Otimizacao da Mavi precisa de historico real de conversa.")

        else:
            blocked.extend(SERVICE_AGENT_MAP.get(service, []))
            reasons.append("Servico sem regras de ativacao cadastradas.")

        return sorted(set(active)), sorted(set(blocked) - set(active)), reasons

    def _recommended_next_steps(self, missing_global: list[str], decisions: list[ActivationDecision]) -> list[str]:
        steps = []
        if missing_global:
            steps.append("Completar primeiro o contexto base obrigatorio antes de tentar ativar especialistas.")
        makeads_decision = next((decision for decision in decisions if decision.stage == "makeads"), None)
        if makeads_decision and makeads_decision.status in {"active", "partial"}:
            steps.append("Growth: rodar primeiro a skill `onboarding-media-plan` para gerar o plano de midia diretor das campanhas.")
        blocked = [decision for decision in decisions if decision.status != "active"]
        if blocked:
            steps.append("Resolver primeiro as etapas bloqueadas com menos dependencias para ganhar velocidade.")
            for decision in blocked[:3]:
                steps.append(f"{decision.stage}: {decision.reasons[0]}")
        else:
            steps.append("Todos os pilares contratados estao prontos para ativacao inicial.")
            steps.append("Rodar indexacao do contexto e gerar fila do dia com o Maestro.")
        return steps

    def _suggested_tutorials(self, answers: dict, contracted_services: list[str]) -> list[dict]:
        keys = set()
        if "makeads" in contracted_services:
            keys.update({"meta", "google_ads"})
        if "crm" in contracted_services:
            keys.add("makecrm")
        if any(service in contracted_services for service in ("web", "seo", "aeo", "geo")):
            keys.update({"website", "ga4", "search_console"})
        if "mavi" in contracted_services:
            keys.add("mavi")

        if answers.get("meta_access_ready") is False:
            keys.add("meta")
        if answers.get("makecrm_enabled") is True and not answers.get("makecrm_api_key"):
            keys.add("makecrm")
        return [{"key": key, **INTEGRATION_TUTORIALS[key]} for key in sorted(keys)]

    def _stage_tutorials(self, stage: str) -> list[dict]:
        mapping = {
            "makeads": ["meta", "google_ads"],
            "social": ["meta"],
            "web": ["website", "ga4"],
            "seo": ["website", "ga4", "search_console"],
            "aeo": ["website"],
            "geo": ["website", "search_console"],
            "crm": ["makecrm"],
            "mavi": ["mavi"],
        }
        return [{"key": key, **INTEGRATION_TUTORIALS[key]} for key in mapping.get(stage, [])]

    def _agents_for_services(self, services: list[str]) -> list[str]:
        agents = []
        for service in services:
            agents.extend(SERVICE_AGENT_MAP.get(service, []))
        return agents

    def _recommended_context_files(self, services: list[str]) -> list[str]:
        files = [
            "00_profile.md",
            "01_brand_voice.md",
            "02_business_model.md",
            "03_offer_stack.md",
            "05_sales_crm.md",
            "06_mavi.md",
            "09_rules_and_constraints.md",
        ]
        if services:
            files.append("07_history/daily/<date>/<timestamp>-onboarding.md")
        if "makeads" in services:
            files.append("04_channels/makeads.md")
        if "social" in services:
            files.append("04_channels/social.md")
        if "web" in services:
            files.append("04_channels/web.md")
        if "seo" in services:
            files.append("04_channels/seo.md")
        if "aeo" in services:
            files.append("04_channels/aeo.md")
        if "geo" in services:
            files.append("04_channels/geo.md")
        return files
