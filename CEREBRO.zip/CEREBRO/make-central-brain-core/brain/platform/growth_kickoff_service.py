from __future__ import annotations

from sqlalchemy.orm import Session

from .artifact_service import ArtifactService
from .context_service import ContextService
from .db_models import EventLogORM
from .job_queue import JobQueue


class GrowthKickoffService:
    def __init__(self, session: Session, context_service: ContextService | None = None):
        self.session = session
        self.context_service = context_service or ContextService()

    def finalize_media_plan_job(
        self,
        job_id: str,
        media_plan_content: str,
        plan_summary: str,
        approved_by: str,
    ) -> dict:
        queue = JobQueue(self.session)
        job = queue.get(job_id)
        if job.skill_id != "onboarding-media-plan":
            raise ValueError("O job informado nao e um onboarding-media-plan.")

        artifact_path = self.context_service.publish_artifact(
            client_slug=job.client_id,
            artifact_type="media-plan",
            title="Plano de Midia Inicial Aprovado",
            body=media_plan_content,
            metadata={
                "approved_by": approved_by,
                "source_job_id": job.job_id,
                "skill_id": job.skill_id,
            },
        )
        channel_path = self.context_service.update_makeads_channel_from_media_plan(
            client_slug=job.client_id,
            plan_summary=plan_summary,
            artifact_path=str(artifact_path),
            approved_by=approved_by,
        )
        artifact = ArtifactService(self.session).create(
            client_id=job.client_id,
            artifact_type="media-plan",
            producer_agent=job.agent_id,
            source_jobs=[job.job_id],
            source_context_sha=job.context_sha,
            storage_ref=str(artifact_path),
        )
        queue.complete(job.job_id)
        self.session.add(
            EventLogORM(
                event_type="growth.media_plan_published",
                client_id=job.client_id,
                payload={
                    "job_id": job.job_id,
                    "artifact_id": artifact.artifact_id,
                    "artifact_path": str(artifact_path),
                    "makeads_channel_path": str(channel_path),
                    "approved_by": approved_by,
                },
            )
        )
        return {
            "job_id": job.job_id,
            "client_id": job.client_id,
            "artifact": artifact.model_dump(mode="json"),
            "artifact_path": str(artifact_path),
            "makeads_channel_path": str(channel_path),
            "approved_by": approved_by,
            "status": "published",
        }

