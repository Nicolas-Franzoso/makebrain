from __future__ import annotations

import re
from datetime import datetime
from uuid import uuid4
from pathlib import Path

from sqlalchemy.orm import Session

from .bootstrap_service import OnboardingBootstrapService
from .db_models import ConversationSessionORM, EventLogORM
from .media_plan_skill import media_plan_skill_sources
from .onboarding_catalog import PROJECT_ONBOARDING_SECTIONS
from .onboarding_service import OnboardingService


FIELD_ALIASES = {
    "client_name": ["cliente", "nome", "empresa", "nome do cliente"],
    "client_slug": ["slug", "identificador"],
    "timezone": ["timezone", "fuso", "fuso horario"],
    "owners": ["owners", "responsaveis", "responsáveis", "donos da conta"],
    "contracted_services": ["servicos", "serviços", "produtos contratados", "pilares contratados"],
    "primary_goal_90d": ["meta", "objetivo", "meta 90 dias"],
    "success_metrics": ["metricas", "métricas", "kpis"],
    "monthly_investment_total": ["investimento mensal total", "investimento total"],
    "monthly_media_budget": ["verba de midia", "verba de mídia", "investimento em midia", "orcamento de anuncios"],
    "main_offers": ["ofertas", "produtos principais", "servicos principais"],
    "ticket_range": ["ticket", "ticket medio", "ticket médio"],
    "sales_cycle": ["ciclo de vendas", "tempo de fechamento"],
    "sales_capacity": ["capacidade comercial", "capacidade de atendimento", "estrutura comercial"],
    "approval_sla": ["sla de aprovacao", "tempo de aprovacao"],
    "r1_transcript": ["r1", "transcricao da r1", "transcrição da r1"],
    "competitors": ["concorrentes", "competidores"],
    "target_regions": ["regioes", "regiões", "cidades", "areas atendidas"],
    "brand_tone": ["tom de voz", "tom", "linguagem da marca"],
    "compliance_constraints": ["compliance", "restricoes", "restrições"],
    "existing_assets": ["ativos", "materiais", "ativos existentes"],
    "website_url": ["site", "url do site"],
    "cms_platform": ["cms", "plataforma do site"],
    "meta_access_ready": ["meta conectada", "acesso meta", "meta pronta"],
    "meta_business_id": ["business manager", "business manager id", "bm id"],
    "meta_ad_account_id": ["conta meta", "conta de anuncios", "id conta meta"],
    "meta_pixel_id": ["pixel meta", "pixel id", "dataset meta"],
    "meta_page_id": ["page id", "facebook page id", "id da pagina meta", "pagina facebook id"],
    "instagram_business_account_id": ["instagram business account id", "ig business account id", "id instagram business", "instagram account id"],
    "instagram_handle": ["instagram handle", "arroba instagram", "usuario instagram", "@instagram"],
    "meta_access_token": ["token meta", "access token meta", "meta access token", "token da meta"],
    "google_ads_customer_id": ["google ads", "customer id google ads"],
    "ga4_property_id": ["ga4", "property ga4"],
    "search_console_ready": ["search console", "search console conectado"],
    "makecrm_enabled": ["usa makecrm", "makecrm"],
    "makecrm_api_key": ["chave makecrm", "api makecrm"],
    "social_access_ready": ["acesso social", "acesso aos perfis"],
    "mavi_channels": ["canais da mavi", "mavi canais"],
    "conversation_history_available": ["historico de conversa", "histórico de conversa"],
    "domain_or_host_access": ["acesso ao site", "acesso cms", "acesso hospedagem"],
    "approval_contacts": ["aprovadores", "quem aprova", "contatos de aprovacao"],
    "meeting_cadence": ["cadencia", "cadência", "ritmo de reuniao", "reunioes"],
    "content_assets_ready": ["ativos criativos prontos", "material criativo pronto"],
    "faq_or_sales_scripts": ["faq", "script comercial", "scripts de vendas"],
    "notes": ["observacoes", "observações", "notas"],
}


class ConversationService:
    def __init__(self, session: Session, context_root: Path | None = None):
        self.session = session
        self.onboarding = OnboardingService()
        self.questions = self._flatten_questions()
        self.context_root = context_root

    def handle_message(self, message: str, session_id: str | None = None, author: str = "user") -> dict:
        conversation = self._get_or_create(session_id)
        self._append_message(conversation, "user", message, author)

        if not message.strip():
            response = self._welcome_or_next_question(conversation)
            self._append_message(conversation, "assistant", response["reply"], "system")
            self.session.flush()
            return response

        answers = dict(conversation.answers_json or {})
        updated_fields = self._extract_answers(message, answers, conversation.pending_question_id)
        answers.update(updated_fields)
        conversation.answers_json = answers
        integration_note = self._maybe_connect_meta_social(conversation, answers, updated_fields)
        social_report_response = self._maybe_generate_social_report(conversation, message)

        if social_report_response is not None:
            response = social_report_response
        elif conversation.stage == "awaiting_media_plan_generation":
            response = self._handle_media_plan_generation_stage(conversation, message, answers)
        elif conversation.stage == "awaiting_media_plan_review":
            response = self._handle_media_plan_review_stage(conversation, message, answers)
        elif conversation.stage == "awaiting_media_plan_summary":
            response = self._handle_media_plan_summary(conversation, message, answers)
        elif conversation.stage == "active":
            response = self._handle_active_stage(conversation, answers, updated_fields)
        else:
            response = self._handle_onboarding_flow(conversation, answers, updated_fields)

        if integration_note:
            response["reply"] = f"{integration_note}\n\n{response['reply']}"
        self._append_message(conversation, "assistant", response["reply"], "system")
        self.session.flush()
        return response

    def _handle_onboarding_flow(self, conversation: ConversationSessionORM, answers: dict, updated_fields: dict) -> dict:
        next_question = self._next_question(answers)
        if next_question is None:
            bootstrap = OnboardingBootstrapService().run(answers, requested_by="conversation", context_root=self.context_root)
            conversation.client_id = bootstrap["client_slug"]
            conversation.stage = "awaiting_media_plan_generation" if bootstrap["growth_process"]["media_plan_required"] else "active"
            conversation.status = "bootstrapped"
            conversation.pending_question_id = None
            conversation.metadata_json = {
                **(conversation.metadata_json or {}),
                "bootstrap": bootstrap,
                "pending_media_plan_job_id": self._find_job_id(bootstrap, "onboarding-media-plan"),
            }
            reply = self._build_bootstrap_reply(bootstrap)
            return {
                "session_id": conversation.session_id,
                "reply": reply,
                "stage": conversation.stage,
                "status": conversation.status,
                "answers_updated": list(updated_fields),
                "bootstrap": bootstrap,
            }

        conversation.pending_question_id = next_question["id"]
        conversation.status = "collecting"
        reply = self._question_text(next_question)
        return {
            "session_id": conversation.session_id,
            "reply": reply,
            "stage": conversation.stage,
            "status": conversation.status,
            "answers_updated": list(updated_fields),
            "pending_question_id": next_question["id"],
        }

    def _handle_media_plan_generation_stage(self, conversation: ConversationSessionORM, message: str, answers: dict) -> dict:
        text = message.strip()
        if len(text) > 120 or "<html" in text.lower() or "# " in text:
            conversation.metadata_json = {
                **(conversation.metadata_json or {}),
                "pending_media_plan_content": text,
            }
            conversation.stage = "awaiting_media_plan_review"
            return {
                "session_id": conversation.session_id,
                "reply": "Recebi o plano de midia gerado. Antes de seguir, ele esta aprovado ou voce quer mudancas? Se quiser ajustes, escreva em texto comum o que precisa mudar.",
                "stage": conversation.stage,
                "status": conversation.status,
            }

        approval_words = ("aprovado", "pode seguir", "segue", "aprovei")
        if any(word in text.lower() for word in approval_words):
            return {
                "session_id": conversation.session_id,
                "reply": "Antes de aprovar eu preciso receber o conteudo final do plano de midia gerado com a skill oficial `plano-de-midia-make`. Cole o plano aqui.",
                "stage": conversation.stage,
                "status": conversation.status,
            }

        return {
            "session_id": conversation.session_id,
            "reply": "Como MakeADS esta contratado, o proximo passo obrigatorio e gerar o plano de midia usando a skill oficial `plano-de-midia-make`, que ja esta incorporada ao Make Brain. Use a transcricao da R1 como base e, quando a versao gerada estiver pronta, cole o conteudo aqui para eu abrir a revisao.",
            "stage": conversation.stage,
            "status": conversation.status,
        }

    def _handle_media_plan_review_stage(self, conversation: ConversationSessionORM, message: str, answers: dict) -> dict:
        text = message.strip()
        lowered = text.lower()

        if len(text) > 120 or "<html" in lowered or "# " in text:
            conversation.metadata_json = {
                **(conversation.metadata_json or {}),
                "pending_media_plan_content": text,
            }
            return {
                "session_id": conversation.session_id,
                "reply": "Atualizei a versao do plano recebida. Esta versao esta aprovada ou voce quer mais mudancas?",
                "stage": conversation.stage,
                "status": conversation.status,
            }

        approval_words = ("aprovado", "pode seguir", "segue", "aprovei", "ok")
        if any(word in lowered for word in approval_words):
            conversation.stage = "awaiting_media_plan_summary"
            return {
                "session_id": conversation.session_id,
                "reply": "Perfeito. Agora me mande um resumo executivo curto com a diretriz principal das campanhas para eu publicar o plano no contexto e fechar o kickoff de growth.",
                "stage": conversation.stage,
                "status": conversation.status,
            }

        change_words = ("mudar", "mudanca", "mudancas", "ajuste", "ajustes", "nao aprovado", "não aprovado", "revisar")
        if any(word in lowered for word in change_words):
            metadata = dict(conversation.metadata_json or {})
            feedback_log = list(metadata.get("media_plan_feedback", []))
            feedback_log.append(text)
            metadata["media_plan_feedback"] = feedback_log
            conversation.metadata_json = metadata
            conversation.stage = "awaiting_media_plan_generation"
            return {
                "session_id": conversation.session_id,
                "reply": "Anotei as mudancas pedidas. Gere a nova versao usando a skill oficial `plano-de-midia-make` e cole aqui quando estiver pronta para nova revisao.",
                "stage": conversation.stage,
                "status": conversation.status,
            }

        return {
            "session_id": conversation.session_id,
            "reply": "Me diga se esta versao do plano esta aprovada ou escreva quais mudancas sao necessarias. Se preferir, pode colar uma versao revisada do plano aqui.",
            "stage": conversation.stage,
            "status": conversation.status,
        }

    def _handle_media_plan_summary(self, conversation: ConversationSessionORM, message: str, answers: dict) -> dict:
        metadata = dict(conversation.metadata_json or {})
        bootstrap = metadata.get("bootstrap", {})
        job_id = metadata.get("pending_media_plan_job_id")
        media_plan_content = metadata.get("pending_media_plan_content")
        if not job_id or not media_plan_content:
            conversation.stage = "active"
            return {
                "session_id": conversation.session_id,
                "reply": "Nao consegui localizar o job do plano de midia. O onboarding foi concluido, mas preciso reabrir o kickoff de growth.",
                "stage": conversation.stage,
                "status": "attention",
            }

        from brain.db import session_scope
        from .growth_kickoff_service import GrowthKickoffService
        from .context_service import ContextService

        with session_scope() as inner_session:
            result = GrowthKickoffService(inner_session, ContextService(self.context_root)).finalize_media_plan_job(
                job_id=job_id,
                media_plan_content=media_plan_content,
                plan_summary=message.strip(),
                approved_by="conversation-user",
            )

        conversation.stage = "active"
        conversation.status = "ready"
        metadata["published_media_plan"] = result
        conversation.metadata_json = metadata
        return {
            "session_id": conversation.session_id,
            "reply": "Plano de midia publicado no contexto e kickoff de growth fechado. A diretriz de MakeADS foi atualizada e os proximos agentes agora podem seguir a partir desse plano.",
            "stage": conversation.stage,
            "status": conversation.status,
            "growth_publish": result,
            "bootstrap": bootstrap,
        }

    def _handle_active_stage(self, conversation: ConversationSessionORM, answers: dict, updated_fields: dict) -> dict:
        return {
            "session_id": conversation.session_id,
            "reply": "O cliente ja esta ativo no ecossistema. Pode me enviar novos acessos, aprovacoes, pedidos de execucao ou solicitar analises e relatorios.",
            "stage": conversation.stage,
            "status": conversation.status,
            "answers_updated": list(updated_fields),
        }

    def _welcome_or_next_question(self, conversation: ConversationSessionORM) -> dict:
        answers = conversation.answers_json or {}
        next_question = self._next_question(answers)
        if next_question is None:
            reply = "O contexto base ja foi coletado. Se quiser, me mande aprovacoes, ajustes ou o plano de midia aprovado."
            conversation.pending_question_id = None
        else:
            conversation.pending_question_id = next_question["id"]
            reply = (
                "Vou conduzir o onboarding inteiro por conversa comum. "
                + self._question_text(next_question)
            )
        return {
            "session_id": conversation.session_id,
            "reply": reply,
            "stage": conversation.stage,
            "status": conversation.status,
            "pending_question_id": conversation.pending_question_id,
        }

    def _get_or_create(self, session_id: str | None) -> ConversationSessionORM:
        if session_id:
            conversation = self.session.get(ConversationSessionORM, session_id)
            if conversation is not None:
                return conversation
        conversation = ConversationSessionORM(session_id=(session_id or uuid4().hex))
        self.session.add(conversation)
        self.session.flush()
        return conversation

    def _append_message(self, conversation: ConversationSessionORM, role: str, message: str, author: str) -> None:
        log = list(conversation.message_log or [])
        log.append({"role": role, "message": message, "author": author})
        conversation.message_log = log[-50:]

    def _flatten_questions(self) -> list[dict]:
        items = []
        for section in PROJECT_ONBOARDING_SECTIONS:
            for question in section["questions"]:
                items.append({**question, "section_id": section["id"], "section_title": section["title"]})
        return items

    def _next_question(self, answers: dict) -> dict | None:
        priority_question = self._priority_question(answers)
        if priority_question is not None:
            return priority_question
        for question in self.questions:
            if not self._is_relevant(question["id"], answers):
                continue
            if question.get("required") and answers.get(question["id"]) in (None, "", [], {}):
                return question
        return None

    def _priority_question(self, answers: dict) -> dict | None:
        if answers.get("client_name") and answers.get("client_slug") and answers.get("contracted_services") and not answers.get("r1_transcript"):
            return self._question_by_id("r1_transcript")
        return None

    def _is_relevant(self, question_id: str, answers: dict) -> bool:
        services = answers.get("contracted_services", []) or []
        if question_id.startswith("meta_") or question_id in {"instagram_business_account_id", "instagram_handle", "monthly_media_budget"}:
            return any(service in services for service in ("makeads", "social")) or not services
        if question_id in {"google_ads_customer_id"}:
            return "makeads" in services or not services
        if question_id in {"social_access_ready"}:
            return "social" in services or not services
        if question_id in {"website_url", "cms_platform", "ga4_property_id", "search_console_ready", "domain_or_host_access"}:
            return any(service in services for service in ("web", "seo", "aeo", "geo")) or not services
        if question_id in {"makecrm_enabled", "makecrm_api_key"}:
            return "crm" in services or not services
        if question_id in {"mavi_channels", "conversation_history_available"}:
            return "mavi" in services or not services
        return True

    def _extract_answers(self, message: str, answers: dict, pending_question_id: str | None) -> dict:
        updated: dict = {}

        key_value_matches = self._extract_key_value_pairs(message)
        updated.update(key_value_matches)

        if pending_question_id and pending_question_id not in updated:
            question = self._question_by_id(pending_question_id)
            if question is not None:
                parsed = self._parse_answer(question, message)
                if parsed not in (None, "", [], {}):
                    updated[pending_question_id] = parsed

        return updated

    def _extract_key_value_pairs(self, message: str) -> dict:
        updated = {}
        for raw_line in message.splitlines():
            if ":" not in raw_line:
                continue
            raw_key, raw_value = raw_line.split(":", 1)
            normalized_key = raw_key.strip().lower()
            value = raw_value.strip()
            if not value:
                continue
            for field_id, aliases in FIELD_ALIASES.items():
                if normalized_key == field_id or normalized_key in aliases:
                    question = self._question_by_id(field_id)
                    if question is not None:
                        updated[field_id] = self._parse_answer(question, value)
                    break
        return updated

    def _parse_answer(self, question: dict, raw_value: str):
        value = raw_value.strip()
        qtype = question.get("type", "text")
        if qtype == "boolean":
            lowered = value.lower()
            if any(token in lowered for token in ("sim", "yes", "true", "tem", "conectado", "pronto", "ok")):
                return True
            if any(token in lowered for token in ("nao", "não", "no", "false", "sem")):
                return False
            return value
        if qtype in {"list", "multi-select"}:
            items = [item.strip() for item in re.split(r"[,;\n]+", value) if item.strip()]
            if qtype == "multi-select" and question.get("options"):
                normalized = []
                lowered_items = [item.lower() for item in items]
                for option in question["options"]:
                    if option.lower() in lowered_items or option.lower() in value.lower():
                        normalized.append(option)
                return normalized or items
            return items
        if qtype == "currency":
            match = re.search(r"R\$\s*[\d\.\,]+", value, flags=re.IGNORECASE)
            return match.group(0) if match else value
        return value

    def _question_by_id(self, question_id: str) -> dict | None:
        for question in self.questions:
            if question["id"] == question_id:
                return question
        return None

    def _question_text(self, question: dict) -> str:
        help_text = question.get("help_text")
        if help_text:
            return f"{question['label']} {help_text}"
        return question["label"]

    def _build_bootstrap_reply(self, bootstrap: dict) -> str:
        sources = media_plan_skill_sources()
        message = "Onboarding base concluido e cliente ativado no sistema."
        if bootstrap["growth_process"]["media_plan_required"]:
            message += " Como MakeADS esta contratado, o kickoff de growth ja foi aberto e o primeiro job obrigatorio e o plano de midia. Esse plano deve ser gerado com a skill oficial `plano-de-midia-make`, versionada dentro do Make Brain, usando a transcricao da R1 como base."
            if sources["bundled_available"]:
                message += f" A fonte atual dessa skill e `{sources['bundled_path']}`."
            message += " Quando a versao gerada estiver pronta, cole aqui o conteudo para eu abrir a revisao e perguntar se esta aprovado ou quais mudancas precisam ser feitas."
        else:
            message += " Os agentes iniciais ja podem seguir com os jobs gerados."
        return message

    def _find_job_id(self, bootstrap: dict, skill_id: str) -> str | None:
        for job in bootstrap.get("initial_jobs", []):
            if job.get("skill_id") == skill_id:
                return job.get("job_id")
        return None

    def _maybe_connect_meta_social(self, conversation: ConversationSessionORM, answers: dict, updated_fields: dict) -> str | None:
        relevant = {"meta_access_token", "instagram_business_account_id", "meta_page_id", "instagram_handle"}
        if not (relevant & set(updated_fields)):
            return None
        if "social" not in (answers.get("contracted_services", []) or []):
            return None

        client_id = conversation.client_id or answers.get("client_slug")
        if not client_id:
            return "Recebi dados da Meta para Social, mas ainda preciso do slug do cliente antes de salvar a integracao."

        token = answers.get("meta_access_token")
        ig_user_id = answers.get("instagram_business_account_id")
        missing = []
        if not token:
            missing.append("meta_access_token")
        if not ig_user_id:
            missing.append("instagram_business_account_id")
        if missing:
            return "Recebi parte da conexao Meta de Social. Ainda preciso de " + ", ".join(missing) + " para validar a Graph API."

        from .integration_service import IntegrationService

        result = IntegrationService(self.session).upsert_meta_social_connection(
            client_id=client_id,
            access_token=token,
            instagram_business_account_id=ig_user_id,
            meta_page_id=answers.get("meta_page_id"),
            meta_business_id=answers.get("meta_business_id"),
            instagram_handle=answers.get("instagram_handle"),
            requested_by="conversation-user",
        )
        answers["meta_access_ready"] = True
        answers["social_access_ready"] = True
        conversation.answers_json = answers
        metadata = dict(conversation.metadata_json or {})
        metadata["meta_social_connection"] = result
        conversation.metadata_json = metadata
        return (
            "Conexao real da Meta para Social validada e salva no control plane. "
            + f"Instagram conectado: `{result['profile'].get('username', answers.get('instagram_handle', ig_user_id))}`."
        )

    def _maybe_generate_social_report(self, conversation: ConversationSessionORM, message: str) -> dict | None:
        lowered = message.lower()
        if not any(trigger in lowered for trigger in ("relatorio social", "relatório social", "relatorio mensal", "relatório mensal")):
            return None
        if not conversation.client_id:
            return None

        period_match = re.search(r"\b([a-z]+20\d{2}|\d{4}-\d{2})\b", lowered)
        period = period_match.group(1) if period_match else self._default_period_label()

        from brain.db import session_scope
        from .context_service import ContextService
        from .social_reporting_service import SocialReportingService

        with session_scope() as inner_session:
            result = SocialReportingService(inner_session, ContextService(self.context_root)).generate_monthly_report(
                client_id=conversation.client_id,
                period_label=period,
                requested_by="conversation-user",
            )

        return {
            "session_id": conversation.session_id,
            "reply": f"Relatorio mensal de Social gerado com dados da Meta e salvo no contexto. Artefato: `{result['artifact_path']}`. Aprovacao criada: `{result['approval_id']}`.",
            "stage": conversation.stage,
            "status": conversation.status,
            "social_report": result,
        }

    def _default_period_label(self) -> str:
        month_names = {
            1: "janeiro",
            2: "fevereiro",
            3: "marco",
            4: "abril",
            5: "maio",
            6: "junho",
            7: "julho",
            8: "agosto",
            9: "setembro",
            10: "outubro",
            11: "novembro",
            12: "dezembro",
        }
        now = datetime.now()
        return f"{month_names[now.month]}{now.year}"
