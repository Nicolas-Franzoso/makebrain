from __future__ import annotations

from dataclasses import dataclass


@dataclass(frozen=True)
class SocialModule:
    module_id: str
    title: str
    trigger: str
    owner_agent: str
    primary_skills: list[str]
    outputs: list[str]
    approval_required: bool


SOCIAL_MODULES = [
    SocialModule(
        module_id="social-onboarding-research",
        title="Modulo 1: Onboarding e Setup Inicial",
        trigger="Novo cliente com servico social contratado",
        owner_agent="social-onboarding-agent",
        primary_skills=["social-r1-ingestion", "social-profile-audit", "social-meta-api-connection-guide"],
        outputs=["07_history/daily/<date>/<timestamp>-onboarding.md", "04_channels/social.md", "auditoria_social_inicial.md", "tutorial_conexao_meta_social.md"],
        approval_required=False,
    ),
    SocialModule(
        module_id="social-initial-delivery",
        title="Modulo 2: Entrega Estrategica Inicial",
        trigger="Conclusao do modulo de onboarding e research",
        owner_agent="social-onboarding-agent",
        primary_skills=["social-initial-delivery", "editorial-pillar-map"],
        outputs=["briefing_social.md", "posts_iniciais.md"],
        approval_required=True,
    ),
    SocialModule(
        module_id="social-copy-engine",
        title="Modulo 3: Motor de Execucao",
        trigger="Pedido do gestor para completar grade ou iniciar novo ciclo mensal",
        owner_agent="social-copy-agent",
        primary_skills=["social-copy-engine"],
        outputs=["posts_<mes><ano>.md"],
        approval_required=True,
    ),
    SocialModule(
        module_id="social-monthly-reporting",
        title="Modulo 4: Analise de Dados e Reporte",
        trigger="Fechamento do ciclo mensal de 30 dias",
        owner_agent="social-reporting-agent",
        primary_skills=["social-monthly-report-analysis", "community-signal-report", "content-winner-analysis"],
        outputs=["relatorio_<mes><ano>.md"],
        approval_required=True,
    ),
]


def build_social_workflow_blueprint() -> dict:
    return {
        "pillar": "social",
        "shared_context_rule": "Toda leitura e toda escrita devem usar a base global de contexto em Markdown do cliente.",
        "modules": [module.__dict__ for module in SOCIAL_MODULES],
        "cross_pillar_reads": [
            "00_profile.md",
            "01_brand_voice.md",
            "03_offer_stack.md",
            "04_channels/social.md",
            "04_channels/makeads.md",
            "05_sales_crm.md",
            "07_history/daily/*",
            "08_artifacts/*",
        ],
        "approval_rule": "Nenhuma postagem ou relatorio segue sem aprovacao humana registrada.",
    }
