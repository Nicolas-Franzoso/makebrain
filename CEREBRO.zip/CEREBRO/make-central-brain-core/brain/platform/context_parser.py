from __future__ import annotations

import hashlib
from pathlib import Path

import yaml

from brain.contracts import ContextBlock, ContextDocument


REQUIRED_FRONTMATTER_KEYS = {
    "client_id",
    "slug",
    "name",
    "timezone",
    "owners",
    "services_enabled",
    "approval_policy",
    "stage",
    "main_goals",
    "primary_kpis",
    "integrations",
    "status",
}

DAILY_NOTE_KEYS = {"client_id", "author", "created_at", "kind"}
ARTIFACT_KEYS = {"client_id", "artifact_type", "title", "created_at", "metadata"}


def split_frontmatter(text: str) -> tuple[dict, str]:
    if not text.startswith("---\n"):
        return {}, text

    parts = text.split("\n---\n", maxsplit=1)
    if len(parts) != 2:
        raise ValueError("Frontmatter markdown invalido.")
    raw_frontmatter = parts[0].replace("---\n", "", 1)
    frontmatter = yaml.safe_load(raw_frontmatter) or {}
    return frontmatter, parts[1]


def validate_frontmatter(frontmatter: dict) -> list[str]:
    return sorted(REQUIRED_FRONTMATTER_KEYS - set(frontmatter))


def validate_frontmatter_for_path(path: Path, frontmatter: dict) -> list[str]:
    normalized = str(path).replace("\\", "/")
    if "/07_history/daily/" in normalized:
        return sorted(DAILY_NOTE_KEYS - set(frontmatter))
    if "/08_artifacts/" in normalized:
        return sorted(ARTIFACT_KEYS - set(frontmatter))
    return validate_frontmatter(frontmatter)


def build_embedding(body: str) -> list[float]:
    digest = hashlib.sha256(body.encode("utf-8")).digest()
    return [round(byte / 255, 6) for byte in digest[:8]]


def parse_markdown_document(path: Path, commit_sha: str) -> ContextDocument:
    text = path.read_text(encoding="utf-8")
    frontmatter, body = split_frontmatter(text)

    headings: list[tuple[int, str, list[str]]] = []
    current_level = 1
    current_heading = "Document"
    current_lines: list[str] = []

    for line in body.splitlines():
        if line.startswith("#"):
            headings.append((current_level, current_heading, current_lines))
            current_level = len(line) - len(line.lstrip("#"))
            current_heading = line.lstrip("#").strip() or "Untitled"
            current_lines = []
            continue
        current_lines.append(line)

    headings.append((current_level, current_heading, current_lines))

    blocks = []
    client_id = str(frontmatter.get("client_id", path.parts[-2] if len(path.parts) > 1 else "unknown"))
    for order, (heading_level, heading, lines) in enumerate(headings):
        body_text = "\n".join(lines).strip()
        if not body_text and heading == "Document":
            continue
        blocks.append(
            ContextBlock(
                client_id=client_id,
                path=str(path),
                heading=heading,
                body=body_text,
                heading_level=heading_level,
                order=order,
                commit_sha=commit_sha,
                metadata={"source_file": path.name},
                embedding=build_embedding(body_text or heading),
            )
        )

    return ContextDocument(
        client_id=client_id,
        path=str(path),
        commit_sha=commit_sha,
        frontmatter=frontmatter,
        blocks=blocks,
    )


def parse_context_repository(root: Path, commit_sha: str) -> list[ContextDocument]:
    documents = []
    for path in sorted(root.rglob("*.md")):
        if path.name == "README.md":
            continue
        documents.append(parse_markdown_document(path, commit_sha))
    return documents
