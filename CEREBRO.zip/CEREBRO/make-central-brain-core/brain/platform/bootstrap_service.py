from __future__ import annotations

from pathlib import Path

from brain.config import get_settings
from brain.db import init_db, session_scope

from .context_indexer import ContextIndexer
from .context_service import ContextService
from .growth_workflow import LOCAL_MEDIA_PLAN_SKILL, GrowthWorkflowService
from .job_queue import JobQueue
from .onboarding_service import OnboardingService


class OnboardingBootstrapService:
    def run(self, answers: dict, requested_by: str = "onboarding", context_root: Path | None = None) -> dict:
        init_db()
        context_service = ContextService(context_root)
        normalized_answers = dict(answers)
        normalized_answers["requested_by"] = requested_by
        normalized_answers["client_slug"] = context_service.slugify(normalized_answers["client_slug"])
        context_sha = get_settings().default_context_sha

        written_files = context_service.bootstrap_client_context(normalized_answers)
        with session_scope() as session:
            indexed = ContextIndexer(session).index_repository(context_service.root, context_sha)
            queue = JobQueue(session)
            jobs = [
                queue.enqueue(job).model_dump(mode="json")
                for job in GrowthWorkflowService().build_initial_jobs(normalized_answers, context_sha)
            ]

        activation_plan = OnboardingService().build_activation_plan(normalized_answers)
        return {
            "client_slug": normalized_answers["client_slug"],
            "context_sha": context_sha,
            "written_files": written_files,
            "indexed_blocks": indexed,
            "activation_plan": activation_plan,
            "initial_jobs": jobs,
            "growth_process": {
                "media_plan_required": "makeads" in normalized_answers.get("contracted_services", []),
                "local_media_plan_skill_path": str(LOCAL_MEDIA_PLAN_SKILL),
                "growth_rule": "Quando MakeADS estiver contratado, o plano de midia e obrigatorio e antecede o roadmap de campanhas.",
            },
        }
