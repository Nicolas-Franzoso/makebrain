from __future__ import annotations

from datetime import UTC, datetime
from uuid import uuid4

from sqlalchemy import JSON, DateTime, Integer, String, Text, UniqueConstraint
from sqlalchemy.orm import DeclarativeBase, Mapped, mapped_column


class Base(DeclarativeBase):
    pass


def utcnow() -> datetime:
    return datetime.now(UTC)


class ClientORM(Base):
    __tablename__ = "clients"
    client_id: Mapped[str] = mapped_column(String(100), primary_key=True)
    slug: Mapped[str] = mapped_column(String(120), unique=True, index=True)
    name: Mapped[str] = mapped_column(String(200))
    status: Mapped[str] = mapped_column(String(50))
    services_enabled: Mapped[list[str]] = mapped_column(JSON, default=list)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class ContextIndexORM(Base):
    __tablename__ = "context_index"
    __table_args__ = (UniqueConstraint("client_id", "path", "heading", "chunk_order", "commit_sha"),)

    chunk_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    path: Mapped[str] = mapped_column(String(500), index=True)
    heading: Mapped[str] = mapped_column(String(255))
    body: Mapped[str] = mapped_column(Text)
    heading_level: Mapped[int] = mapped_column(Integer)
    chunk_order: Mapped[int] = mapped_column(Integer)
    commit_sha: Mapped[str] = mapped_column(String(120), index=True)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    embedding_json: Mapped[list[float]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class JobORM(Base):
    __tablename__ = "job_queue"

    job_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    agent_id: Mapped[str] = mapped_column(String(100), index=True)
    skill_id: Mapped[str] = mapped_column(String(120), index=True)
    priority: Mapped[int] = mapped_column(Integer, default=50, index=True)
    input_refs: Mapped[list[str]] = mapped_column(JSON, default=list)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    context_sha: Mapped[str] = mapped_column(String(120))
    idempotency_key: Mapped[str] = mapped_column(String(255), unique=True, index=True)
    status: Mapped[str] = mapped_column(String(50), default="queued", index=True)
    worker_id: Mapped[str | None] = mapped_column(String(100), nullable=True)
    lease_until: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)


class JobRunORM(Base):
    __tablename__ = "job_runs"
    run_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    job_id: Mapped[str] = mapped_column(String(64), index=True)
    worker_id: Mapped[str] = mapped_column(String(100), index=True)
    status: Mapped[str] = mapped_column(String(50), index=True)
    started_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    finished_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    details_json: Mapped[dict] = mapped_column(JSON, default=dict)


class WorkerHeartbeatORM(Base):
    __tablename__ = "worker_heartbeats"
    worker_id: Mapped[str] = mapped_column(String(100), primary_key=True)
    execution_profile: Mapped[str] = mapped_column(String(50))
    host: Mapped[str] = mapped_column(String(120))
    last_seen_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)


class DistributedLockORM(Base):
    __tablename__ = "distributed_locks"
    lock_name: Mapped[str] = mapped_column(String(150), primary_key=True)
    owner: Mapped[str] = mapped_column(String(100))
    acquired_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    expires_at: Mapped[datetime] = mapped_column(DateTime)


class ApprovalORM(Base):
    __tablename__ = "approvals"
    approval_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    artifact_id: Mapped[str | None] = mapped_column(String(64), nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="pending", index=True)
    requested_by: Mapped[str] = mapped_column(String(120))
    requested_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    decision_by: Mapped[str | None] = mapped_column(String(120), nullable=True)
    decision_at: Mapped[datetime | None] = mapped_column(DateTime, nullable=True)
    rationale: Mapped[str | None] = mapped_column(Text, nullable=True)


class AlertORM(Base):
    __tablename__ = "alerts"
    alert_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    severity: Mapped[str] = mapped_column(String(50), index=True)
    pillar: Mapped[str] = mapped_column(String(50), index=True)
    reason: Mapped[str] = mapped_column(Text)
    recommended_action: Mapped[str] = mapped_column(Text)
    evidence_refs: Mapped[list[str]] = mapped_column(JSON, default=list)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class ArtifactORM(Base):
    __tablename__ = "artifacts"
    artifact_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    type: Mapped[str] = mapped_column(String(80))
    producer_agent: Mapped[str] = mapped_column(String(100))
    source_jobs: Mapped[list[str]] = mapped_column(JSON, default=list)
    source_context_sha: Mapped[str] = mapped_column(String(120))
    approval_status: Mapped[str] = mapped_column(String(50), default="pending")
    storage_ref: Mapped[str] = mapped_column(String(500))
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class IntegrationAccountORM(Base):
    __tablename__ = "integration_accounts"
    integration_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str] = mapped_column(String(100), index=True)
    provider: Mapped[str] = mapped_column(String(80), index=True)
    account_ref: Mapped[str] = mapped_column(String(180))
    execution_profile: Mapped[str] = mapped_column(String(50))
    secrets_ref: Mapped[str] = mapped_column(String(300))
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class EventLogORM(Base):
    __tablename__ = "event_log"
    event_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    event_type: Mapped[str] = mapped_column(String(120), index=True)
    client_id: Mapped[str | None] = mapped_column(String(100), index=True, nullable=True)
    payload: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)


class ConversationSessionORM(Base):
    __tablename__ = "conversation_sessions"
    session_id: Mapped[str] = mapped_column(String(64), primary_key=True, default=lambda: uuid4().hex)
    client_id: Mapped[str | None] = mapped_column(String(100), index=True, nullable=True)
    status: Mapped[str] = mapped_column(String(50), default="collecting")
    stage: Mapped[str] = mapped_column(String(80), default="onboarding")
    pending_question_id: Mapped[str | None] = mapped_column(String(120), nullable=True)
    answers_json: Mapped[dict] = mapped_column(JSON, default=dict)
    message_log: Mapped[list[dict]] = mapped_column(JSON, default=list)
    metadata_json: Mapped[dict] = mapped_column(JSON, default=dict)
    created_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow)
    updated_at: Mapped[datetime] = mapped_column(DateTime, default=utcnow, onupdate=utcnow)
