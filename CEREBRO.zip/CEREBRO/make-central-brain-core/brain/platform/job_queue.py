from __future__ import annotations

from datetime import UTC, datetime, timedelta

from sqlalchemy import select
from sqlalchemy.orm import Session

from brain.config import get_settings
from brain.contracts import JobCreate, JobRecord, JobStatus

from .db_models import JobORM


class JobQueue:
    def __init__(self, session: Session):
        self.session = session
        self.settings = get_settings()

    def get(self, job_id: str) -> JobRecord:
        job = self.session.get(JobORM, job_id)
        if job is None:
            raise KeyError(job_id)
        return self._to_record(job)

    def enqueue(self, data: JobCreate) -> JobRecord:
        existing = self.session.execute(
            select(JobORM).where(JobORM.idempotency_key == data.idempotency_key)
        ).scalar_one_or_none()
        if existing:
            return self._to_record(existing)

        job = JobORM(
            client_id=data.client_id,
            agent_id=data.agent_id,
            skill_id=data.skill_id,
            priority=data.priority,
            input_refs=data.input_refs,
            payload=data.payload,
            context_sha=data.context_sha,
            idempotency_key=data.idempotency_key,
            status=JobStatus.queued.value,
        )
        self.session.add(job)
        self.session.flush()
        return self._to_record(job)

    def claim_next(self, worker_id: str) -> JobRecord | None:
        now = datetime.now(UTC)
        stmt = (
            select(JobORM)
            .where(
                JobORM.status == JobStatus.queued.value,
            )
            .order_by(JobORM.priority.desc(), JobORM.created_at.asc())
            .limit(1)
        )
        if self.session.bind and self.session.bind.dialect.name == "postgresql":
            stmt = stmt.with_for_update(skip_locked=True)

        job = self.session.execute(stmt).scalar_one_or_none()
        if job is None:
            return None

        job.status = JobStatus.leased.value
        job.worker_id = worker_id
        job.lease_until = now + timedelta(seconds=self.settings.lease_seconds)
        self.session.flush()
        return self._to_record(job)

    def complete(self, job_id: str) -> JobRecord:
        job = self.session.get(JobORM, job_id)
        if not job:
            raise KeyError(job_id)
        job.status = JobStatus.completed.value
        job.lease_until = None
        self.session.flush()
        return self._to_record(job)

    def fail(self, job_id: str) -> JobRecord:
        job = self.session.get(JobORM, job_id)
        if not job:
            raise KeyError(job_id)
        job.status = JobStatus.failed.value
        self.session.flush()
        return self._to_record(job)

    def _to_record(self, job: JobORM) -> JobRecord:
        return JobRecord(
            job_id=job.job_id,
            client_id=job.client_id,
            agent_id=job.agent_id,
            skill_id=job.skill_id,
            priority=job.priority,
            input_refs=job.input_refs,
            payload=job.payload,
            context_sha=job.context_sha,
            idempotency_key=job.idempotency_key,
            status=JobStatus(job.status),
            lease_until=job.lease_until,
            worker_id=job.worker_id,
            created_at=job.created_at,
            updated_at=job.updated_at,
        )
