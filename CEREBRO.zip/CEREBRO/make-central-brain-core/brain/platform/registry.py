from __future__ import annotations

from pathlib import Path

from brain.contracts import AgentDefinition, SkillDefinition, SkillExecutionContract

from .registry_data import AGENT_CATALOG, SKILL_PURPOSE_OVERRIDES


def _titleize(skill_id: str) -> str:
    return skill_id.replace("-", " ").title()


def load_agents() -> list[AgentDefinition]:
    return [
        AgentDefinition(
            agent_id=agent_id,
            title=title,
            layer=layer,
            pillar=pillar,
            purpose=purpose,
            execution_profile=execution_profile,
            skill_ids=skill_ids,
        )
        for agent_id, title, layer, pillar, purpose, execution_profile, skill_ids in AGENT_CATALOG
    ]


def load_skills(root: Path | None = None) -> list[SkillDefinition]:
    base_path = root or Path(__file__).resolve().parents[1] / "skills"
    skills: list[SkillDefinition] = []
    for agent in load_agents():
        for skill_id in agent.skill_ids:
            skills.append(
                SkillDefinition(
                    skill_id=skill_id,
                    agent_id=agent.agent_id,
                    layer=agent.layer,
                    pillar=agent.pillar,
                    title=_titleize(skill_id),
                    purpose=SKILL_PURPOSE_OVERRIDES.get(
                        skill_id,
                        f"Scaffold operacional para a skill `{skill_id}` do agente {agent.title}.",
                    ),
                    contract=SkillExecutionContract(
                        inputs=["client_id", "payload"],
                        context_dependencies=["00_profile.md", "01_brand_voice.md"],
                        external_connectors=[],
                        output_shape="artifact-or-alert",
                        approval_required=agent.execution_profile != "read-only",
                        retry_behavior="exponential-backoff",
                    ),
                    scaffold_path=str(base_path / agent.pillar / skill_id),
                )
            )
    return skills


def get_agent(agent_id: str) -> AgentDefinition:
    for agent in load_agents():
        if agent.agent_id == agent_id:
            return agent
    raise KeyError(agent_id)


def get_skill(skill_id: str) -> SkillDefinition:
    for skill in load_skills():
        if skill.skill_id == skill_id:
            return skill
    raise KeyError(skill_id)

