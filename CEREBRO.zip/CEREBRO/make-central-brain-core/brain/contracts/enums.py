from enum import Enum


class ExecutionProfile(str, Enum):
    read_only = "read-only"
    draft_write = "draft-write"
    critical_write = "critical-write"


class JobStatus(str, Enum):
    queued = "queued"
    leased = "leased"
    running = "running"
    completed = "completed"
    failed = "failed"
    dead_letter = "dead-letter"


class ApprovalStatus(str, Enum):
    pending = "pending"
    approved = "approved"
    rejected = "rejected"


class Severity(str, Enum):
    info = "info"
    warning = "warning"
    critical = "critical"

