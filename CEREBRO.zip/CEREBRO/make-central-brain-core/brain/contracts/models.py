from __future__ import annotations

from datetime import datetime
from typing import Any

from pydantic import BaseModel, Field

from .enums import ApprovalStatus, ExecutionProfile, JobStatus, Severity


class ContextBlock(BaseModel):
    client_id: str
    path: str
    heading: str
    body: str
    heading_level: int
    order: int
    commit_sha: str
    metadata: dict[str, Any] = Field(default_factory=dict)
    embedding: list[float] = Field(default_factory=list)


class ContextDocument(BaseModel):
    client_id: str
    path: str
    commit_sha: str
    frontmatter: dict[str, Any] = Field(default_factory=dict)
    blocks: list[ContextBlock] = Field(default_factory=list)


class SkillExecutionContract(BaseModel):
    inputs: list[str]
    context_dependencies: list[str]
    external_connectors: list[str]
    output_shape: str
    approval_required: bool
    retry_behavior: str


class SkillDefinition(BaseModel):
    skill_id: str
    agent_id: str
    layer: str
    pillar: str
    title: str
    purpose: str
    contract: SkillExecutionContract
    scaffold_path: str | None = None


class AgentDefinition(BaseModel):
    agent_id: str
    title: str
    layer: str
    pillar: str
    purpose: str
    execution_profile: ExecutionProfile
    skill_ids: list[str]


class JobCreate(BaseModel):
    client_id: str
    agent_id: str
    skill_id: str
    priority: int = 50
    input_refs: list[str] = Field(default_factory=list)
    payload: dict[str, Any] = Field(default_factory=dict)
    idempotency_key: str
    context_sha: str


class JobRecord(JobCreate):
    job_id: str
    status: JobStatus
    lease_until: datetime | None = None
    worker_id: str | None = None
    created_at: datetime
    updated_at: datetime


class ApprovalRecord(BaseModel):
    approval_id: str
    client_id: str
    artifact_id: str | None = None
    status: ApprovalStatus
    requested_by: str
    requested_at: datetime
    decision_by: str | None = None
    decision_at: datetime | None = None
    rationale: str | None = None


class ApprovalDecision(BaseModel):
    decision_by: str
    rationale: str | None = None
    approved: bool


class ArtifactRecord(BaseModel):
    artifact_id: str
    client_id: str
    type: str
    producer_agent: str
    source_jobs: list[str]
    source_context_sha: str
    approval_status: ApprovalStatus
    storage_ref: str


class OrchestratorPlan(BaseModel):
    client_id: str
    context_sha: str
    generated_at: datetime
    priorities: list[dict[str, Any]]
    alerts_considered: int
    approvals_pending: int
    sources: list[str] = Field(default_factory=list)


class AlertRecord(BaseModel):
    alert_id: str
    client_id: str
    severity: Severity
    pillar: str
    reason: str
    recommended_action: str
    evidence_refs: list[str] = Field(default_factory=list)
    created_at: datetime

