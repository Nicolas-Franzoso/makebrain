# Approval Request

- `skill_id`: `approval-request`
- `agent_id`: `approval-governance-agent`
- `layer`: `platform`
- `pillar`: `governance`

## Purpose

Abre item de aprovacao no control plane.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
