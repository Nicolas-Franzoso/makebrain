from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `approval-request`."""
    return {
        'skill_id': 'approval-request',
        'status': 'scaffold',
        'payload': payload,
    }
