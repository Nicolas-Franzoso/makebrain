# Claim Risk Check

- `skill_id`: `claim-risk-check`
- `agent_id`: `qa-compliance-agent`
- `layer`: `platform`
- `pillar`: `governance`

## Purpose

Scaffold operacional para a skill `claim-risk-check` do agente Agente de QA e Compliance.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
