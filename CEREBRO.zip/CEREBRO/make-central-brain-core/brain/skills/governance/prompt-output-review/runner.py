from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `prompt-output-review`."""
    return {
        'skill_id': 'prompt-output-review',
        'status': 'scaffold',
        'payload': payload,
    }
