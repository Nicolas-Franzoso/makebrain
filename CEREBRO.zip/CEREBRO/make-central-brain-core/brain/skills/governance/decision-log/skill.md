# Decision Log

- `skill_id`: `decision-log`
- `agent_id`: `approval-governance-agent`
- `layer`: `platform`
- `pillar`: `governance`

## Purpose

Scaffold operacional para a skill `decision-log` do agente Agente de Aprovacao e Governanca.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
