from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `policy-check`."""
    return {
        'skill_id': 'policy-check',
        'status': 'scaffold',
        'payload': payload,
    }
