# Conversation Next Question

- `skill_id`: `conversation-next-question`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Descobre a proxima pergunta necessaria sem exigir comandos tecnicos do operador.

## How To Use

- Use quando quiser saber qual pergunta vem agora para uma sessao conversacional ja aberta.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
