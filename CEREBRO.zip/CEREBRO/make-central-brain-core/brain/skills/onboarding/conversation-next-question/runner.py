from __future__ import annotations

from typing import Any

from brain.db import init_db, session_scope
from brain.platform.conversation_service import ConversationService


def run(payload: dict[str, Any]) -> dict[str, Any]:
    init_db()
    with session_scope() as session:
        return ConversationService(session).handle_message(
            message="",
            session_id=payload.get("session_id"),
            author=payload.get("author", "system"),
        )

