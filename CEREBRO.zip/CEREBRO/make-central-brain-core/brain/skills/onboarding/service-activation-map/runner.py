from __future__ import annotations

from typing import Any

from brain.platform.onboarding_service import OnboardingService


def run(payload: dict[str, Any]) -> dict[str, Any]:
    answers = payload.get("answers", payload)
    return OnboardingService().build_activation_plan(answers)

