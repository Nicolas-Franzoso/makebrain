# Service Activation Map

- `skill_id`: `service-activation-map`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Decide quais agentes e etapas podem ser ativados com base nas respostas do onboarding.

## How To Use

- Envie todas as respostas do onboarding mestre.
- A skill retorna agentes ativos, agentes bloqueados, motivos e proximas perguntas.
- Use a saida para abrir o onboarding da etapa certa.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
