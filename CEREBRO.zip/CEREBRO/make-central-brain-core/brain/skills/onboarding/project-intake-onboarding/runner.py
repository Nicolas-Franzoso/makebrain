from __future__ import annotations

from typing import Any

from brain.platform.onboarding_service import OnboardingService


def run(payload: dict[str, Any]) -> dict[str, Any]:
    return OnboardingService().get_project_template()

