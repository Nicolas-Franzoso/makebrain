# Project Intake Onboarding

- `skill_id`: `project-intake-onboarding`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Conduz o onboarding inicial do cliente com perguntas essenciais, tutoriais e checklist guiado.

## How To Use

- Rode esta skill sempre que um novo cliente entrar.
- Preencha primeiro as perguntas mestras.
- Use os tutoriais embutidos para pedir acessos sem depender de conhecimento tecnico.
- Depois passe as respostas para `service-activation-map`.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
