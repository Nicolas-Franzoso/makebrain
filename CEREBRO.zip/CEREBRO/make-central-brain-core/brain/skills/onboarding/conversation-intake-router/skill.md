# Conversation Intake Router

- `skill_id`: `conversation-intake-router`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Recebe texto livre do usuario, atualiza o estado da conversa e chama o proximo passo automaticamente.

## How To Use

- O usuario so escreve em linguagem natural.
- A skill decide se deve salvar resposta, perguntar algo, bootstrapar o cliente ou pedir aprovacao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
