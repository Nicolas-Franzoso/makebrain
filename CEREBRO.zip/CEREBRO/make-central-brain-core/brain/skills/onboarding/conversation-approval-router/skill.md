# Conversation Approval Router

- `skill_id`: `conversation-approval-router`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Entende aprovacoes em linguagem natural e aciona os proximos passos automaticamente.

## How To Use

- O usuario pode escrever coisas como `aprovado`, `pode seguir` ou colar o plano final.
- A skill usa o estado da conversa para decidir o que fazer depois.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
