# Project Bootstrap Client

- `skill_id`: `project-bootstrap-client`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Aplica o onboarding no contexto oficial, indexa a memoria e gera o kickoff inicial do cliente.

## How To Use

- Use esta skill quando o questionario do novo cliente ja estiver preenchido.
- A entrada deve conter todas as respostas do onboarding.
- A skill cria os arquivos canônicos, indexa a memoria e abre os primeiros jobs do projeto.

## Growth Rule

- Se `makeads` estiver contratado, o primeiro job obrigatorio sera `onboarding-media-plan`.
- Esse job deve usar a skill oficial `plano-de-midia-make`, versionada dentro do Make Brain.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
