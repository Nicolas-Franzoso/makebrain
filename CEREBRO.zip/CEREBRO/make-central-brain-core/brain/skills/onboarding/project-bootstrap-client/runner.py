from __future__ import annotations

from typing import Any

from brain.platform.bootstrap_service import OnboardingBootstrapService


def run(payload: dict[str, Any]) -> dict[str, Any]:
    answers = payload.get("answers", payload)
    requested_by = payload.get("requested_by", "onboarding")
    return OnboardingBootstrapService().run(answers, requested_by=requested_by)

