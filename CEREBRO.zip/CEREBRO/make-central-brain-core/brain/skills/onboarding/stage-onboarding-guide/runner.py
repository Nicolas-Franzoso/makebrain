from __future__ import annotations

from typing import Any

from brain.platform.onboarding_service import OnboardingService


def run(payload: dict[str, Any]) -> dict[str, Any]:
    stage = payload["stage"]
    return OnboardingService().get_stage_guide(stage)

