# Stage Onboarding Guide

- `skill_id`: `stage-onboarding-guide`
- `agent_id`: `project-onboarding-agent`
- `layer`: `orchestration`
- `pillar`: `onboarding`

## Purpose

Mostra o próximo conjunto de perguntas para cada etapa ou pilar contratado.

## Example Stages

- `makeads`
- `social`
- `web`
- `seo`
- `aeo`
- `geo`
- `crm`
- `mavi`

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
