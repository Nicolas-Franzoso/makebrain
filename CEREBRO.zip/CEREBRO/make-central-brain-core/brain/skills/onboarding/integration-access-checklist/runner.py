from __future__ import annotations

from typing import Any

from brain.platform.onboarding_catalog import INTEGRATION_TUTORIALS


def run(payload: dict[str, Any]) -> dict[str, Any]:
    keys = payload.get("keys") or sorted(INTEGRATION_TUTORIALS)
    return {
        "checklists": [{"key": key, **INTEGRATION_TUTORIALS[key]} for key in keys if key in INTEGRATION_TUTORIALS]
    }

