from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `unsafe-response-check`."""
    return {
        'skill_id': 'unsafe-response-check',
        'status': 'scaffold',
        'payload': payload,
    }
