# Unsafe Response Check

- `skill_id`: `unsafe-response-check`
- `agent_id`: `mavi-safety-agent`
- `layer`: `specialist`
- `pillar`: `mavi`

## Purpose

Scaffold operacional para a skill `unsafe-response-check` do agente Agente de Seguranca Conversacional.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
