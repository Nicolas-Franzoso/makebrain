from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `handoff-rules`."""
    return {
        'skill_id': 'handoff-rules',
        'status': 'scaffold',
        'payload': payload,
    }
