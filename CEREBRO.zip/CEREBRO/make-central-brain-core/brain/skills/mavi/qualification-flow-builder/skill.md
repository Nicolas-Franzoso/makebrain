# Qualification Flow Builder

- `skill_id`: `qualification-flow-builder`
- `agent_id`: `mavi-conversation-design-agent`
- `layer`: `specialist`
- `pillar`: `mavi`

## Purpose

Scaffold operacional para a skill `qualification-flow-builder` do agente Agente de Design Conversacional.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
