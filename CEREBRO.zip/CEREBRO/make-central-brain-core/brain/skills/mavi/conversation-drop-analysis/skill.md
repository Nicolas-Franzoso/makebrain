# Conversation Drop Analysis

- `skill_id`: `conversation-drop-analysis`
- `agent_id`: `mavi-optimization-agent`
- `layer`: `specialist`
- `pillar`: `mavi`

## Purpose

Scaffold operacional para a skill `conversation-drop-analysis` do agente Agente de Otimizacao de Conversa.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
