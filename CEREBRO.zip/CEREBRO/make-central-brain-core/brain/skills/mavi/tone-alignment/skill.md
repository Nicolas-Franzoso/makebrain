# Tone Alignment

- `skill_id`: `tone-alignment`
- `agent_id`: `mavi-conversation-design-agent`
- `layer`: `specialist`
- `pillar`: `mavi`

## Purpose

Scaffold operacional para a skill `tone-alignment` do agente Agente de Design Conversacional.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
