from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `persona-definition`."""
    return {
        'skill_id': 'persona-definition',
        'status': 'scaffold',
        'payload': payload,
    }
