# Conversation Memory Pack

- `skill_id`: `conversation-memory-pack`
- `agent_id`: `mavi-knowledge-agent`
- `layer`: `specialist`
- `pillar`: `mavi`

## Purpose

Scaffold operacional para a skill `conversation-memory-pack` do agente Agente de Base de Conhecimento.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
