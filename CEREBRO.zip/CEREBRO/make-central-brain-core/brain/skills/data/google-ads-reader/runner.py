from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `google-ads-reader`."""
    return {
        'skill_id': 'google-ads-reader',
        'status': 'scaffold',
        'payload': payload,
    }
