# Kpi Baseline Builder

- `skill_id`: `kpi-baseline-builder`
- `agent_id`: `data-agent`
- `layer`: `platform`
- `pillar`: `data`

## Purpose

Scaffold operacional para a skill `kpi-baseline-builder` do agente Agente de Dados.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
