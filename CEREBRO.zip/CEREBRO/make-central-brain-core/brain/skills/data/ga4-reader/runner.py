from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `ga4-reader`."""
    return {
        'skill_id': 'ga4-reader',
        'status': 'scaffold',
        'payload': payload,
    }
