# Crm Metrics Reader

- `skill_id`: `crm-metrics-reader`
- `agent_id`: `data-agent`
- `layer`: `platform`
- `pillar`: `data`

## Purpose

Scaffold operacional para a skill `crm-metrics-reader` do agente Agente de Dados.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
