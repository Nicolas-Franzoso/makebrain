from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `meta-reader`."""
    return {
        'skill_id': 'meta-reader',
        'status': 'scaffold',
        'payload': payload,
    }
