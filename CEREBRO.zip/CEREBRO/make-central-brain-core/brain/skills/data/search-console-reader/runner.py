from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `search-console-reader`."""
    return {
        'skill_id': 'search-console-reader',
        'status': 'scaffold',
        'payload': payload,
    }
