# Daily Rhythm Planner

- `skill_id`: `daily-rhythm-planner`
- `agent_id`: `maestro-orchestrator`
- `layer`: `orchestration`
- `pillar`: `orchestration`

## Purpose

Gera o plano diario do cliente a partir de contexto, alertas e backlog.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
