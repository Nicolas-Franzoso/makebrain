from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `dead-letter-review`."""
    return {
        'skill_id': 'dead-letter-review',
        'status': 'scaffold',
        'payload': payload,
    }
