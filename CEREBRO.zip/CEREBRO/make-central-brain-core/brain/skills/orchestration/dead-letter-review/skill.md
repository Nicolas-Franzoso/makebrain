# Dead Letter Review

- `skill_id`: `dead-letter-review`
- `agent_id`: `execution-supervisor`
- `layer`: `orchestration`
- `pillar`: `orchestration`

## Purpose

Scaffold operacional para a skill `dead-letter-review` do agente Agente Supervisor de Execucao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
