# Cross Pillar Prioritizer

- `skill_id`: `cross-pillar-prioritizer`
- `agent_id`: `maestro-orchestrator`
- `layer`: `orchestration`
- `pillar`: `orchestration`

## Purpose

Scaffold operacional para a skill `cross-pillar-prioritizer` do agente Agente Orquestrador Maestro.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
