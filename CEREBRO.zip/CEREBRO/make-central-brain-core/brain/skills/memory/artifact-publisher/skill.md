# Artifact Publisher

- `skill_id`: `artifact-publisher`
- `agent_id`: `memory-context-agent`
- `layer`: `platform`
- `pillar`: `memory`

## Purpose

Publica artefatos aprovados no repositório de contexto.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
