# Md Validator

- `skill_id`: `md-validator`
- `agent_id`: `memory-context-agent`
- `layer`: `platform`
- `pillar`: `memory`

## Purpose

Valida frontmatter, estrutura e obrigatoriedades do contexto.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
