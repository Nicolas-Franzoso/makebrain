from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `context-capture`."""
    return {
        'skill_id': 'context-capture',
        'status': 'scaffold',
        'payload': payload,
    }
