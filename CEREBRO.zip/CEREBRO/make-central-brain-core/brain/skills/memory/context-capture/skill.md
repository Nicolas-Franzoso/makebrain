# Context Capture

- `skill_id`: `context-capture`
- `agent_id`: `memory-context-agent`
- `layer`: `platform`
- `pillar`: `memory`

## Purpose

Captura inputs diarios do time em Markdown append-only.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
