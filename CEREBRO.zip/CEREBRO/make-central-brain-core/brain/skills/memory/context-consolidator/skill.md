# Context Consolidator

- `skill_id`: `context-consolidator`
- `agent_id`: `memory-context-agent`
- `layer`: `platform`
- `pillar`: `memory`

## Purpose

Consolida entradas diarias em resumos semanais e mensais.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
