# Semantic Indexer

- `skill_id`: `semantic-indexer`
- `agent_id`: `memory-context-agent`
- `layer`: `platform`
- `pillar`: `memory`

## Purpose

Indexa blocos do contexto com metadata e embeddings.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
