from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `concise-response-rewriter`."""
    return {
        'skill_id': 'concise-response-rewriter',
        'status': 'scaffold',
        'payload': payload,
    }
