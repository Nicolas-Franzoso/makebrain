"""Generated skill package."""
