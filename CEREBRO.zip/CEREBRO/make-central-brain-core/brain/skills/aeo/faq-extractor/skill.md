# Faq Extractor

- `skill_id`: `faq-extractor`
- `agent_id`: `aeo-answer-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `faq-extractor` do agente Agente de Respostas e FAQs.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
