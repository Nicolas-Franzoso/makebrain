# Featured Snippet Brief

- `skill_id`: `featured-snippet-brief`
- `agent_id`: `aeo-snippet-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `featured-snippet-brief` do agente Agente de Snippet Optimization.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
