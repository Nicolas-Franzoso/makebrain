from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `featured-snippet-brief`."""
    return {
        'skill_id': 'featured-snippet-brief',
        'status': 'scaffold',
        'payload': payload,
    }
