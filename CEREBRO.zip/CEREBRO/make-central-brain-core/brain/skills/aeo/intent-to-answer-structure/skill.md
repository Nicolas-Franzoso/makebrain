# Intent To Answer Structure

- `skill_id`: `intent-to-answer-structure`
- `agent_id`: `aeo-answer-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `intent-to-answer-structure` do agente Agente de Respostas e FAQs.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
