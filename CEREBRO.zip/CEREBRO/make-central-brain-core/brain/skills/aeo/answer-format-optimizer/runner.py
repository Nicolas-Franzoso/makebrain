from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `answer-format-optimizer`."""
    return {
        'skill_id': 'answer-format-optimizer',
        'status': 'scaffold',
        'payload': payload,
    }
