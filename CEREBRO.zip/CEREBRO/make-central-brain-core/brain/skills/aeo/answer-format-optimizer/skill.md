# Answer Format Optimizer

- `skill_id`: `answer-format-optimizer`
- `agent_id`: `aeo-snippet-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `answer-format-optimizer` do agente Agente de Snippet Optimization.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
