# Answer Pack Builder

- `skill_id`: `answer-pack-builder`
- `agent_id`: `aeo-answer-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `answer-pack-builder` do agente Agente de Respostas e FAQs.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
