# Schema Recommendation

- `skill_id`: `schema-recommendation`
- `agent_id`: `aeo-schema-agent`
- `layer`: `specialist`
- `pillar`: `aeo`

## Purpose

Scaffold operacional para a skill `schema-recommendation` do agente Agente de Schema e Entidades.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
