# Budget Shift Suggest

- `skill_id`: `budget-shift-suggest`
- `agent_id`: `makeads-performance-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Scaffold operacional para a skill `budget-shift-suggest` do agente Agente Analyst de Performance.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
