from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `campaign-diagnosis`."""
    return {
        'skill_id': 'campaign-diagnosis',
        'status': 'scaffold',
        'payload': payload,
    }
