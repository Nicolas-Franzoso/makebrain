from __future__ import annotations

from pathlib import Path
from typing import Any

from brain.db import init_db, session_scope
from brain.platform.growth_kickoff_service import GrowthKickoffService
from brain.platform.media_plan_skill import media_plan_skill_sources, resolve_media_plan_skill_path


def run(payload: dict[str, Any]) -> dict[str, Any]:
    if payload.get("job_id") and payload.get("media_plan_content") and payload.get("plan_summary") and payload.get("approved_by"):
        init_db()
        with session_scope() as session:
            return GrowthKickoffService(session).finalize_media_plan_job(
                job_id=payload["job_id"],
                media_plan_content=payload["media_plan_content"],
                plan_summary=payload["plan_summary"],
                approved_by=payload["approved_by"],
            )

    local_skill_path = Path(payload.get("local_skill_path", resolve_media_plan_skill_path()))
    sources = media_plan_skill_sources()
    return {
        "skill_id": "onboarding-media-plan",
        "status": "must-use-official-media-plan-skill" if local_skill_path.exists() else "missing-media-plan-skill",
        "source_skill_name": "plano-de-midia-make",
        "source_skill_path": str(local_skill_path),
        "bundled_skill_path": sources["bundled_path"],
        "bundled_skill_available": sources["bundled_available"],
        "legacy_local_skill_path": sources["legacy_local_path"],
        "client_id": payload.get("client_slug") or payload.get("client_id"),
        "growth_rule": "O plano de midia e obrigatorio para orientar a diretriz inicial de growth e campanhas.",
        "policy": "Nao substituir por prototipo generico. O plano valido deve vir da skill oficial `plano-de-midia-make` do Make Brain.",
        "instructions": [
            "Usar a transcricao da R1 como base do plano de midia.",
            "Gerar o plano com a skill oficial plano-de-midia-make.",
            "Publicar o artefato aprovado em 08_artifacts/ e atualizar 04_channels/makeads.md com as diretrizes finais.",
        ],
        "payload": payload,
    }
