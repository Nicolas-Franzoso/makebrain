# Onboarding Media Plan

- `skill_id`: `onboarding-media-plan`
- `agent_id`: `makeads-planner-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Encapsula a skill oficial `plano-de-midia-make`, agora versionada dentro do Make Brain, como onboarding do ecossistema.

## Growth Rule

- Quando `makeads` estiver contratado, esta skill e obrigatoria no kickoff de growth.
- O plano de midia aprovado vira a diretriz principal de campanhas e do roadmap de ativacao.
- Nao e permitido substituir essa etapa por um prototipo generico.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
