# Plano de Midia Make

- `skill_id`: `plano-de-midia-make`
- `agent_id`: `makeads-planner-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Skill oficial de plano de midia da Make, incorporada ao Make Brain para orientar o kickoff de growth com base na R1.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`
- `03_offer_stack.md`
- `04_channels/makeads.md`
- `07_history/daily/onboarding`

## Output

- Shape: `html-plan-or-review`
- Approval required: `True`
- Retry behavior: `human-in-the-loop`

## Source

- Instrucoes completas da skill original: [SKILL.md](SKILL.md)
- Agente original: [agents/openai.yaml](agents/openai.yaml)
- Evals de referencia: [evals/evals.json](evals/evals.json)
