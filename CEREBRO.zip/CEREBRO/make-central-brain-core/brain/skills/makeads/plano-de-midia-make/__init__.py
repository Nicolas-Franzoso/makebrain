"""Bundled media plan skill for MakeADS."""
