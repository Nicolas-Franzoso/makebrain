from __future__ import annotations

from typing import Any

from brain.platform.media_plan_skill import media_plan_skill_sources


def run(payload: dict[str, Any]) -> dict[str, Any]:
    sources = media_plan_skill_sources()
    return {
        "skill_id": "plano-de-midia-make",
        "status": "bundled-skill-ready",
        "client_id": payload.get("client_slug") or payload.get("client_id"),
        "resolved_skill_path": sources["resolved_path"],
        "bundled_skill_path": sources["bundled_path"],
        "bundled_skill_available": sources["bundled_available"],
        "legacy_local_skill_path": sources["legacy_local_path"],
        "instructions": [
            "Use a transcricao da R1 como base obrigatoria do plano.",
            "Siga a especificacao completa descrita em SKILL.md.",
            "Apos gerar o plano, envie a versao para revisao e aprovacao humana.",
            "Somente a versao aprovada deve ser publicada no contexto do cliente.",
        ],
        "payload": payload,
    }
