# Prompt for plano-de-midia-make

Use a skill oficial `plano-de-midia-make` incorporada ao Make Brain.

Antes de gerar o plano:
- leia a transcricao da R1
- confirme o entendimento
- pergunte apenas o que faltar
- respeite a especificacao completa em `SKILL.md`

Depois da geracao:
- o plano entra em revisao humana
- somente a versao aprovada pode alimentar `04_channels/makeads.md`
