# Organic Post Champion To Paid

- `skill_id`: `organic-post-champion-to-paid`
- `agent_id`: `makeads-expansion-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Detecta post orgânico campeao e propõe um ângulo pago para MakeADS.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
