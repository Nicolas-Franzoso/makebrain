from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `offer-test-suggest`."""
    return {
        'skill_id': 'offer-test-suggest',
        'status': 'scaffold',
        'payload': payload,
    }
