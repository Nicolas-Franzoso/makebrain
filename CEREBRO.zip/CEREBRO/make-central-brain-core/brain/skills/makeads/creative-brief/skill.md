# Creative Brief

- `skill_id`: `creative-brief`
- `agent_id`: `makeads-creative-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Scaffold operacional para a skill `creative-brief` do agente Agente de Criativo Pago.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
