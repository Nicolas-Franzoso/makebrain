# Funnel Design

- `skill_id`: `funnel-design`
- `agent_id`: `makeads-planner-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Scaffold operacional para a skill `funnel-design` do agente Agente Planner de Midia.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
