# New Campaign Trigger

- `skill_id`: `new-campaign-trigger`
- `agent_id`: `makeads-expansion-agent`
- `layer`: `specialist`
- `pillar`: `makeads`

## Purpose

Scaffold operacional para a skill `new-campaign-trigger` do agente Agente de Expansao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
