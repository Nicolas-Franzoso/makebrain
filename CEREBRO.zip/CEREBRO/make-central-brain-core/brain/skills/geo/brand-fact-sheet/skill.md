# Brand Fact Sheet

- `skill_id`: `brand-fact-sheet`
- `agent_id`: `geo-entity-agent`
- `layer`: `specialist`
- `pillar`: `geo`

## Purpose

Scaffold operacional para a skill `brand-fact-sheet` do agente Agente de Reforco de Entidade.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
