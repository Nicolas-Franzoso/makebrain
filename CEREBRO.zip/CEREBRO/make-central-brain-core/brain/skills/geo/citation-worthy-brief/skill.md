# Citation Worthy Brief

- `skill_id`: `citation-worthy-brief`
- `agent_id`: `geo-citable-content-agent`
- `layer`: `specialist`
- `pillar`: `geo`

## Purpose

Scaffold operacional para a skill `citation-worthy-brief` do agente Agente de Conteudo Citavel.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
