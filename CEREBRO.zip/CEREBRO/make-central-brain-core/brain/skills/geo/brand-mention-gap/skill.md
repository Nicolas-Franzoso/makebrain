# Brand Mention Gap

- `skill_id`: `brand-mention-gap`
- `agent_id`: `geo-presence-agent`
- `layer`: `specialist`
- `pillar`: `geo`

## Purpose

Scaffold operacional para a skill `brand-mention-gap` do agente Agente de Presenca em Ambientes Generativos.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
