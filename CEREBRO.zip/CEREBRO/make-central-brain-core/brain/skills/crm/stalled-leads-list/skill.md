# Stalled Leads List

- `skill_id`: `stalled-leads-list`
- `agent_id`: `crm-reactivation-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `stalled-leads-list` do agente Agente de Reativacao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
