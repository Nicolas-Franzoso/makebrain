# Lost Reason Cluster

- `skill_id`: `lost-reason-cluster`
- `agent_id`: `crm-pipeline-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `lost-reason-cluster` do agente Agente de Pipeline.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
