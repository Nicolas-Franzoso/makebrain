from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `lost-reason-cluster`."""
    return {
        'skill_id': 'lost-reason-cluster',
        'status': 'scaffold',
        'payload': payload,
    }
