# Attendance Capacity Watch

- `skill_id`: `attendance-capacity-watch`
- `agent_id`: `crm-sla-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `attendance-capacity-watch` do agente Agente de SLA Comercial.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
