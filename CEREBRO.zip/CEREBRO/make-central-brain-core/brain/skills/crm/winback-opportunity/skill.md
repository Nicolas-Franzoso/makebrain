# Winback Opportunity

- `skill_id`: `winback-opportunity`
- `agent_id`: `crm-reactivation-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `winback-opportunity` do agente Agente de Reativacao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `True`
- Retry behavior: `exponential-backoff`
