from __future__ import annotations

from typing import Any


def run(payload: dict[str, Any]) -> dict[str, Any]:
    """Generated scaffold for `response-time-alert`."""
    return {
        'skill_id': 'response-time-alert',
        'status': 'scaffold',
        'payload': payload,
    }
