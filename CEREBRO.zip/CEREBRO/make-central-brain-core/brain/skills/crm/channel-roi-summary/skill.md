# Channel Roi Summary

- `skill_id`: `channel-roi-summary`
- `agent_id`: `crm-attribution-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `channel-roi-summary` do agente Agente de Atribuicao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
