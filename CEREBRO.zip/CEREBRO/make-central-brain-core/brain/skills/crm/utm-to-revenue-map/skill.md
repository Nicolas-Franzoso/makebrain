# Utm To Revenue Map

- `skill_id`: `utm-to-revenue-map`
- `agent_id`: `crm-attribution-agent`
- `layer`: `specialist`
- `pillar`: `crm`

## Purpose

Scaffold operacional para a skill `utm-to-revenue-map` do agente Agente de Atribuicao.

## Inputs

- `client_id`
- `payload`

## Context Dependencies

- `00_profile.md`
- `01_brand_voice.md`

## Output

- Shape: `artifact-or-alert`
- Approval required: `False`
- Retry behavior: `exponential-backoff`
