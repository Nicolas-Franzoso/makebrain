"""Agent-facing helpers and facades."""

