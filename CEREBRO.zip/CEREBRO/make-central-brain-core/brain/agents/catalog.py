from brain.platform.registry import load_agents, load_skills


def summarize_agent_surface() -> dict:
    return {
        "agents": [agent.model_dump(mode="json") for agent in load_agents()],
        "skills": [skill.model_dump(mode="json") for skill in load_skills()],
    }

