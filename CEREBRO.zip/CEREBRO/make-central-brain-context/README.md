# Make Central Brain Context

Repositório da memória oficial dos clientes em Markdown.

## Convenções

- Um diretório por cliente em `clients/<slug>/`
- Arquivos canônicos com frontmatter completo
- Notas diárias sempre append-only em `07_history/daily/`
- Artefatos aprovados em `08_artifacts/`

