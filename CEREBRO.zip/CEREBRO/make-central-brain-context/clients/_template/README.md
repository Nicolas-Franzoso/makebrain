# Template de novo cliente

Crie uma pasta `clients/<slug>/` e preencha pelo menos:

- `00_profile.md`
- `01_brand_voice.md`
- `02_business_model.md`
- `03_offer_stack.md`
- `09_rules_and_constraints.md`
- `07_history/daily/<data>/<timestamp>-onboarding.md`

Depois adicione os arquivos de `04_channels/` conforme os produtos contratados.

