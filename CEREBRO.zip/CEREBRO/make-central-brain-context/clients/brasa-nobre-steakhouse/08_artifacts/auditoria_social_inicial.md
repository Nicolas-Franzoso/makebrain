---
client_id: brasa-nobre-steakhouse
artifact_type: social-profile-audit
title: Auditoria Social Inicial
created_at: 2026-04-14T21:05:00-03:00
metadata:
  status: draft
  source: social-onboarding-agent
  approved_by: null
---

# Auditoria Social Inicial

## Leitura geral da conta

A Brasa Nobre Steakhouse tem base suficiente para operar Social com intencao comercial e de posicionamento sem precisar recorrer a linguagem promocional ou desconto barato. O contexto consolidado aponta uma marca de steakhouse premium acessivel, com foco em experiencia, desejo, ambiente bonito, carne de qualidade, drinks e atendimento seguro.

Hoje, a principal lacuna nao e falta de ativo ou falta de produto. A lacuna e transformacao de presenca visual em percepcao de valor e, depois, em demanda previsivel para jantar e comemoracoes.

## Objetivo do pilar social

O papel do Social neste cliente e:

- sustentar posicionamento premium acessivel
- aumentar desejo e lembranca de marca
- reforcar prova visual da experiencia
- preparar o publico para reserva via Instagram e WhatsApp
- criar recorrencia narrativa para jantar, date night e comemoracoes

## Pontos fortes identificados

- Produto com forte potencial visual: carne, fogo, corte, drinks e ambiente
- Proposta de experiencia clara e coerente com o publico-alvo
- Acervo inicial disponivel: fotos profissionais, videos curtos, conteudos de pratos, drinks, ambiente e depoimentos
- Tom de voz bem definido: elegante, convidativo, apetitoso e seguro
- Aprovação centralizada, o que facilita consistencia editorial inicial

## Fragilidades atuais

- Instagram sem calendario fixo e sem intencao editorial clara
- Oscilacao de engajamento e baixa conversao percebida em reserva
- Ausencia de linha editorial nitida por ocasiao
- Falta de amarracao entre conteudo organico e objetivo de negocio
- Dependencia de resposta rapida no WhatsApp para nao perder demanda gerada pelo conteudo

## Leitura de posicionamento

A marca nao deve competir como restaurante de promocao, combo barato ou urgencia artificial. O caminho certo e comunicar:

- experiencia premium acessivel
- desejo real de consumo
- ambiente bonito e acolhedor
- jantar que vale a saida
- local adequado para comemorar bem

O Social precisa fazer o publico sentir que a Brasa Nobre e:

- uma escolha segura para uma boa noite
- um lugar desejavel para jantar a dois
- uma opcao forte para pequenos grupos e aniversarios
- uma casa com ritual, atmosfera e memoria

## Territorios editoriais prioritarios

### 1. Desejo e apetite

Conteudos com carne na brasa, corte, textura, fumaca, montagem da mesa e drinks.

### 2. Experiencia e ambiente

Conteudos que mostram atmosfera, salao, iluminacao, detalhes e sensacao de ocasiao especial.

### 3. Ocasioes de consumo

Date night, jantar de fim de semana, comemoracao pequena, aniversario e encontro de amigos.

### 4. Prova social e confianca

Depoimentos, reacoes, cenas de clientes e sinais de atendimento acolhedor.

### 5. Bastidor com acabamento premium

Preparacao, equipe, cuidado com servico e elementos que reforcem autenticidade sem perder sofisticacao.

## O que parece funcionar melhor

Pela R1, os reels de carne na parrilla e ambientacao ja performam melhor do que outras linhas. Isso sugere que:

- conteudo sensorial deve ser o eixo central
- video curto precisa ser formato prioritario
- o perfil deve vender atmosfera, nao apenas cardapio
- posts precisam ter mais intencao de reserva e menos cara de publicacao solta

## O que deve ser evitado

- linguagem desesperada
- excesso de promocao
- cara de cupom
- comunicacao popular demais para o ticket e proposta da casa
- feed sem coerencia entre desejo, prova e reserva
- conteudo generico de restaurante sem diferencial visual

## Hipoteses editoriais iniciais

### Hipotese 1

Conteudos com fogo, carne, corte e close de textura devem liderar alcance e retencao.

### Hipotese 2

Conteudos de ambiente e date night devem ajudar a qualificar melhor o publico de jantar.

### Hipotese 3

Conteudos de comemoracao e aniversarios tendem a puxar publico de maior ticket se tiverem promessa visual clara.

### Hipotese 4

Prova social combinada com ambiente deve melhorar confianca e conversao em conversa.

## Direcao visual inicial

- predominancia de tons quentes, madeira, fogo e mesa posta
- enquadramentos fechados em carne, drinks e detalhes de atmosfera
- menos grid frio de cardapio e mais sensacao de experiencia
- equilibrio entre sofisticação e acolhimento
- acabamento premium sem parecer inacessivel

## Direcao de copy inicial

A copy deve:

- convidar em vez de pressionar
- vender experiencia em vez de desconto
- ter CTA claro quando fizer sentido
- reforcar desejo, ocasiao e prova
- manter elegancia sem ficar fria

Exemplos de territorio de mensagem:

- o jantar que muda o ritmo da semana
- uma mesa pronta para celebrar bem
- carne, ambiente e drinks no ponto certo
- sua proxima noite especial pode comecar aqui

## Bloqueios operacionais atuais

- conexao Meta para Social ainda pendente
- ainda falta validar se a sobremesa gratuita para aniversariantes possui alguma condicao operacional de uso
- ainda falta confirmar se existe limite de mesas, formato de reserva ou regra especifica para divulgacao de aniversarios

## Perguntas minimas para destravar o proximo lote

1. A sobremesa gratuita para aniversariantes exige alguma regra adicional, como numero minimo de pessoas ou apresentacao de documento?
2. Existe alguma condicao que o conteudo nao pode prometer sobre reserva, tempo de permanencia ou disponibilidade?
3. O almoco executivo tambem deve entrar no primeiro ciclo de conteudo ou fica para a segunda leva?

## Proximos artefatos recomendados

1. `briefing_social.md`
2. `posts_iniciais.md`
3. `tutorial_conexao_meta_social.md`

## Conclusao

A Brasa Nobre tem um contexto raro para Social: boa materia-prima de marca, bom produto, ativos disponiveis e uma tese comercial clara. O desafio nao e inventar posicionamento, e disciplinar a execucao para que o perfil deixe de ser apenas bonito e passe a funcionar como instrumento de desejo, prova e preparacao de reserva.
