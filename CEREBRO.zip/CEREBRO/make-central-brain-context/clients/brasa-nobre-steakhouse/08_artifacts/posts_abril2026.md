---
client_id: brasa-nobre-steakhouse
artifact_type: social-monthly-post-batch
title: Posts Abril 2026
created_at: 2026-04-14T21:35:00-03:00
metadata:
  status: draft
  source: social-copy-agent
  approved_by: null
---

# Lote de Posts - Abril 2026

## Cabecalho do lote

- Cliente: Brasa Nobre Steakhouse
- Periodo: Abril de 2026
- Contexto SHA: `workspace`
- Fontes lidas:
  - `00_profile.md`
  - `01_brand_voice.md`
  - `02_business_model.md`
  - `03_offer_stack.md`
  - `04_channels/social.md`
  - `04_channels/makeads.md`
  - `05_sales_crm.md`
  - `07_history/daily/2026-04-14/195254-growth-onboarding-inicial.md`
  - `08_artifacts/auditoria_social_inicial.md`
  - `08_artifacts/briefing_social.md`
  - `08_artifacts/posts_iniciais.md`
  - `08_artifacts/2026-04-14-plano-de-midia-v1.html`
- Assuncoes:
  - o ciclo inicial vai priorizar jantar e comemoracoes antes de dar protagonismo ao almoco executivo
  - a sobremesa gratuita para aniversariantes sera comunicada de forma sutil, sem promessas adicionais nao confirmadas
  - o WhatsApp seguira como CTA principal para reserva

## Resumo estrategico

- Foco do mes: transformar o Instagram em vitrine de desejo, ocasiao e prova para reservas
- Pilares editoriais:
  - carne e apetite
  - ambiente e atmosfera
  - jantar e date night
  - aniversarios e comemoracoes
  - prova social e atendimento
- Distribuicao por formato:
  - 5 reels
  - 5 carrosseis
  - 2 posts unicos

## Grade de posts

### Post 1

- Data sugerida: 15/04/2026
- Formato: Reel
- Objetivo: abrir o ciclo com desejo forte e assinatura visual
- Hook: `Nao e so jantar. E a noite que comeca no fogo e termina em memoria.`
- Roteiro:
  - Cena 1: fogo subindo na grelha
    Copy: `Tem noites que comecam antes da primeira mordida.`
  - Cena 2: close do corte sendo finalizado
    Copy: `No calor da brasa, o desejo ganha forma.`
  - Cena 3: drink servido
    Copy: `Carne, drinks e atmosfera no ponto certo.`
  - Cena 4: mesa pronta e ambiente aceso
    Copy: `Uma experiencia para viver sem pressa.`
  - Cena 5: texto em tela com convite para reserva
    Copy: `Brasa Nobre Steakhouse. Reserve sua mesa no WhatsApp.`
- CTA: `Reserve sua mesa no WhatsApp`
- Referencia visual descritiva: cortes de carne, fumaca, drink e ambiente em luz quente
- Referencia de conteudo: apresentar a Brasa Nobre como experiencia premium acessivel
- Observacao de aprovacao humana: Pendente

### Post 2

- Data sugerida: 17/04/2026
- Formato: Carrossel
- Objetivo: reforcar contexto de date night
- Hook: `Tem noites que pedem mais do que um restaurante.`
- Estrutura:
  - Slide 1: frase principal sobre experiencia
    Copy: `Tem noites que pedem mais do que um restaurante.`
  - Slide 2: ambiente e mesa posta
    Copy: `Pedem um ambiente que acolhe no primeiro olhar.`
  - Slide 3: carne e drink como dupla da noite
    Copy: `Pedem carne no ponto certo e drinks que acompanham a experiencia.`
  - Slide 4: convite para viver isso a dois
    Copy: `Pedem uma mesa onde o jantar vira memoria a dois.`
  - Slide 5: CTA de reserva
    Copy: `Se a noite pede isso, sua mesa pode estar aqui. Reserve no WhatsApp.`
- CTA: `Fale com a Brasa Nobre e reserve seu jantar`
- Referencia visual descritiva: casal, ambiente, tacas, cortes e detalhes de mesa
- Referencia de conteudo: jantar a dois como experiencia segura e memoravel
- Observacao de aprovacao humana: Pendente

### Post 3

- Data sugerida: 20/04/2026
- Formato: Reel
- Objetivo: abrir narrativa de aniversarios
- Hook: `Aniversario bom e aquele que ja comeca com a mesa certa.`
- Roteiro:
  - Cena 1: grupo chegando
    Copy: `Algumas datas pedem mais do que um parabens.`
  - Cena 2: mesa servida
    Copy: `Pedem uma mesa pronta para celebrar bem.`
  - Cena 3: brinde
    Copy: `Um ambiente bonito, comida marcante e gente querida por perto.`
  - Cena 4: sobremesa chegando para o aniversariante
    Copy: `E um detalhe especial para deixar a noite ainda mais memoravel.`
  - Cena 5: convite para organizar a comemoracao
    Copy: `Na Brasa Nobre, seu aniversario pode comecar daqui. Chame no WhatsApp.`
- CTA: `Chame no WhatsApp e organize sua comemoracao`
- Referencia visual descritiva: grupo pequeno, sobremesa, clima elegante e acolhedor
- Referencia de conteudo: mostrar a Brasa Nobre como lugar ideal para celebrar bem
- Observacao de aprovacao humana: Pendente

### Post 4

- Data sugerida: 22/04/2026
- Formato: Post unico
- Objetivo: gerar prova social e confianca
- Hook: `Quando a comida impressiona, o ambiente acolhe e o atendimento acompanha, a experiencia fica completa.`
- Legenda ou roteiro: `Na Brasa Nobre, cada detalhe importa. Do corte servido no ponto certo ao ambiente que convida a ficar mais um pouco, passando pelo atendimento que faz a experiencia acontecer com leveza. Quando comida, atmosfera e cuidado caminham juntos, jantar deixa de ser rotina e vira memoria. Se voce procura um lugar para viver isso em Sao Paulo, sua mesa pode comecar aqui.`
- CTA: `Conheca a Brasa Nobre e reserve sua mesa`
- Referencia visual descritiva: prato hero, drink, ambiente e momento real de cliente
- Referencia de conteudo: prova de experiencia, nao apenas refeicao
- Observacao de aprovacao humana: Pendente

### Post 5

- Data sugerida: 24/04/2026
- Formato: Reel
- Objetivo: reforcar apetite e ritual da carne
- Hook: `O tipo de corte que faz o olhar chegar antes da primeira mordida.`
- Roteiro:
  - Cena 1: faca entrando no corte
    Copy: `Tem carne que ja convence no primeiro corte.`
  - Cena 2: close da textura
    Copy: `Textura, suculencia e fogo falando por si.`
  - Cena 3: grelha e finalizacao
    Copy: `Na brasa, o desejo encontra o ponto certo.`
  - Cena 4: prato servido na mesa
    Copy: `E a mesa recebe muito mais do que um prato.`
  - Cena 5: assinatura da casa
    Copy: `Recebe uma experiencia Brasa Nobre.`
- CTA: `Reserve seu jantar`
- Referencia visual descritiva: close extremo de carne e finalizacao
- Referencia de conteudo: desejo sensorial e autoridade de produto
- Observacao de aprovacao humana: Pendente

### Post 6

- Data sugerida: 27/04/2026
- Formato: Carrossel
- Objetivo: apresentar os pilares da experiencia Brasa Nobre
- Hook: `O que faz uma noite valer a reserva?`
- Estrutura:
  - Slide 1: pergunta principal
    Copy: `O que faz uma noite valer a reserva?`
  - Slide 2: carne
    Copy: `Uma carne que chama atencao antes mesmo da primeira mordida.`
  - Slide 3: ambiente
    Copy: `Um ambiente que faz voce querer ficar mais um pouco.`
  - Slide 4: drinks
    Copy: `Drinks que completam o ritmo da experiencia.`
  - Slide 5: atendimento
    Copy: `Um atendimento que acolhe sem excessos.`
  - Slide 6: convite final
    Copy: `Quando tudo isso se encontra, a noite acontece. Viva a Brasa Nobre.`
- CTA: `Viva essa experiencia na Brasa Nobre`
- Referencia visual descritiva: cada slide com um pilar visual da experiencia
- Referencia de conteudo: traduzir valor percebido sem falar de desconto
- Observacao de aprovacao humana: Pendente

### Post 7

- Data sugerida: 29/04/2026
- Formato: Reel
- Objetivo: mostrar bastidor premium com autenticidade
- Hook: `Antes de chegar a mesa, cada detalhe ja estava sendo pensado.`
- Roteiro:
  - Cena 1: equipe preparando o ambiente
    Copy: `Uma boa noite comeca muito antes da primeira reserva.`
  - Cena 2: drink sendo montado
    Copy: `Comeca no cuidado com cada detalhe.`
  - Cena 3: grelha em acao
    Copy: `No fogo, no ponto, na escolha certa.`
  - Cena 4: prato saindo
    Copy: `Comeca no que chega a mesa com intencao.`
  - Cena 5: salao recebendo clientes
    Copy: `Porque experiencia se constrói antes mesmo do primeiro brinde.`
- CTA: `Fale com a Brasa Nobre no WhatsApp`
- Referencia visual descritiva: bastidor limpo, premium e acolhedor
- Referencia de conteudo: humanizar sem perder sofisticacao
- Observacao de aprovacao humana: Pendente

### Post 8

- Data sugerida: 01/05/2026
- Formato: Carrossel
- Objetivo: reforcar a ocasiao de jantar com amigos
- Hook: `Tem encontros que pedem uma mesa a altura.`
- Estrutura:
  - Slide 1: frase principal
    Copy: `Tem encontros que pedem uma mesa a altura.`
  - Slide 2: grupo em ambiente bonito
    Copy: `Um lugar bonito para reunir quem faz a noite valer.`
  - Slide 3: carne compartilhada
    Copy: `Carne no centro da mesa, conversa fluindo e tempo bem vivido.`
  - Slide 4: drinks e conversa
    Copy: `Drinks, atmosfera e o tipo de energia que nao se improvisa.`
  - Slide 5: CTA para reservar
    Copy: `Se a proxima noite merece isso, reserve sua mesa na Brasa Nobre.`
- CTA: `Reserve sua mesa para a proxima noite`
- Referencia visual descritiva: grupo pequeno, mesa cheia e atmosfera noturna
- Referencia de conteudo: encontros de amigos como momento de consumo
- Observacao de aprovacao humana: Pendente

### Post 9

- Data sugerida: 04/05/2026
- Formato: Post unico
- Objetivo: dar clareza operacional sem perder charme
- Hook: `De segunda a sexta, a Brasa Nobre espera por voce no almoco e no jantar.`
- Legenda ou roteiro: `De segunda a sexta, a Brasa Nobre abre a mesa para dois ritmos diferentes do dia. No almoco, das 11h as 14h. No jantar, das 18h as 22h, com a experiencia da casa no centro de tudo. Se voce quer se programar para viver isso com mais calma, fale com a nossa equipe no WhatsApp e organize sua reserva.`
- CTA: `Consulte sua reserva no WhatsApp`
- Referencia visual descritiva: ambiente da casa com tipografia elegante e horarios discretos
- Referencia de conteudo: utilidade com acabamento premium
- Observacao de aprovacao humana: Pendente

### Post 10

- Data sugerida: 06/05/2026
- Formato: Reel
- Objetivo: conectar drinks e experiencia da casa
- Hook: `Uma boa noite tambem se serve em uma boa taca.`
- Roteiro:
  - Cena 1: bartender finalizando drink
    Copy: `Algumas noites pedem mais do que um prato bem servido.`
  - Cena 2: close da bebida
    Copy: `Pedem um drink a altura da experiencia.`
  - Cena 3: drink chegando a mesa com a carne
    Copy: `Porque quando a mesa ganha ritmo, a noite muda de tom.`
  - Cena 4: ambiente vivo
    Copy: `Carne, ambiente e taca no momento certo.`
  - Cena 5: convite para viver a experiencia
    Copy: `Na Brasa Nobre, cada detalhe convida voce a ficar.`
- CTA: `Viva essa experiencia na Brasa Nobre`
- Referencia visual descritiva: drinks, brilho, gelo, luz quente e mesa posta
- Referencia de conteudo: reforcar ritual e ticket percebido
- Observacao de aprovacao humana: Pendente

### Post 11

- Data sugerida: 08/05/2026
- Formato: Carrossel
- Objetivo: trabalhar aniversario sem apelo promocional
- Hook: `Comemorar bem tambem e saber escolher o lugar certo.`
- Estrutura:
  - Slide 1: frase principal
    Copy: `Comemorar bem tambem e saber escolher o lugar certo.`
  - Slide 2: ambiente para celebrar
    Copy: `Um ambiente bonito muda o clima da data desde o primeiro minuto.`
  - Slide 3: mesa e pratos
    Copy: `A mesa certa deixa a experiencia mais gostosa para todo mundo.`
  - Slide 4: sobremesa do aniversariante
    Copy: `E o aniversariante ainda ganha um detalhe especial para adoçar a noite.`
  - Slide 5: convite para organizar a data
    Copy: `Se a proxima comemoracao merece isso, fale com a Brasa Nobre no WhatsApp.`
- CTA: `Celebre aqui`
- Referencia visual descritiva: mesa de comemoracao, sobremesa e clima elegante
- Referencia de conteudo: aniversario como experiencia, nao como oferta barata
- Observacao de aprovacao humana: Pendente

### Post 12

- Data sugerida: 11/05/2026
- Formato: Carrossel
- Objetivo: fechar o ciclo com manifesto de marca
- Hook: `Mais do que servir um jantar, a Brasa Nobre serve o tipo de noite que fica na memoria.`
- Estrutura:
  - Slide 1: manifesto principal
    Copy: `Mais do que servir um jantar, a Brasa Nobre serve o tipo de noite que fica na memoria.`
  - Slide 2: carne
    Copy: `Na carne que chama atencao pelo aroma, pela textura e pelo ponto.`
  - Slide 3: ambiente
    Copy: `No ambiente que recebe sem excessos e acolhe com elegancia.`
  - Slide 4: atendimento
    Copy: `No atendimento que faz a experiencia acontecer com leveza.`
  - Slide 5: reserva
    Copy: `Quando tudo isso se encontra, a reserva faz sentido. Sua mesa pode comecar aqui.`
- CTA: `Reserve sua proxima noite`
- Referencia visual descritiva: compilado de carne, ambiente, drinks e atendimento
- Referencia de conteudo: consolidar posicionamento premium acessivel
- Observacao de aprovacao humana: Pendente

## Aprovacao Humana

Pendente

## Riscos ou dependencias

- validar se a sobremesa gratuita para aniversariantes tem condicoes especificas antes de publicar
- confirmar se o almoco executivo deve ganhar mais peso no lote seguinte
- garantir que a operacao de WhatsApp mantenha velocidade de resposta coerente com o volume gerado

## O que precisa ser validado pelo gestor

- uso da oferta de sobremesa para aniversariantes
- tom final das legendas de aniversario
- prioridades entre date night, grupos e jantar recorrente

## O que pode ser reaproveitado por MakeADS, SEO ou CRM

- ganchos de date night e comemoracao podem virar criativos de topo e fundo para MakeADS
- provas de experiencia e atendimento podem alimentar landing pages e FAQs
- temas de reserva, aniversario e ocasiao podem orientar CRM e respostas comerciais
