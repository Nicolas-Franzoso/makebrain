---
client_id: brasa-nobre-steakhouse
artifact_type: social-briefing
title: Briefing Social
created_at: 2026-04-14T21:20:00-03:00
metadata:
  status: draft
  source: social-onboarding-agent
  approved_by: null
---

# Briefing Social

## Papel do pilar social

O Social da Brasa Nobre deve fortalecer posicionamento, desejo e prova de experiencia para alimentar reservas vindas do Instagram e do WhatsApp. O objetivo nao e apenas publicar com consistencia, e sim transformar o perfil em vitrine de atmosfera, ocasiao e confianca.

## Objetivo dos proximos 90 dias

- aumentar reservas vindas do digital
- reforcar jantar como produto principal
- sustentar aniversarios e comemoracoes pequenas como frente de maior ticket
- preparar o publico para reservar via Instagram e WhatsApp

## Prioridades de negocio refletidas no conteudo

### Prioridade 1

Jantar de segunda a sexta, com foco especial em desejo, ambiente e convite para reserva.

### Prioridade 2

Aniversarios e comemoracoes pequenas, usando a sobremesa gratuita para aniversariantes como detalhe de valor e nao como promocao agressiva.

### Prioridade 3

Almoco executivo como frente de apoio, sem disputar protagonismo com o jantar neste primeiro ciclo.

## Publico principal

- casais de 28 a 45 anos
- grupos de amigos
- familias pequenas
- publico de classe media alta e alta
- pessoas que circulam por Moema, Vila Olimpia, Brooklin e Itaim

## Percepcao desejada de marca

- premium acessivel
- elegante sem ser fria
- apetitosa
- convidativa
- segura para uma boa experiencia

## Territorios editoriais obrigatorios

1. Carne e desejo
2. Ambiente e atmosfera
3. Ocasioes especiais
4. Drinks e ritual da experiencia
5. Prova social e atendimento

## Direcao visual

- foco em tons quentes, fogo, textura e mesa posta
- prioridade para video curto e conteudo sensorial
- cenas que facam a pessoa se imaginar no local
- equilibrio entre sofisticacao e acolhimento

## Direcao de copy

- convidar mais do que pressionar
- vender experiencia antes de preco
- reforcar ocasiao e atmosfera
- ter CTA claro quando a peca pedir reserva
- evitar tom popular demais ou promocional demais

## Regras de comunicacao

- nao usar linguagem desesperada
- nao parecer restaurante de desconto
- nao transformar a sobremesa do aniversariante em cupom barato
- validar qualquer promessa de reserva, horario ou beneficio antes de publicar

## Dados confirmados para execucao

- Instagram oficial: `@brasanobresteakhouse`
- Atendimento de almoco: segunda a sexta, das 11h as 14h
- Atendimento de jantar: segunda a sexta, das 18h as 22h
- Beneficio confirmado: sobremesa gratuita para aniversariantes

## CTA prioritarios

- reserve sua mesa
- fale com a Brasa Nobre no WhatsApp
- celebre aqui
- viva essa experiencia

## Resultado esperado do primeiro ciclo

O primeiro lote de conteudo deve deixar claro que a Brasa Nobre e:

- uma escolha forte para jantar bem
- um lugar desejavel para celebrar
- uma casa com boa experiencia, boa comida e atmosfera certa

## Aprovacao

Aprovacao humana pendente antes de qualquer publicacao.
