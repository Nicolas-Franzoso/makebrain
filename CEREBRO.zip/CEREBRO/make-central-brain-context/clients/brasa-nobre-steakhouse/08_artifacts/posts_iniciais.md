---
client_id: brasa-nobre-steakhouse
artifact_type: social-initial-posts
title: Posts Iniciais
created_at: 2026-04-14T21:20:00-03:00
metadata:
  status: draft
  source: social-onboarding-agent
  approved_by: null
---

# Posts Iniciais

## Post 1

- Objetivo: abrir o ciclo com desejo forte e assinatura visual da casa
- Formato sugerido: Reel curto
- Hook: `Nao e so jantar. E a noite que comeca no fogo e termina em memoria.`
- Referencia visual descritiva: cortes de carne na brasa, close de textura, fumaca subindo, drink sendo finalizado e mesa servida em luz quente
- Referencia de conteudo: apresentar a Brasa Nobre como experiencia premium acessivel para quem quer jantar bem em Sao Paulo
- CTA: `Reserve sua mesa no WhatsApp`
- Aprovacao humana pendente

## Post 2

- Objetivo: reforcar atmosfera e contexto de date night
- Formato sugerido: Carrossel
- Hook: `Tem noites que pedem mais do que um restaurante.`
- Referencia visual descritiva: ambiente da casa, detalhes da mesa, taças, luz, cortes prontos e casal vivendo a experiencia
- Referencia de conteudo: comunicar a Brasa Nobre como escolha segura para um jantar a dois com carne, drinks e ambiente no ponto certo
- CTA: `Fale com a Brasa Nobre e reserve seu jantar`
- Aprovacao humana pendente

## Post 3

- Objetivo: abrir a narrativa de aniversarios e comemoracoes pequenas
- Formato sugerido: Reel ou video curto
- Hook: `Aniversario bom e aquele que ja comeca com a mesa certa.`
- Referencia visual descritiva: grupo pequeno brindando, sobremesa chegando a mesa, clima de comemoracao elegante e acolhedor
- Referencia de conteudo: posicionar a Brasa Nobre como lugar ideal para celebrar bem, com destaque sutil para sobremesa gratuita do aniversariante
- CTA: `Chame no WhatsApp e organize sua comemoracao`
- Aprovacao humana pendente

## Post 4

- Objetivo: gerar prova social e confianca na experiencia
- Formato sugerido: Carrossel ou post estatico com apoio de legenda forte
- Hook: `Quando a comida impressiona, o ambiente acolhe e o atendimento acompanha, a experiencia fica completa.`
- Referencia visual descritiva: combinacao de prato hero, drink, ambiente e momento real de cliente ou depoimento visualmente bem enquadrado
- Referencia de conteudo: reforcar que a Brasa Nobre entrega experiencia completa e nao apenas refeicao
- CTA: `Conheca a Brasa Nobre e reserve sua mesa`
- Aprovacao humana pendente
