---
client_id: brasa-nobre-steakhouse
artifact_type: media-plan-superseded
title: Plano de Midia Inicial v0 - superseded
created_at: 2026-04-14T20:05:00-03:00
metadata:
  status: superseded
  source: codex
  approved_by: null
  superseded_by: 2026-04-14-plano-de-midia-v1.html
---

# Artefato superseded

Este rascunho inicial nao segue a skill oficial `plano-de-midia-make` e foi substituido por:

- `08_artifacts/2026-04-14-plano-de-midia-v1.html`

Use apenas a versao em HTML para revisao humana e aprovacao do plano.
