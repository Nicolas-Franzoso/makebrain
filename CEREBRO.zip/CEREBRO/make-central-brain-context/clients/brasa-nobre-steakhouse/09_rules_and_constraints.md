---
client_id: brasa-nobre-steakhouse
slug: brasa-nobre-steakhouse
name: Brasa Nobre Steakhouse
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
- social
approval_policy: human-required
stage: onboarding
main_goals:
- Aumentar o volume de reservas vindas do digital e transformar Instagram e WhatsApp
  em canais previsiveis de demanda, com foco principal em jantar e aniversarios nos
  proximos 90 dias.
primary_kpis:
- reservas_confirmadas
- conversas_qualificadas_no_whatsapp
- custo_por_reserva
- taxa_de_conversao_ig_e_whatsapp_em_reserva
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Politica de aprovacao

Nenhuma acao externa critica sem aprovacao humana.

# Rotina de alinhamento

Checkpoint semanal

# Observacoes

R1 incorporada. Direcao estrategica: usar MakeADS para gerar demanda com foco em reserva e WhatsApp e Social para sustentar posicionamento, desejo, prova e recorrencia. Prioridade comercial em jantar e aniversarios; almoco executivo entra como apoio. Pendencias principais: confirmar acessos Meta, rotina operacional de resposta no WhatsApp, disponibilidade de agenda para reservas e eventual playbook de atendimento para reduzir perda por demora na resposta.
