---
client_id: brasa-nobre-steakhouse
author: growth
created_at: 2026-04-14T19:52:54.854620+00:00
kind: daily-note
---

# Onboarding Inicial

## Resumo rapido

- Cliente: Brasa Nobre Steakhouse
- Servicos contratados: makeads, social
- Meta 90 dias: Aumentar o volume de reservas vindas do digital e transformar Instagram e WhatsApp em canais previsiveis de demanda, com foco principal em jantar e aniversarios nos proximos 90 dias.
- Verba de midia: R$ 9.000 por mes

## Transcricao R1

Participantes: Lucas (Growth Make), Mariana Souza (Gestora da Brasa Nobre) e Eduardo Lima (Socio). A Brasa Nobre e uma steakhouse premium em Moema, Sao Paulo, com proposta sofisticada sem ser travada. A experiencia combina carne de alta qualidade, ambiente bonito, atendimento atencioso e carta de drinks bem trabalhada. O carro-chefe e o rodizio premium, com festival de carnes nobres em algumas datas e menu executivo no almoco durante a semana. O momento atual e de consolidacao: o restaurante ja e conhecido na regiao, mas ainda depende muito de indicacao e de cliente recorrente, e a percepcao da equipe e que a presenca digital comunica menos valor do que a experiencia real entrega. O foco principal de negocio hoje e aumentar reservas no jantar, especialmente quinta, sexta, sabado e domingo, e crescer aniversarios e comemoracoes pequenas, publico que costuma gerar ticket maior. O almoco executivo entra como segunda prioridade. O ticket medio do jantar gira entre R$ 120 e R$ 220 por pessoa, podendo subir em aniversarios e mesas maiores. O perfil ideal inclui casais de 28 a 45 anos, grupos de amigos e familias pequenas, de classe media alta e alta, com concentracao em Moema, Vila Olimpia, Brooklin e Itaim, alem de profissionais que trabalham na regiao. As maiores dores hoje sao falta de previsibilidade de demanda, Instagram com boa imagem mas baixa conversao consistente em reservas e pouca clareza sobre a experiencia premium da casa. O conteudo atual e postado em media tres vezes por semana, sem calendario fixo. Reels de carne na parrilla e ambientacao performam melhor. Mariana aprova tudo internamente e uma pessoa operacional publica; nao existe estrategista nem copy dedicada. Em trafego pago, houve apenas impulsionamentos pontuais sem estrategia real. A jornada comercial passa por Instagram, direct e WhatsApp, com perguntas sobre cardapio, valores, reservas, aniversarios e experiencia para casal. Quando o atendimento responde rapido, a reserva acontece; quando demora, a pessoa some. A operacao tem equipe e capacidade para atender a demanda; o desafio e gerar volume com consistencia. Concorrentes observados: Fogo Supremo Grill, Estancia 481, Pampa Fire e Quintal do Churrasco. O tom desejado para a marca e premium acessivel: elegante, convidativo, apetitoso e seguro, sem cara de promocao barata ou comunicacao desesperada. Ativos disponiveis: fotos profissionais, videos curtos de ambiente, pratos, drinks, clientes, depoimentos, identidade visual e cardapio. A meta dos proximos 90 dias e aumentar reservas vindas do digital e transformar Instagram e WhatsApp em canais previsiveis de demanda, com foco principal em jantar e aniversarios. O investimento pode trabalhar com R$ 9.000 de verba de midia dentro de um total de marketing de R$ 18.000 por mes. Restricao central: nao usar comunicacao desesperada, cupom ou desconto barato; a narrativa deve sustentar desejo, prova, ambiente, qualidade e experiencia.
