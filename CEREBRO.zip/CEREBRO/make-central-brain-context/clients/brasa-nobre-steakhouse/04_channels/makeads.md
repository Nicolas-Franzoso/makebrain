---
client_id: brasa-nobre-steakhouse
slug: brasa-nobre-steakhouse
name: Brasa Nobre Steakhouse
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
- social
approval_policy: human-required
stage: onboarding
main_goals:
- Aumentar o volume de reservas vindas do digital e transformar Instagram e WhatsApp
  em canais previsiveis de demanda, com foco principal em jantar e aniversarios nos
  proximos 90 dias.
primary_kpis:
- reservas_confirmadas
- conversas_qualificadas_no_whatsapp
- custo_por_reserva
- taxa_de_conversao_ig_e_whatsapp_em_reserva
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Estado inicial do pilar makeads

## Diretriz-mestra

O plano de midia gerado pela skill oficial `plano-de-midia-make`, versionada dentro do Make Brain, e a referencia principal do growth para campanhas.

## Verba de midia

R$ 9.000 por mes

## R1

A transcricao da R1 esta registrada no historico de onboarding e deve alimentar o plano de midia.
