---
client_id: brasa-nobre-steakhouse
slug: brasa-nobre-steakhouse
name: Brasa Nobre Steakhouse
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
- social
approval_policy: human-required
stage: onboarding
main_goals:
- Aumentar o volume de reservas vindas do digital e transformar Instagram e WhatsApp
  em canais previsiveis de demanda, com foco principal em jantar e aniversarios nos
  proximos 90 dias.
primary_kpis:
- reservas_confirmadas
- conversas_qualificadas_no_whatsapp
- custo_por_reserva
- taxa_de_conversao_ig_e_whatsapp_em_reserva
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Estado inicial do pilar social

## Regra central do pilar

Social Media deve usar a mesma base de contexto global do cliente, sem silo separado de informacao.

## Entregaveis esperados

- `auditoria_social_inicial.md`
- `tutorial_conexao_meta_social.md`
- `briefing_social.md`
- `posts_iniciais.md`
- `posts_<mes><ano>.md`
- `relatorio_<mes><ano>.md`

## Governanca

Nenhuma postagem avanca sem aprovacao humana.

## Dados operacionais confirmados

- Instagram oficial: `@brasanobresteakhouse`
- Atendimento de almoco: segunda a sexta, das 11h as 14h
- Atendimento de jantar: segunda a sexta, das 18h as 22h
- Regra comercial confirmada: sobremesa gratuita para aniversariantes
