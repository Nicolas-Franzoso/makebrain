---
client_id: brasa-nobre-steakhouse
slug: brasa-nobre-steakhouse
name: Brasa Nobre Steakhouse
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
- social
approval_policy: human-required
stage: onboarding
main_goals:
- Aumentar o volume de reservas vindas do digital e transformar Instagram e WhatsApp
  em canais previsiveis de demanda, com foco principal em jantar e aniversarios nos
  proximos 90 dias.
primary_kpis:
- reservas_confirmadas
- conversas_qualificadas_no_whatsapp
- custo_por_reserva
- taxa_de_conversao_ig_e_whatsapp_em_reserva
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Canais da Mavi

- Nao informado

# Material de FAQ e script

Ainda nao disponivel

# Historico de conversa

Ainda nao disponivel