---
client_id: nubia-sushi
slug: nubia-sushi
name: Nubia Sushi
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
approval_policy: human-required
stage: onboarding
main_goals:
- Estruturar uma operacao previsivel de aquisicao para o delivery da Nubia Sushi em
  Barueri, validando criativos com forte apelo de apetite, reduzindo a dependencia
  exclusiva do WhatsApp e criando uma rota mais direta para pedido e recompra.
primary_kpis:
- cpa_pedido
- volume_de_pedidos
- taxa_de_recompra
- participacao_de_pedidos_diretos
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Estado inicial do pilar makeads

## Diretriz-mestra

O plano de midia gerado pela skill local `plano-de-midia-make` e a referencia principal do growth para campanhas.

## Verba de midia

A confirmar no kickoff de midia

## R1

A transcricao da R1 esta registrada no historico de onboarding e deve alimentar o plano de midia.

## Hipotese de rota de conversao

Priorizar uma rota de pedido mais direta que o WhatsApp sempre que a operacao tiver cardapio, link rastreavel ou pagina propria. Enquanto essa rota nao estiver pronta, usar o WhatsApp apenas como contingencia e nao como dependencia unica da aquisicao.

## Direcao inicial de campanhas

- Campanhas focadas em delivery local para Barueri
- Mensagens com forte apelo visual de fome, frescor e desejo imediato
- Prioridade para criativos de produto e combo antes de campanhas institucionais
- Incentivo a primeiro pedido e segunda compra em janela curta
- Separar qualquer frente de eventos em campanha propria, com mensagem e destino diferentes

## Estrutura inicial sugerida

1. Prospeccao local com foco em novos pedidos
2. Remarketing para visitantes, engajados e iniciadores de pedido
3. Recompra para clientes recentes com oferta de conveniencia, combo ou beneficio

## Aprendizados da R1

- O delivery de Barueri e a prioridade real para gerar caixa agora
- Ja existe campanha com destino em WhatsApp, mas sem clareza de retorno e atribuicao
- Existe hipotese forte de que link direto de pedido converta melhor do que WhatsApp para consumidor final
- O material atual parece mais institucional do que apetitoso, entao a criacao precisa mostrar comida, preparo e consumo
- Ticket medio inicial de referencia: R$ 150

## Teste de destino recomendado

1. Link direto de pedido da loja, se existir
2. Ferramenta tipo Anota.ai ou Pede.ai, se a operacao puder adotar
3. WhatsApp como comparativo ou fallback

## Plano de midia vigente

Versao atual para R2: `08_artifacts/2026-04-14-plano-de-midia-v1.html`

Diretriz central:

- Validar criativo de apetite antes de escalar verba
- Testar rota direta de pedido contra o fluxo atual
- Separar delivery e eventos em campanhas diferentes
- Levar Meses 2 e 3 como ativacao condicional, nao automatica
- Usar a v1 do plano como documento-base da R2 e das primeiras campanhas

Artefatos operacionais derivados:

- `08_artifacts/2026-04-14-briefing-criativos-v1.md`
- `08_artifacts/2026-04-14-estrutura-de-campanhas-v1.md`
- `08_artifacts/2026-04-14-copies-anuncios-v1.md`
- `08_artifacts/2026-04-14-checklist-setup-meta-v1.md`
- `08_artifacts/2026-04-14-ordem-de-subida-campanhas-v1.md`

## Bloqueios atuais

- Verba mensal de midia ainda nao confirmada
- Plataforma de pedidos e pagina de destino ainda nao confirmadas
- Acessos da Meta ainda pendentes
- Taxa atual de conversao entre mensagem e pedido ainda desconhecida
