---
client_id: nubia-sushi
artifact_type: setup-checklist
title: Checklist de Setup Meta v1
created_at: 2026-04-14T17:50:00-03:00
metadata:
  status: draft
  source: codex
---

# Checklist de Setup Meta v1

## Acessos

- Confirmar acesso ao Business Manager
- Confirmar acesso a conta de anuncios correta
- Confirmar acesso a pagina do Facebook
- Confirmar acesso ao Instagram da marca
- Confirmar quem aprova criativos e campanhas

## Estrutura tecnica

- Confirmar dominio ou link principal de pedido
- Confirmar se existe pixel ou dataset ativo
- Validar evento minimo de clique no link
- Validar evento de visualizacao de pagina, se houver
- Validar evento de inicio de pedido, se houver plataforma compativel
- Configurar UTMs padrao da conta

## Perfil e ativos

- Ajustar bio com foco em delivery
- Deixar horario de atendimento visivel
- Deixar CTA de pedido visivel
- Confirmar numero de WhatsApp correto
- Confirmar link principal que sera usado na campanha

## Campanhas

- Criar campanha `[NS] [M1] Delivery | Oferta Hero | Barueri`
- Criar conjuntos Broad, Interesses e Engajados
- Subir pelo menos 4 criativos iniciais
- Subir pelo menos 3 variacoes de copy
- Revisar CTA final conforme destino vencedor

## Rastreamento e leitura

- Nomear campanhas, conjuntos e anuncios no padrao definido
- Conferir parametros UTM em todos os anuncios
- Conferir se o clique vai para o destino correto
- Conferir se o WhatsApp abre corretamente, se for usado
- Registrar a data exata de go-live

## Rotina de acompanhamento

- Revisao diaria nos primeiros 7 dias
- Leitura de CTR, CPC e custo por inicio de pedido
- Leitura de destino com melhor resposta
- Pausa de criativos fracos
- Duplicacao dos criativos vencedores

## Bloqueios que impedem subida

- Sem acesso a conta de anuncios
- Sem destino principal definido
- Sem criativos minimos aprovados
- Sem forma de medir clique ou inicio de pedido
