---
client_id: nubia-sushi
artifact_type: media-plan-draft
title: Plano de Midia Inicial v0
created_at: 2026-04-14T12:40:00-03:00
metadata:
  status: draft
  source: codex
  approved_by: null
---

# Plano de Midia Inicial v0

## Objetivo central

Construir uma operacao previsivel de aquisicao para o delivery da Nubia Sushi em Barueri, validando criativos com forte apelo de apetite, reduzindo a dependencia exclusiva do WhatsApp e criando uma rota mais direta para pedido e recompra.

## Leitura estrategica inicial

O ponto de partida da conta nao e somente gerar volume. A operacao precisa provar tres coisas ao mesmo tempo:

1. Quais criativos realmente despertam fome e clique qualificado
2. Qual rota de conversao reduz atrito e aumenta pedidos concluidos
3. Como transformar a primeira compra em recompra com janela curta

Como o contexto ainda esta incompleto, este plano funciona como uma diretriz v0 para kickoff e nao como versao final aprovada. Ainda assim, a R1 real trouxe sinais suficientes para deixar o plano mais objetivo em criativo, rota de pedido e leitura comercial.

## Principais aprendizados da R1

- O foco principal da conta e delivery para consumidor final em Barueri
- Eventos existem, mas devem ficar em frente separada e nao misturados com a campanha de caixa
- Ja ha historico de campanha com destino em WhatsApp
- A equipe percebe pouco retorno do marketing atual
- O material atual parece institucional demais e com baixo apelo de fome
- Existe abertura para testar link direto de pedido, Anota.ai, Pede.ai ou fluxo equivalente
- Ticket medio inicial de referencia: R$ 150
- Meta aspiracional citada em conversa: entre R$ 1.000 e R$ 2.000 por dia em vendas

## Hipoteses principais

### Hipotese 1

Criativos com close forte de produto, textura, molho, corte e montagem devem performar melhor que pecas institucionais ou genéricas.

### Hipotese 2

Uma rota de pedido com menos etapas do que o WhatsApp tende a elevar taxa de conversao, principalmente em janelas de fome imediata.

### Hipotese 3

Combos, barcas e ofertas com ancoragem de valor devem capturar melhor novos compradores do que itens avulsos sem contexto de oferta.

### Hipotese 4

A recompra pode crescer com campanhas separadas para clientes ou engajados recentes, usando argumento de praticidade, desejo e recorrencia.

### Hipotese 5

Separar a comunicacao de delivery e eventos deve melhorar clareza da oferta e reduzir desperdicio de clique em publico com intencoes diferentes.

## Norte de canal

- Geografia inicial: Barueri
- Foco de negocio: delivery
- Canal contratado: makeads
- Prioridade estrategica: pedido direto e recompra
- Canal a reduzir dependencia: WhatsApp
- Destino ideal a validar: link direto de pedido, cardapio proprio, landing page com CTA de pedido ou integracao com plataforma de delivery
- Ticket medio de referencia para planejamento inicial: R$ 150

## Arquitetura inicial de campanhas

### 1. Campanha de prospeccao local

Objetivo:
Gerar novos pedidos em Barueri a partir de criativos de apetite e ofertas com leitura rapida.

Publicos:
- Raio local em Barueri e bairros prioritarios da entrega
- Interesses amplos relacionados a comida japonesa, delivery e consumo noturno
- Publico aberto local, se a base ainda for pequena

Mensagem:
- Pedido rapido
- Produto bonito e apetitoso
- Combo com valor claro
- Conveniencia para almoco, jantar e fim de semana
- Mostrar pessoas comendo, preparo e closes reais sempre que possivel

### 2. Campanha de remarketing quente

Objetivo:
Recapturar pessoas que clicaram, visitaram a rota de pedido, engajaram no Instagram ou iniciaram conversa sem concluir.

Publicos:
- Engajados de redes sociais
- Visitantes da pagina de pedido ou cardapio
- Iniciadores de conversa
- Visualizadores de video

Mensagem:
- Fome do momento
- Prova visual do produto
- Oferta ou incentivo de decisao
- CTA direto para concluir pedido

### 3. Campanha de recompra

Objetivo:
Estimular segunda compra e aumentar frequencia de clientes recentes.

Publicos:
- Base de clientes recentes, se existir
- Lista de compradores ou audiencia de conversao
- Engajados fortes dos ultimos 30 dias

Mensagem:
- Repeticao de um favorito
- Combo para compartilhar
- Beneficio simples para recompra
- Conveniencia e consistencia

### 4. Campanha futura para eventos

Objetivo:
Captar demanda para eventos sem contaminar a comunicacao de delivery.

Observacao:
Nao priorizar agora. So entrar depois que a frente de caixa do delivery estiver organizada ou quando houver verba especifica para isso.

## Sequencia recomendada de ativacao

1. Confirmar qual sera a rota principal de pedido
2. Validar se havera teste entre link direto e WhatsApp
3. Subir criativos de produto e oferta em volume suficiente para teste
4. Rodar prospeccao local primeiro
5. Ligar remarketing assim que houver sinais de trafego e engajamento
6. Preparar recompra assim que a base de pedidos estiver rastreavel

## Estrutura de testes criativos

### Angulos criativos prioritarios

- Apetite extremo: close, brilho, textura, salmao, empanado, cream cheese, molho
- Oferta percebida: combo, barca, combinados, quantidade versus preco
- Momento de consumo: almoco, jantar, sexta, sabado, domingo
- Conveniencia: pedir rapido, receber facil, matar a fome sem friccao
- Prova visual: montagem real, embalagem, variedade, porcao
- Dona ou rosto conhecido da marca apenas se isso de fato agregar autoridade local

### Formatos sugeridos

- Video curto com montagem e closes
- Imagem estatica com combo heroi
- Carrossel com variedade e ticket de entrada
- UGC simples mostrando abertura do pedido e consumo
- Video com chef preparando ou finalizando pecas
- Video com cliente ou convidado consumindo no ponto certo de desejo

### Matriz inicial de teste

Rodar pelo menos:

- 3 criativos focados em close e apetite
- 2 criativos focados em combo e valor percebido
- 2 criativos focados em conveniencia e rapidez
- 1 criativo com prova social ou percepcao de qualidade, se houver material
- 1 variacao com rosto local da marca, somente se a Nubia tiver reconhecimento real na regiao

## Ofertas prioritarias para o primeiro ciclo

- Combinados de sushi
- Temakis
- Barcas e combos para delivery

## Rota de conversao recomendada

Ordem de preferencia:

1. Link direto para cardapio ou checkout rastreavel
2. Landing page simples com CTA unico de pedido
3. Plataforma de delivery com URL rastreavel
4. WhatsApp apenas como fallback temporario

Se a operacao ainda depender de WhatsApp, a recomendacao e medir:

- Clique no anuncio
- Clique para iniciar conversa
- Tempo de resposta
- Conversa iniciada versus pedido fechado
- Ticket medio por conversa iniciada

Se houver teste entre WhatsApp e link direto, comparar:

- Custo por inicio de pedido
- Custo por pedido concluido
- Ticket medio
- Tempo ate concluir a compra

## KPIs iniciais

- CPA por pedido
- Taxa de clique dos criativos
- Taxa de inicio de pedido
- Taxa de conclusao do pedido
- Participacao de pedidos diretos versus WhatsApp
- Taxa de recompra em 7, 15 e 30 dias
- Custo por conversa iniciada
- Receita por campanha, quando houver atribuicao minima

## Leitura comercial inicial

Com ticket medio estimado em R$ 150, a meta de R$ 1.500 por dia equivaleria a cerca de 10 pedidos diarios. A faixa mencionada de R$ 1.000 a R$ 2.000 por dia representa algo entre 7 e 14 pedidos diarios aproximadamente. Isso nao deve ser tratado como projeção fechada ainda, porque falta saber:

- taxa real de conversao entre clique, mensagem e compra
- verba diaria disponivel
- eficiencia da rota de pedido
- capacidade operacional nos horarios de pico

## Faixas de leitura para decisao

Sem verba confirmada, a conta deve ser otimizada por tendencia relativa:

- Criativos com CTR muito acima da media local ganham prioridade
- Destinos com mais inicio de pedido e menos atrito ganham escala
- Publicos com melhor custo por pedido recebem mais verba
- Campanhas de recompra entram so depois de um minimo de volume rastreavel

## Requisitos para fechar a versao v1

- Verba mensal de midia
- Ticket medio final validado
- Plataforma de pedido atual
- Link do cardapio, site ou app de delivery
- Historico de campanhas anteriores
- Acesso ao Meta Business e conta de anuncios
- Pixel, dataset ou evento de conversao disponivel
- Banco de criativos atuais
- Raio real de entrega e bairros prioritarios
- Horarios e dias mais fortes de pedido
- Taxa atual de conversao entre conversa e compra

## Proximas decisoes operacionais

1. Confirmar a rota principal de pedido
2. Definir a oferta hero do primeiro ciclo
3. Separar ativos de prato, combo e bastidores
4. Confirmar verba para teste inicial
5. Configurar rastreio minimo por clique, inicio de pedido e compra
6. Deixar bio e perfil com CTA, horario e canal de pedido mais claros

## Resumo executivo

A Nubia Sushi deve iniciar com uma operacao de MakeADS focada em Barueri, criativos com forte apelo visual de apetite e um teste serio de rota de pedido mais direta do que o WhatsApp. O primeiro objetivo nao e escalar volume a qualquer custo, mas descobrir quais combinacoes de criativo, oferta e destino geram pedido com menos friccao, maior ticket e maior chance de recompra, sem misturar essa frente com a comunicacao de eventos.
