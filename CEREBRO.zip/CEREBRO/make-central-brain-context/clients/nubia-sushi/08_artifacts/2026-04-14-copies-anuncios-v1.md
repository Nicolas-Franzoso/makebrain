---
client_id: nubia-sushi
artifact_type: ad-copy
title: Copies de Anuncios v1
created_at: 2026-04-14T17:35:00-03:00
metadata:
  status: draft
  source: codex
---

# Copies de Anuncios v1

## Diretrizes gerais

- Frases curtas e diretas
- Produto antes de marca
- Fome antes de explicacao
- CTA claro para pedido
- Evitar excesso de texto

## Criativo 1 - Barca Hero

### Copy principal 1

Bateu vontade de sushi? Olha essa barca saindo agora na Nubia Sushi. Delivery em Barueri com muito sabor, variedade e aquele visual que faz pedir na hora. Clique e veja o cardapio.

### Copy principal 2

Se a fome bateu de verdade, comeca por aqui. Barca linda, combinacao caprichada e delivery da Nubia Sushi em Barueri. Peça agora.

### Copy principal 3

Tem coisa que voce olha e ja sabe que vai pedir. Essa barca da Nubia Sushi e uma delas. Clique e escolha seu pedido.

### Headline

- Peça sua barca agora
- Sushi delivery em Barueri
- Seu jantar começa aqui

### Descricao curta

- Barca pronta para pedir hoje
- Delivery com muito sabor e variedade

## Criativo 2 - Combo de Entrada

### Copy principal 1

Quer pedir sushi hoje sem complicar? Comece por um combo da Nubia Sushi e resolva seu jantar com praticidade, sabor e delivery em Barueri. Clique e veja as opcoes.

### Copy principal 2

Pra matar a vontade sem erro: combo pronto, visual bonito e pedido facil. A Nubia Sushi entrega em Barueri. Peça agora.

### Copy principal 3

Se a ideia e comer bem hoje, esse combo resolve. Delivery da Nubia Sushi em Barueri com opções para pedir agora.

### Headline

- Combo ideal para hoje
- Peça seu sushi agora
- Delivery rapido em Barueri

### Descricao curta

- Combo pratico para o jantar
- Seu pedido em poucos cliques

## Criativo 3 - Temaki e Consumo

### Copy principal 1

Temaki bem feito, recheado e saindo na hora. Se bateu vontade de comer sushi hoje, a Nubia Sushi entrega em Barueri. Clique e escolha o seu.

### Copy principal 2

Pra matar a vontade rapido: temaki da Nubia Sushi, feito na hora e com aquele recheio que faz pedir na hora. Peça agora.

### Copy principal 3

Olha esse temaki. Agora imagina isso chegando no seu jantar hoje. Delivery da Nubia Sushi em Barueri. Clique e peça.

### Headline

- Temaki feito na hora
- Peça seu favorito hoje
- Sushi para matar a vontade

### Descricao curta

- Recheio caprichado e pedido facil
- Delivery em Barueri

## Criativo 4 - Chef e Preparo

### Copy principal 1

Aqui o sushi sai assim: preparo na hora, cuidado em cada detalhe e aquele visual que abre o apetite. Peça na Nubia Sushi e receba em Barueri.

### Copy principal 2

Qualidade de verdade aparece no preparo. A Nubia Sushi faz seu pedido com capricho e entrega em Barueri. Clique e veja o cardapio.

### Copy principal 3

Do preparo ao seu pedido: sushi bonito, fresco e pronto para sair. Delivery da Nubia Sushi em Barueri. Peça agora.

### Headline

- Veja como seu sushi sai
- Qualidade que da fome
- Delivery com preparo na hora

### Descricao curta

- Preparo, frescor e sabor
- Clique e veja o cardapio

## Criativo 5 - Prova de Consumo

### Copy principal 1

Nao tem como ver isso e nao ficar com vontade. A Nubia Sushi entrega em Barueri com aquele sushi que chama no visual e confirma no sabor. Peça agora.

### Copy principal 2

Quando a comida fala por si, o pedido vem facil. Nubia Sushi em Barueri com delivery e combinacoes para pedir hoje.

### Copy principal 3

Se voce estava pensando no que pedir hoje, acabou de achar. Nubia Sushi em Barueri. Clique e escolha seu pedido.

### Headline

- Deu vontade? Peça agora
- Seu sushi em Barueri
- Hora de pedir de verdade

### Descricao curta

- Visual que abre o apetite
- Clique e escolha seu pedido

## Copies curtas para story

- Bateu vontade de sushi?
- Peça agora em Barueri
- Combo pronto para hoje
- Seu jantar esta aqui
- Clique e veja o cardapio

## CTAs recomendados

- Peça agora
- Veja o cardapio
- Clique e escolha o seu
- Fazer pedido
- Quero pedir

## Observacao operacional

Se a campanha subir com WhatsApp como comparativo, adaptar o CTA final para conversa apenas nas variacoes em que isso for necessario. Se subir com link direto, manter o CTA sempre orientado a pedido.
