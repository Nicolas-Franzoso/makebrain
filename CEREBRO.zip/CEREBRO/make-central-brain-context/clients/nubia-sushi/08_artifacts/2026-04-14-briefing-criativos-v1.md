---
client_id: nubia-sushi
artifact_type: creative-brief
title: Briefing de Criativos v1
created_at: 2026-04-14T17:20:00-03:00
metadata:
  status: draft
  source: codex
---

# Briefing de Criativos v1

## Objetivo dos criativos

Gerar fome real, clique qualificado e inicio de pedido para o delivery da Nubia Sushi em Barueri, com foco em reduzir a dependencia exclusiva do WhatsApp e validar uma rota de pedido mais direta.

## Regras criativas da conta

- Mostrar comida antes de falar da marca
- Priorizar closes, textura, brilho, corte e montagem
- Mostrar consumo real sempre que possivel
- Evitar video institucional sem produto dominante
- Evitar falar de evento dentro dos criativos de delivery
- CTA sempre orientado a pedido, nao apenas a curiosidade

## Sensacao que o criativo precisa causar

- Fome imediata
- Desejo de pedir agora
- Percepcao de qualidade e frescor
- Conveniencia e praticidade

## Ofertas prioritarias para gravacao

- Barca hero
- Combinado com melhor custo-beneficio
- Temaki com boa leitura visual
- Combo de entrada para reduzir barreira de primeira compra

## Lista de takes obrigatorios

- Close bem fechado em peca premium
- Corte ou montagem pelo chef
- Molho, cream cheese, salmao e textura em evidencia
- Mao pegando a peca
- Pessoa mordendo ou comendo
- Embalagem ou entrega pronta
- Mesa com variedade de produtos
- Produto hero centralizado para thumb e imagem estatica

## Criativo 1 - Barca Hero

### Objetivo

Gerar desejo imediato com ticket mais alto e percepcao de abundancia.

### Gancho

- "Olha essa barca saindo agora"
- "Se bateu vontade de sushi, comeca por aqui"

### O que mostrar

- Barca completa
- Zoom em variedade
- Pessoa comendo
- Final com CTA de pedido

### CTA

- Peça agora
- Clique e veja o cardapio

## Criativo 2 - Combo de Entrada

### Objetivo

Diminuir barreira de primeira compra.

### Gancho

- "Quer pedir sushi hoje sem errar?"
- "Esse combo resolve seu jantar"

### O que mostrar

- Combo com leitura clara de quantidade
- Itens principais do combo
- Beneficio percebido

### CTA

- Veja o combo e peça agora

## Criativo 3 - Temaki e Consumo

### Objetivo

Trabalhar praticidade e desejo rapido.

### Gancho

- "Temaki bom e feito na hora"
- "Pra matar a vontade sem enrolacao"

### O que mostrar

- Temaki sendo montado
- Close da mordida
- Recheio aparente

### CTA

- Clique e escolha o seu

## Criativo 4 - Chef e Preparo

### Objetivo

Reforcar qualidade e frescor.

### Gancho

- "Aqui o sushi sai assim"
- "Qualidade de verdade com preparo na hora"

### O que mostrar

- Chef finalizando
- Corte preciso
- Montagem do prato

### CTA

- Peça agora pelo link

## Criativo 5 - Prova de Consumo

### Objetivo

Trazer autenticidade e reduzir percepcao de risco.

### Gancho

- "Olha isso aqui"
- "Nao tem como ver e nao querer pedir"

### O que mostrar

- Pessoa experimentando
- Reacao simples e genuina
- Produto em primeiro plano

### CTA

- Peça hoje

## Versoes que precisam sair da gravacao

- 3 videos de 15 a 25 segundos
- 2 videos de 30 a 45 segundos
- 5 thumbs ou frames fortes para estatico
- 3 fotos verticais para story
- 3 fotos quadradas para feed e remarketing

## Capas e thumbs

- Produto ocupando a maior parte da tela
- Fundo limpo ou pouco poluido
- Texto curto, se usar: "Peça agora", "Delivery em Barueri", "Combo hero"

## Erros para evitar

- Muito tempo falando antes de mostrar comida
- Video escuro ou sem textura aparente
- Mostrar ambiente ou bastidor demais e produto de menos
- CTA confuso
- Misturar delivery com evento no mesmo material

## Ordem sugerida de priorizacao na edicao

1. Barca hero
2. Combo de entrada
3. Temaki e consumo
4. Chef e preparo
5. Prova de consumo
