---
client_id: nubia-sushi
artifact_type: campaign-structure
title: Estrutura de Campanhas v1
created_at: 2026-04-14T17:20:00-03:00
metadata:
  status: draft
  source: codex
---

# Estrutura de Campanhas v1

## Campanha 1

Nome sugerido:
`[NS] [M1] Delivery | Oferta Hero | Barueri`

Objetivo:
Validar criativos e destino com foco em novos pedidos.

Plataforma:
Meta Ads

Geografia:
Barueri e raio prioritario de entrega a confirmar

Publicos iniciais:

- Broad local
- Interesses relacionados a sushi, comida japonesa e delivery
- Engajados do Instagram, se a base tiver volume minimo

Conjuntos sugeridos:

### Conjunto A - Broad Local

- Homens e mulheres
- 24 a 44 anos
- Barueri
- Sem muitos filtros

### Conjunto B - Interesses

- Homens e mulheres
- 24 a 44 anos
- Interesses em sushi, culinaria japonesa, delivery e restaurantes

### Conjunto C - Engajados

- Engajamento do Instagram e Facebook 30 a 90 dias
- Ativar apenas se houver base minima

Criativos dentro da campanha:

- Barca hero
- Combo de entrada
- Temaki e consumo
- Chef e preparo

Destino:

- Prioridade 1: link direto de pedido
- Prioridade 2: plataforma de cardapio/checkout
- Prioridade 3: WhatsApp comparativo

KPI principal:

- CPL de inicio de pedido

KPI secundario:

- CTR
- Taxa de clique no link
- Custo por conversa iniciada, se houver WhatsApp

Regra de decisao:

- Pausar criativo com CTR muito abaixo da media da conta
- Escalar criativo com melhor combinacao de CTR e inicio de pedido

## Campanha 2

Nome sugerido:
`[NS] [M2] Delivery | Remarketing | Recuperacao`

Objetivo:
Recuperar quem clicou, visitou ou quase pediu.

Plataforma:
Meta Ads

Trigger:

- Ativar apenas apos validacao do Mes 1

Publicos:

- Visitantes da rota de pedido
- Engajados com video
- Engajados com Instagram
- Iniciadores de conversa, se houver integracao

Criativos:

- Oferta curta
- Reforco de apetite
- Beneficio de decisao
- Lembrete de conveniencia

Destino:

- Mesmo destino vencedor do Mes 1

KPI principal:

- CPL menor que o trafego frio

## Campanha 3

Nome sugerido:
`[NS] [M3] Delivery | Recompra | Fidelizacao`

Objetivo:
Gerar segunda compra e frequencia.

Plataforma:
Meta Ads

Trigger:

- Ativar apenas se houver base qualificada

Publicos:

- Clientes recentes
- Lista de compradores
- Engajados quentes

Criativos:

- Volte a pedir hoje
- Seu combo favorito
- Conveniencia de repetir sem erro

Destino:

- Link direto de pedido ou rota vencedora

KPI principal:

- Custo por recompra

## Convencao de nomes

- Campanha: `[NS] [Mx] [Objetivo] | [Oferta]`
- Conjunto: `[Publico] | [Idade] | [Cidade]`
- Anuncio: `[Angulo] | [Formato] | [CTA]`

## Checklist antes de subir

- Pixel ou evento minimo configurado
- URL com UTMs
- Bio e perfil alinhados com a oferta
- Criativos exportados em 9:16 e 1:1
- Texto principal curto e objetivo
- CTA coerente com o destino

## Copys curtas para teste

- Bateu vontade de sushi? Peça agora.
- Seu jantar em Barueri pede isso aqui.
- Combo pronto para resolver sua fome hoje.
- Sushi bonito, fresco e saindo agora.

## Observacao operacional

Se a rota direta ainda nao estiver pronta, subir a campanha com WhatsApp apenas como fase de comparativo e nao como solucao definitiva.
