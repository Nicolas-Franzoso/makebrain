---
client_id: nubia-sushi
artifact_type: launch-playbook
title: Ordem de Subida de Campanhas v1
created_at: 2026-04-14T17:50:00-03:00
metadata:
  status: draft
  source: codex
---

# Ordem de Subida de Campanhas v1

## Fase 1 - Preparacao

1. Definir o destino principal da campanha
2. Confirmar se havera comparativo com WhatsApp
3. Subir pixel, UTM e rastreamento minimo
4. Ajustar bio, horario e link da marca
5. Separar criativos aprovados e copies finais

## Fase 2 - Subida da campanha principal

1. Criar campanha `Oferta Hero de Delivery`
2. Criar conjunto Broad Local
3. Criar conjunto Interesses
4. Criar conjunto Engajados apenas se houver volume
5. Subir criativos:
   Barca hero
   Combo de entrada
   Temaki e consumo
   Chef e preparo
6. Subir 2 a 3 variacoes de copy por anuncio

## Fase 3 - Primeiros 7 dias

1. Monitorar CTR
2. Monitorar custo por clique
3. Monitorar custo por inicio de pedido
4. Identificar criativo com maior apelo
5. Identificar melhor destino
6. Pausar rapidamente anuncio com baixa resposta

## Fase 4 - Otimizacao inicial

1. Manter os 2 melhores criativos
2. Subir novas variacoes com base no angulo vencedor
3. Reforcar o conjunto com melhor custo
4. Reduzir dispersao em publicos fracos

## Fase 5 - Trigger para remarketing

Ativar a campanha de remarketing apenas quando:

- houver base minima de engajamento ou visita
- o frio tiver gerado volume suficiente
- existir leitura clara do destino vencedor

## Fase 6 - Trigger para recompra

Ativar a campanha de recompra apenas quando:

- houver base minima de clientes ou compradores
- existir dado confiavel de retorno
- a operacao conseguir sustentar incentivo de recompra

## Ordem de prioridade operacional

1. Validar destino
2. Validar criativo
3. Validar publico
4. Validar remarketing
5. Validar recompra

## Erros para nao cometer

- Subir remarketing cedo demais
- Misturar objetivo de evento com delivery
- Escalar verba sem clareza de destino vencedor
- Manter criativo institucional por apego
- Tomar decisao so por clique sem olhar inicio de pedido
