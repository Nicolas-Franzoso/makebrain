---
client_id: nubia-sushi
author: growth
created_at: 2026-04-14T15:27:38.421399+00:00
kind: daily-note
---

# Onboarding Inicial

## Resumo rapido

- Cliente: Nubia Sushi
- Servicos contratados: makeads
- Meta 90 dias: Estruturar uma operacao previsivel de aquisicao para o delivery da Nubia Sushi em Barueri, validando criativos com forte apelo de apetite, reduzindo a dependencia exclusiva do WhatsApp e criando uma rota mais direta para pedido e recompra.
- Verba de midia: A confirmar no kickoff de midia

## Transcricao R1

Resumo inicial registrado pela Make: a meta central e construir previsibilidade na aquisicao do delivery da Nubia Sushi em Barueri. O foco inicial de MakeADS sera testar criativos com forte apelo de apetite, reduzir a dependencia exclusiva do WhatsApp como destino e criar uma rota mais direta para pedido e recompra. Pendencias para proxima coleta: ticket medio, verba, plataforma de pedidos, historico de campanhas, acessos da Meta e ativos criativos disponiveis.
