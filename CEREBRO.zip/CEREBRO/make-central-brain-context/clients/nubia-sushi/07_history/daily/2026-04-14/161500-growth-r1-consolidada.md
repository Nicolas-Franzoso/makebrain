---
client_id: nubia-sushi
author: growth
created_at: 2026-04-14T16:15:00+00:00
kind: daily-note
---

# R1 Consolidada

## Sintese estrategica

- A frente principal do projeto e delivery para Barueri, nao eventos e nao a operacao da Bolivia
- Ja existe historico de campanha levando para WhatsApp, mas com retorno percebido como fraco
- Surgiu uma oportunidade clara de testar rota de pedido mais direta via link da loja, como Anota.ai, Pede.ai ou equivalente
- O foco de curto prazo e gerar caixa no delivery; eventos ficam como linha secundaria com campanha separada

## Sinais relevantes

- Ticket medio inicial estimado em R$ 150
- Faixa observada nas ofertas citadas: R$ 100, R$ 155 e R$ 170
- Ambicao comercial citada em conversa: entre R$ 1.000 e R$ 2.000 por dia em vendas
- Nao ha controle claro hoje de origem dos pedidos nem da conversao entre mensagem e compra

## Direcao criativa

- Mostrar mais comida e menos institucional
- Trabalhar closes, textura, preparo, consumo e reacao
- Deixar a oferta mais clara no proprio anuncio
- Usar CTA direto para pedido

## Pendencias abertas

- Verba mensal de midia
- Link principal de pedido
- Acessos da Meta
- Conversao atual de mensagem para compra
- Raio e bairros prioritarios de entrega
