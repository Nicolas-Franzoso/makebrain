---
client_id: nubia-sushi
author: growth
created_at: 2026-04-14T15:45:00+00:00
kind: daily-note
---

# Plano de Midia v0

## O que foi definido

- Diretriz inicial de makeads para delivery local em Barueri
- Hipotese de reduzir dependencia do WhatsApp como destino principal
- Estrutura de campanhas separando prospeccao, remarketing e recompra
- Angulos criativos focados em apetite, combo, conveniencia e recorrencia

## Pendencias para fechar a v1

- Verba mensal de midia
- Ticket medio
- Plataforma e link de pedido
- Acessos da Meta
- Ativos criativos reais da operacao
- Raio de entrega e bairros prioritarios
