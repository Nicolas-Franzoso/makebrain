---
client_id: nubia-sushi
author: growth
created_at: 2026-04-14T17:05:00+00:00
kind: daily-note
---

# Plano de Midia v1

## O que mudou da v0 para a v1

- Plano migrado para o formato completo da skill de plano de midia
- Artefato principal agora esta em HTML com identidade Make
- CPLs e projecoes foram calculados com o M confidencial informado
- Estrategia principal ficou centrada em delivery Barueri com teste de rota direta
- Eventos foram mantidos fora do plano principal como frente separada

## Estrutura aprovada para apresentacao

- Mes 1: oferta hero de delivery
- Mes 2: remarketing de recuperacao, condicionado a validacao
- Mes 3: recompra e fidelizacao, condicionada a base qualificada

## Pendencias operacionais

- Confirmar rota principal de pedido
- Confirmar verba real disponivel
- Liberar acessos da Meta
- Organizar rastreio minimo
