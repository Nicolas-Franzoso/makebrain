---
client_id: nubia-sushi
slug: nubia-sushi
name: Nubia Sushi
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
approval_policy: human-required
stage: onboarding
main_goals:
- Estruturar uma operacao previsivel de aquisicao para o delivery da Nubia Sushi em
  Barueri, validando criativos com forte apelo de apetite, reduzindo a dependencia
  exclusiva do WhatsApp e criando uma rota mais direta para pedido e recompra.
primary_kpis:
- cpa_pedido
- volume_de_pedidos
- taxa_de_recompra
- participacao_de_pedidos_diretos
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Politica de aprovacao

Nenhuma acao externa critica sem aprovacao humana.

# Rotina de alinhamento

Checkpoint semanal a confirmar com o cliente

# Observacoes

Cadastro inicial criado a partir de briefing resumido. Confirmar no proximo contato: verba de midia, ticket medio, plataforma de pedidos, pagina ou cardapio proprio, acessos da Meta, publico prioritario, raio de entrega e disponibilidade de fotos/videos dos pratos.
