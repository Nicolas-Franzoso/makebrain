---
client_id: nubia-sushi
slug: nubia-sushi
name: Nubia Sushi
timezone: America/Sao_Paulo
owners:
- growth@make.local
services_enabled:
- makeads
approval_policy: human-required
stage: onboarding
main_goals:
- Estruturar uma operacao previsivel de aquisicao para o delivery da Nubia Sushi em
  Barueri, validando criativos com forte apelo de apetite, reduzindo a dependencia
  exclusiva do WhatsApp e criando uma rota mais direta para pedido e recompra.
primary_kpis:
- cpa_pedido
- volume_de_pedidos
- taxa_de_recompra
- participacao_de_pedidos_diretos
integrations:
  meta: pending
  google_ads: pending
  ga4: pending
  search_console: pending
  makecrm: pending
  mavi: disabled
status: active
---

# Tom de voz

Apetitoso, acessivel, direto e confiavel para pedidos rapidos no delivery

# Restrições e compliance

Evitar promessas que a operacao nao consiga cumprir em prazo, frete ou condicoes comerciais. Validar qualquer oferta promocional antes de publicar.

# Quem aprova

- Contato principal do cliente a confirmar
