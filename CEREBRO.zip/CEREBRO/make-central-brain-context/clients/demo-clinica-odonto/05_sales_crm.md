---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - crm
approval_policy: human-required
stage: onboarding
main_goals:
  - Melhorar comparecimento
primary_kpis:
  - contato_em_5_min
integrations:
  makecrm: planned
status: active
---

# SLA comercial

Responder leads em até 5 minutos úteis.

# Objeções frequentes

- Preço
- Medo de dor

