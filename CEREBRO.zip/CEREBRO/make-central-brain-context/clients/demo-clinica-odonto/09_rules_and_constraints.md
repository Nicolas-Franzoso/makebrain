---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - makeads
  - social
  - seo
  - crm
  - mavi
approval_policy: human-required
stage: onboarding
main_goals:
  - Operacao segura
primary_kpis:
  - aprovacoes_em_dia
integrations:
  meta: planned
status: active
---

# Limites de autonomia

Nenhuma campanha ou resposta sensível pode ser publicada sem aprovação humana.

# Compliance

Evitar promessas clínicas e antes/depois sem validação.

