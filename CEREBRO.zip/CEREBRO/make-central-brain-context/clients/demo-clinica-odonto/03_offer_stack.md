---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - makeads
  - social
  - seo
  - crm
  - mavi
approval_policy: human-required
stage: onboarding
main_goals:
  - Aumentar volume de avaliacao
primary_kpis:
  - leads_qualificados
integrations:
  meta: planned
status: active
---

# Prioridades comerciais

1. Implantes
2. Protocolo
3. Clareamento como oferta de entrada

