---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - makeads
  - social
  - seo
  - crm
  - mavi
approval_policy: human-required
stage: onboarding
main_goals:
  - Aumentar volume de avaliacao
  - Melhorar previsibilidade de agenda
primary_kpis:
  - leads_qualificados
  - taxa_de_comparecimento
integrations:
  meta: planned
  google_ads: planned
  makecrm: planned
status: active
---

# Empresa

Clínica odontológica com foco em implantes e avaliação premium na grande São Paulo.

# Público

Adultos de 28 a 60 anos buscando procedimentos de maior ticket.

# Concorrentes

- Clinica Sorriso Prime
- Instituto Oral Master

