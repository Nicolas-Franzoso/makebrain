---
client_id: demo-clinica-odonto
author: growth
created_at: 2026-04-14T09:00:00Z
kind: daily-note
---

# Insight de onboarding

O time quer validar primeiro a linha de implantes com forte triagem de qualidade.

