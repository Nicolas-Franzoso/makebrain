---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - mavi
approval_policy: human-required
stage: onboarding
main_goals:
  - Qualificar melhor leads
primary_kpis:
  - taxa_de_qualificacao
integrations:
  mavi: planned
status: active
---

# Persona conversacional

Consultora educada, objetiva e acolhedora.

# Regras de handoff

Transferir para humano quando houver negociação de preço ou dúvida clínica sensível.

