---
client_id: demo-clinica-odonto
slug: demo-clinica-odonto
name: Demo Clinica Odonto
timezone: America/Sao_Paulo
owners:
  - growth@make.local
services_enabled:
  - makeads
approval_policy: human-required
stage: onboarding
main_goals:
  - Validar CPL para avaliacao
primary_kpis:
  - cpl
integrations:
  meta: planned
status: active
---

# Estado atual

Ainda sem campanha ativa na v1.

# Hipótese inicial

Meta com CTA para avaliação e WhatsApp como destino primário.

